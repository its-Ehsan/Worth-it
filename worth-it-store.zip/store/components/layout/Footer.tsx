import Link from "next/link";
import type { Category, SiteSettings } from "@/lib/types";

export default function Footer({ s, categories }: { s: SiteSettings; categories: Category[] }) {
  const socials = [["Facebook", s.contact.facebook], ["Instagram", s.contact.instagram], ["YouTube", s.contact.youtube], ["TikTok", s.contact.tiktok]].filter(([, u]) => u);
  const col = "space-y-2.5 text-[14px] text-white/70 [&_a:hover]:text-white";
  return (
    <footer className="mt-24 border-t border-white/10 bg-[#07040D] text-white">
      <div className="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <p className="flex items-center gap-2 font-display text-2xl font-extrabold">
            {s.brand.logo_url && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={s.brand.logo_url} alt="" className="h-9 w-auto" />
            )}
            {s.brand.name}
          </p>
          <p className="mt-2 max-w-xs text-[14px] leading-relaxed text-white/70">{s.brand.tagline}</p>
          {socials.length > 0 && (
            <ul className="mt-5 flex flex-wrap gap-2">
              {socials.map(([n, u]) => <li key={n}><a href={u} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-[40px] items-center rounded-full border border-white/20 px-4 text-[13px] font-semibold hover:bg-white/10">{n}</a></li>)}
            </ul>
          )}
        </div>
        <nav aria-label="Shop"><h3 className="mb-3 text-sm font-bold">Shop</h3>
          <ul className={col}><li><Link href="/shop">All products</Link></li>{categories.map((c) => <li key={c.id}><Link href={`/category/${c.slug}`}>{c.name}</Link></li>)}</ul></nav>
        <nav aria-label="Help"><h3 className="mb-3 text-sm font-bold">Help</h3>
          <ul className={col}>
            <li><Link href="/faq">FAQ</Link></li><li><Link href="/shipping">Shipping &amp; delivery</Link></li>
            <li><Link href="/returns">Returns &amp; refunds</Link></li><li><Link href="/contact">Contact us</Link></li>
          </ul></nav>
        <div><h3 className="mb-3 text-sm font-bold">Talk to us</h3>
          <ul className={col}>
            {s.contact.phone && <li><a href={`tel:${s.contact.phone}`}>{s.contact.phone}</a></li>}
            {s.contact.email && <li><a href={`mailto:${s.contact.email}`}>{s.contact.email}</a></li>}
            {s.contact.hours && <li>{s.contact.hours}</li>}
          </ul></div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-x flex flex-col items-start justify-between gap-3 py-5 text-[13px] text-white/60 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} {s.brand.name}. All rights reserved.</p>
          <p className="flex gap-4"><Link href="/privacy" className="hover:text-white">Privacy</Link><Link href="/terms" className="hover:text-white">Terms</Link></p>
        </div>
      </div>
    </footer>
  );
}
