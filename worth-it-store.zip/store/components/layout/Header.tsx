"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "@/components/shop/CartProvider";
import SearchOverlay from "./SearchOverlay";

interface Props { brandName: string; logoUrl: string; showName: boolean; categories: { name: string; slug: string }[] }

const Icon = ({ d, size = 22 }: { d: string; size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d={d} /></svg>
);

export default function Header({ brandName, logoUrl, showName, categories }: Props) {
  const { count, bump, setDrawerOpen } = useCart();
  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const path = usePathname();

  useEffect(() => { setMenu(false); setSearch(false); }, [path]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on(); window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => { document.body.style.overflow = menu ? "hidden" : ""; return () => { document.body.style.overflow = ""; }; }, [menu]);

  const links = [{ href: "/shop", label: "Shop" }, ...categories.slice(0, 4).map((c) => ({ href: `/category/${c.slug}`, label: c.name })), { href: "/about", label: "About" }];

  return (
    <>
      <header className={`sticky top-0 z-40 transition-all duration-300 ${scrolled ? "border-b border-line bg-paper/85 backdrop-blur-xl" : "bg-paper"}`}>
        <div className="container-x flex h-16 items-center justify-between gap-4">
          <div className="flex items-center gap-2 lg:hidden">
            <button onClick={() => setMenu(true)} className="-ml-2 flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10" aria-label="Open menu"><Icon d="M4 7h16M4 12h16M4 17h10" /></button>
          </div>
          <Link href="/" className="flex items-center gap-2 font-display text-[22px] font-extrabold tracking-tight" aria-label={`${brandName} home`}>
            {logoUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logoUrl} alt={showName ? "" : brandName} className="h-9 w-auto" />
            )}
            {(!logoUrl || showName) && <span>{brandName}</span>}
          </Link>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={`rounded-full px-4 py-2 text-[14px] font-semibold transition hover:bg-white/10 ${path === l.href ? "bg-line/60" : ""}`}>{l.label}</Link>
            ))}
          </nav>
          <div className="flex items-center gap-1">
            <button onClick={() => setSearch(true)} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10" aria-label="Search"><Icon d="M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3" /></button>
            <button onClick={() => setDrawerOpen(true)} className="relative flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10" aria-label={`Cart, ${count} items`}>
              <Icon d="M6 7h13l-1.4 8.2a2 2 0 01-2 1.7H9.4a2 2 0 01-2-1.6L5.6 4H3M9 21h.01M17 21h.01" />
              {count > 0 && <span key={bump} className="absolute right-0.5 top-0.5 flex h-[18px] min-w-[18px] animate-pop items-center justify-center rounded-full bg-brand px-1 text-[11px] font-bold text-white">{count}</span>}
            </button>
          </div>
        </div>
      </header>

      {menu && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 animate-fadeIn bg-black/40" onClick={() => setMenu(false)} />
          <div className="absolute inset-y-0 left-0 flex w-[84%] max-w-sm animate-slideIn flex-col bg-paper p-5 [animation-name:none] motion-safe:[animation-name:slideInLeft]">
            <div className="mb-6 flex items-center justify-between">
              <span className="font-display text-xl font-extrabold">{brandName}</span>
              <button onClick={() => setMenu(false)} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10" aria-label="Close menu"><Icon d="M6 6l12 12M18 6L6 18" /></button>
            </div>
            <nav className="flex flex-col" aria-label="Mobile">
              {[{ href: "/shop", label: "All products" }, ...categories.map((c) => ({ href: `/category/${c.slug}`, label: c.name })), { href: "/about", label: "About" }, { href: "/contact", label: "Contact" }, { href: "/faq", label: "FAQ" }].map((l) => (
                <Link key={l.href + l.label} href={l.href} className="border-b border-line py-4 font-display text-xl font-bold">{l.label}</Link>
              ))}
            </nav>
          </div>
        </div>
      )}
      {search && <SearchOverlay onClose={() => setSearch(false)} />}
    </>
  );
}
