"use client";
import Link from "next/link";
import { useEffect } from "react";
import { useCart } from "@/components/shop/CartProvider";
import CartLines from "@/components/shop/CartLines";

export default function CartDrawer() {
  const { drawerOpen, setDrawerOpen, items, subtotal, money, config } = useCart();
  useEffect(() => {
    if (!drawerOpen) return;
    const key = (e: KeyboardEvent) => e.key === "Escape" && setDrawerOpen(false);
    window.addEventListener("keydown", key);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", key); document.body.style.overflow = ""; };
  }, [drawerOpen, setDrawerOpen]);
  if (!drawerOpen) return null;
  const close = () => setDrawerOpen(false);
  const remaining = config.freeAbove - subtotal;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Your cart">
      <div className="absolute inset-0 animate-fadeIn bg-black/50" onClick={close} />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-md animate-slideIn flex-col bg-paper shadow-2xl">
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <h2 className="font-display text-xl font-bold">Your cart</h2>
          <button onClick={close} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10" aria-label="Close cart">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
          </button>
        </div>
        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <p className="font-display text-xl font-bold">Your cart is empty</p>
            <p className="mt-1 text-sm text-muted">Add a gadget and it will wait for you here.</p>
            <Link href="/shop" onClick={close} className="btn-dark mt-5">Browse gadgets</Link>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-5 py-2"><CartLines compact onNavigate={close} /></div>
            <div className="border-t border-line bg-surface p-5">
              {config.freeAbove > 0 && (
                <div className="mb-4">
                  <p className="mb-1.5 text-[13px] font-medium">{remaining > 0 ? <>Add <b>{money(remaining)}</b> more for free delivery</> : "You've unlocked free delivery"}</p>
                  <div className="h-1.5 overflow-hidden rounded-full bg-line"><div className="h-full rounded-full bg-brand transition-all duration-500" style={{ width: `${Math.min(100, (subtotal / config.freeAbove) * 100)}%` }} /></div>
                </div>
              )}
              <div className="mb-3 flex items-center justify-between"><span className="text-sm text-muted">Subtotal</span><span className="font-display text-xl font-bold">{money(subtotal)}</span></div>
              <Link href="/checkout" onClick={close} className="btn-primary w-full">Checkout</Link>
              <Link href="/cart" onClick={close} className="mt-2 block py-2 text-center text-sm font-semibold text-muted hover:text-ink">View full cart</Link>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
