"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useCart } from "@/components/shop/CartProvider";

interface Suggestion { slug: string; name: string; price: number; image: string | null; category: string | null }
const RECENT = "recent-searches:v1";

export default function SearchOverlay({ onClose }: { onClose: () => void }) {
  const router = useRouter();
  const { money } = useCart();
  const ref = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Suggestion[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [recent, setRecent] = useState<string[]>([]);
  const [trending, setTrending] = useState<string[]>([]);

  useEffect(() => {
    ref.current?.focus();
    try { setRecent(JSON.parse(localStorage.getItem(RECENT) || "[]")); } catch { /* ignore */ }
    fetch("/api/search?trending=1").then((r) => r.json()).then((d) => setTrending(d.trending ?? [])).catch(() => {});
    const key = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", key);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", key); document.body.style.overflow = ""; };
  }, [onClose]);

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) { setResults(null); return; }
    setLoading(true);
    const ctl = new AbortController();
    const t = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(term)}`, { signal: ctl.signal })
        .then((r) => r.json()).then((d) => { setResults(d.results ?? []); setLoading(false); })
        .catch(() => setLoading(false));
    }, 160);
    return () => { clearTimeout(t); ctl.abort(); };
  }, [q]);

  function go(term: string) {
    const t = term.trim();
    if (!t) return;
    try { localStorage.setItem(RECENT, JSON.stringify([t, ...recent.filter((r) => r !== t)].slice(0, 6))); } catch { /* ignore */ }
    onClose();
    router.push(`/search?q=${encodeURIComponent(t)}`);
  }

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Search">
      <div className="absolute inset-0 animate-fadeIn bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative mx-auto mt-0 max-h-[100dvh] w-full animate-fadeUp overflow-y-auto bg-paper shadow-2xl sm:mt-16 sm:max-w-2xl sm:rounded-3xl">
        <form onSubmit={(e) => { e.preventDefault(); go(q); }} className="flex items-center gap-2 border-b border-line p-3 sm:p-4" role="search">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className="ml-2 shrink-0 text-muted"><path d="M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3" /></svg>
          <input ref={ref} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search earbuds, chargers, keyboards" aria-label="Search products"
            className="h-11 w-full bg-transparent text-base outline-none placeholder:text-muted/70" enterKeyHint="search" />
          <button type="button" onClick={onClose} className="rounded-full px-3 py-2 text-sm font-semibold hover:bg-white/10">Close</button>
        </form>

        <div className="p-4 sm:p-5">
          {results === null && (
            <div className="space-y-5">
              {recent.length > 0 && (
                <div>
                  <div className="mb-2 flex items-center justify-between"><h3 className="text-sm font-bold">Recent searches</h3>
                    <button className="text-xs font-semibold text-muted hover:text-ink" onClick={() => { localStorage.removeItem(RECENT); setRecent([]); }}>Clear</button></div>
                  <div className="flex flex-wrap gap-2">{recent.map((r) => <button key={r} onClick={() => go(r)} className="chip">{r}</button>)}</div>
                </div>
              )}
              {trending.length > 0 && (
                <div><h3 className="mb-2 text-sm font-bold">Popular right now</h3>
                  <div className="flex flex-wrap gap-2">{trending.map((r) => <button key={r} onClick={() => go(r)} className="chip">{r}</button>)}</div></div>
              )}
            </div>
          )}
          {loading && results === null && <div className="skeleton h-14" />}
          {results !== null && results.length > 0 && (
            <ul className="space-y-1" aria-live="polite">
              {results.map((r) => (
                <li key={r.slug}>
                  <Link href={`/product/${r.slug}`} onClick={() => { go(q); }} className="flex items-center gap-3 rounded-xl p-2 hover:bg-white/10">
                    <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-line/50">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      {r.image && <img src={r.image} alt="" className="h-full w-full object-cover" loading="lazy" />}
                    </span>
                    <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{r.name}</span><span className="block text-xs text-muted">{r.category}</span></span>
                    <span className="text-sm font-bold">{money(r.price)}</span>
                  </Link>
                </li>
              ))}
              <li><button onClick={() => go(q)} className="mt-1 w-full rounded-xl py-3 text-sm font-semibold text-brand-soft hover:bg-brand/5">See all results for “{q.trim()}”</button></li>
            </ul>
          )}
          {results !== null && results.length === 0 && (
            <div className="py-8 text-center" aria-live="polite">
              <p className="font-display text-lg font-bold">No matches for “{q.trim()}”</p>
              <p className="mt-1 text-sm text-muted">Check the spelling, or try a broader word like “charger” or “speaker”.</p>
              <Link href="/shop" onClick={onClose} className="btn-dark mt-4">Browse all products</Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
