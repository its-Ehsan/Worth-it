"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "./CartProvider";
import type { Product } from "@/lib/types";
import { isPurchasable } from "@/lib/utils";

export default function PurchasePanel({ product: p }: { product: Product }) {
  const { add, setDrawerOpen, money, config } = useCart();
  const router = useRouter();
  const [qty, setQty] = useState(1);
  const [choice, setChoice] = useState<Record<string, string>>(() => Object.fromEntries(p.variants.map((v) => [v.name, v.options[0] ?? ""])));
  const [added, setAdded] = useState(false);
  const buyable = isPurchasable(p);
  const max = p.stock_qty ?? 20;
  const variant = p.variants.map((v) => choice[v.name]).filter(Boolean).join(" / ");

  useEffect(() => { document.body.classList.add("has-sticky-buy"); return () => document.body.classList.remove("has-sticky-buy"); }, []);

  const line = { productId: p.id, slug: p.slug, name: p.name, price: p.price, image: p.images[0]?.url ?? null, variant, maxQty: p.stock_qty };
  function addToCart() {
    add(line, qty);
    setAdded(true); setDrawerOpen(true);
    setTimeout(() => setAdded(false), 1600);
  }
  function buyNow() { add(line, qty); router.push("/checkout"); }

  const actions = (
    <div className="flex gap-2.5">
      <button onClick={addToCart} disabled={!buyable} className="btn-ghost flex-1 !border-ink !font-bold">{added ? "Added ✓" : "Add to cart"}</button>
      <button onClick={buyNow} disabled={!buyable} className="btn-primary flex-1">Buy now</button>
    </div>
  );

  return (
    <div>
      {p.variants.map((v) => (
        <fieldset key={v.name} className="mb-5">
          <legend className="mb-2 text-sm font-bold">{v.name}: <span className="font-medium text-muted">{choice[v.name]}</span></legend>
          <div className="flex flex-wrap gap-2">
            {v.options.map((o) => (
              <button key={o} onClick={() => setChoice((c) => ({ ...c, [v.name]: o }))} aria-pressed={choice[v.name] === o}
                className={`min-h-[44px] rounded-xl border px-4 text-[14px] font-semibold transition ${choice[v.name] === o ? "border-brand bg-brand text-white" : "border-line bg-surface hover:border-ink/40"}`}>{o}</button>
            ))}
          </div>
        </fieldset>
      ))}

      {buyable ? (
        <>
          <div className="mb-4 flex items-center gap-4">
            <span className="text-sm font-bold">Quantity</span>
            <div className="inline-flex items-center rounded-full border border-line bg-surface">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10" aria-label="Decrease quantity">−</button>
              <span className="min-w-[2rem] text-center font-semibold" aria-live="polite">{qty}</span>
              <button onClick={() => setQty((q) => Math.min(max, q + 1))} disabled={qty >= max} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10 disabled:opacity-30" aria-label="Increase quantity">+</button>
            </div>
          </div>
          <div className="hidden lg:block">{actions}</div>
          {/* Mobile sticky purchase bar */}
          <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper/95 p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] backdrop-blur-xl lg:hidden">
            <div className="mx-auto flex max-w-xl items-center gap-3">
              <div className="min-w-0 shrink-0"><p className="font-display text-lg font-extrabold leading-none">{money(p.price * qty)}</p><p className="mt-0.5 text-[11px] text-muted">{qty > 1 ? `${qty} items` : "Cash on delivery"}</p></div>
              <div className="flex-1">{actions}</div>
            </div>
          </div>
        </>
      ) : (
        <div className="rounded-2xl border border-line bg-surface p-4 text-sm"><p className="font-bold">This item is sold out right now</p><p className="mt-1 text-muted">Message us and we&apos;ll tell you when it&apos;s back.</p></div>
      )}

      {buyable && p.cod_available && (
        <ul className="mt-5 space-y-2 rounded-2xl border border-line bg-surface p-4 text-[14px]">
          <li className="flex gap-2.5"><span className="font-bold text-emerald-400">✓</span><span><b>Cash on delivery</b> available. {config.codNote}</span></li>
          <li className="flex gap-2.5"><span className="font-bold text-emerald-400">✓</span><span>Inside Dhaka {config.insideEta}, outside Dhaka {config.outsideEta}</span></li>
          <li className="flex gap-2.5"><span className="font-bold text-emerald-400">✓</span><span>Delivery {money(config.insideFee)} in Dhaka, {money(config.outsideFee)} elsewhere{config.freeAbove > 0 ? `. Free over ${money(config.freeAbove)}.` : "."}</span></li>
        </ul>
      )}
    </div>
  );
}
