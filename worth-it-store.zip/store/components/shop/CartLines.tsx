"use client";
import Link from "next/link";
import Img from "@/components/ui/Img";
import { useCart } from "./CartProvider";

export default function CartLines({ compact = false, onNavigate }: { compact?: boolean; onNavigate?: () => void }) {
  const { items, setQty, remove, money } = useCart();
  return (
    <ul className="divide-y divide-line">
      {items.map((i) => (
        <li key={i.key} className={`flex gap-3.5 ${compact ? "py-4" : "py-5"}`}>
          <Link href={`/product/${i.slug}`} onClick={onNavigate} className={`relative shrink-0 overflow-hidden rounded-xl bg-line/40 ${compact ? "h-20 w-20" : "h-24 w-24 sm:h-28 sm:w-28"}`}>
            <Img src={i.image ?? ""} alt={i.name} sizes="112px" />
          </Link>
          <div className="flex min-w-0 flex-1 flex-col">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <Link href={`/product/${i.slug}`} onClick={onNavigate} className="line-clamp-2 text-[15px] font-semibold leading-snug hover:text-brand-soft">{i.name}</Link>
                {i.variant && <p className="mt-0.5 text-[13px] text-muted">{i.variant}</p>}
              </div>
              <button onClick={() => remove(i.key)} className="-mr-2 -mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-muted hover:bg-white/10 hover:text-ink" aria-label={`Remove ${i.name}`}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
              </button>
            </div>
            <div className="mt-auto flex items-center justify-between pt-2">
              <div className="inline-flex items-center rounded-full border border-line bg-surface">
                <button onClick={() => (i.qty > 1 ? setQty(i.key, i.qty - 1) : remove(i.key))} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-white/10" aria-label="Decrease quantity">−</button>
                <span className="min-w-[1.75rem] text-center text-sm font-semibold" aria-live="polite">{i.qty}</span>
                <button onClick={() => setQty(i.key, i.qty + 1)} disabled={i.maxQty !== null && i.qty >= i.maxQty} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-white/10 disabled:opacity-30" aria-label="Increase quantity">+</button>
              </div>
              <span className="font-display text-base font-bold">{money(i.price * i.qty)}</span>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
