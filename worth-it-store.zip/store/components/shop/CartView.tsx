"use client";
import Link from "next/link";
import { useCart } from "./CartProvider";
import CartLines from "./CartLines";

export default function CartView() {
  const { items, ready, subtotal, money, config } = useCart();
  if (!ready) return <div className="container-x pt-8"><div className="skeleton h-10 w-48" /><div className="skeleton mt-6 h-40" /><div className="skeleton mt-4 h-40" /></div>;
  if (items.length === 0) {
    return (
      <div className="container-x flex flex-col items-center py-24 text-center">
        <h1 className="text-3xl font-extrabold sm:text-4xl">Your cart is empty</h1>
        <p className="mt-2 max-w-sm text-muted">Pick a gadget you like and it will wait for you here.</p>
        <Link href="/shop" className="btn-primary mt-6">Start shopping</Link>
      </div>
    );
  }
  const remaining = config.freeAbove - subtotal;
  return (
    <div className="container-x pt-4 sm:pt-8">
      <h1 className="mb-6 text-4xl font-extrabold sm:text-5xl">Your cart</h1>
      <div className="grid gap-8 lg:grid-cols-[1fr_380px] lg:items-start lg:gap-12">
        <div className="card px-4 sm:px-6"><CartLines /></div>
        <aside className="card p-5 sm:p-6 lg:sticky lg:top-24">
          <h2 className="font-display text-xl font-bold">Order summary</h2>
          <dl className="mt-4 space-y-2.5 text-[15px]">
            <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd className="font-semibold">{money(subtotal)}</dd></div>
            <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd className="text-muted">Calculated at checkout</dd></div>
          </dl>
          {config.freeAbove > 0 && remaining > 0 && <p className="mt-4 rounded-xl bg-brand/5 px-3.5 py-2.5 text-[13px]">Add <b>{money(remaining)}</b> more for free delivery.</p>}
          <p className="mt-4 text-[13px] text-muted">{config.codNote}</p>
          <Link href="/checkout" className="btn-primary mt-5 w-full">Go to checkout</Link>
          <Link href="/shop" className="mt-2 block py-2 text-center text-sm font-semibold text-muted hover:text-ink">Keep shopping</Link>
        </aside>
      </div>
    </div>
  );
}
