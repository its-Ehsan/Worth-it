"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import Img from "@/components/ui/Img";
import { useCart } from "./CartProvider";

export interface Mini { slug: string; name: string; price: number; image: string }
const KEY = "recently-viewed:v1";

export default function RecentlyViewed({ currentSlug, all }: { currentSlug?: string; all: Mini[] }) {
  const [slugs, setSlugs] = useState<string[]>([]);
  const { money } = useCart();
  useEffect(() => {
    let list: string[] = [];
    try { list = JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { /* ignore */ }
    if (currentSlug) { list = [currentSlug, ...list.filter((s) => s !== currentSlug)].slice(0, 12); try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* ignore */ } }
    setSlugs(list.filter((s) => s !== currentSlug));
  }, [currentSlug]);
  const items = slugs.map((s) => all.find((a) => a.slug === s)).filter((x): x is Mini => !!x).slice(0, 6);
  if (!items.length) return null;
  return (
    <section className="container-x pt-14 sm:pt-20" aria-labelledby="rv-h">
      <h2 id="rv-h" className="mb-5 text-2xl font-extrabold sm:text-3xl">Recently viewed</h2>
      <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        {items.map((i) => (
          <Link key={i.slug} href={`/product/${i.slug}`} className="group w-36 shrink-0 sm:w-44">
            <span className="relative block aspect-square overflow-hidden rounded-2xl bg-line/40"><Img src={i.image} alt="" sizes="176px" className="transition duration-500 group-hover:scale-105" /></span>
            <span className="mt-2 line-clamp-1 block text-sm font-semibold">{i.name}</span><span className="text-sm text-muted">{money(i.price)}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}
