"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import Img from "@/components/ui/Img";
import Stars from "@/components/ui/Stars";

export interface DiscoveryItem {
  slug: string; name: string; price: number; compare: number | null; image: string; categoryId: string | null;
  rating: number; ratingCount: number; sold: number; buyable: boolean; short: string;
}

const BUDGETS = [
  { id: "all", max: Infinity },
  { id: "2k", max: 2000 },
  { id: "4k", max: 4000 },
  { id: "6k", max: 6000 },
];

export default function Discovery({ items, categories, symbol }: { items: DiscoveryItem[]; categories: { id: string; name: string }[]; symbol: string }) {
  const [cat, setCat] = useState("all");
  const [budget, setBudget] = useState("all");
  const max = BUDGETS.find((b) => b.id === budget)!.max;
  const list = useMemo(
    () => items.filter((i) => i.buyable && (cat === "all" || i.categoryId === cat) && i.price <= max).sort((a, b) => b.sold - a.sold).slice(0, 6),
    [items, cat, max],
  );
  const money = (n: number) => `${symbol}${Math.round(n).toLocaleString("en-US")}`;
  const Chip = ({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) => (
    <button onClick={onClick} aria-pressed={active} className={`shrink-0 rounded-full border px-4 py-2 text-[14px] font-semibold transition ${active ? "border-brand bg-brand text-white" : "border-line bg-surface hover:border-ink/40"}`}>{children}</button>
  );
  return (
    <div>
      <div className="space-y-3">
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0" role="group" aria-label="Category">
          <Chip active={cat === "all"} onClick={() => setCat("all")}>Everything</Chip>
          {categories.map((c) => <Chip key={c.id} active={cat === c.id} onClick={() => setCat(c.id)}>{c.name}</Chip>)}
        </div>
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0" role="group" aria-label="Budget">
          {BUDGETS.map((b) => <Chip key={b.id} active={budget === b.id} onClick={() => setBudget(b.id)}>{b.id === "all" ? "Any budget" : `Under ${symbol}${b.max.toLocaleString("en-US")}`}</Chip>)}
        </div>
      </div>
      <div key={`${cat}-${budget}`} className="mt-6 grid animate-fadeIn gap-3 sm:grid-cols-2 lg:grid-cols-3" aria-live="polite">
        {list.length === 0 && <p className="col-span-full rounded-2xl border border-dashed border-line p-8 text-center text-muted">Nothing fits that combination yet. Try a higher budget or another category.</p>}
        {list.map((i) => (
          <Link key={i.slug} href={`/product/${i.slug}`} className="group flex items-center gap-4 rounded-2xl border border-line bg-surface p-3 transition hover:border-ink/30 hover:shadow-[0_12px_30px_-18px_rgba(15,19,25,.4)]">
            <span className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-line/40"><Img src={i.image} alt="" sizes="96px" className="transition duration-500 group-hover:scale-105" /></span>
            <span className="min-w-0">
              <span className="line-clamp-1 font-semibold">{i.name}</span>
              <span className="mt-0.5 line-clamp-2 text-[13px] leading-snug text-muted">{i.short}</span>
              <span className="mt-1.5 flex items-center gap-2">
                <span className="font-display font-bold">{money(i.price)}</span>
                {i.ratingCount > 0 && <span className="flex items-center gap-1 text-xs text-muted"><Stars value={i.rating} size={11} />{i.rating.toFixed(1)}</span>}
              </span>
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
