import Link from "next/link";
import Img from "@/components/ui/Img";
import Stars from "@/components/ui/Stars";
import QuickAdd from "./QuickAdd";
import type { Product } from "@/lib/types";
import { discountPercent, isPurchasable } from "@/lib/utils";

export default function ProductCard({ p, symbol = "৳", priority = false, rank }: { p: Product; symbol?: string; priority?: boolean; rank?: number }) {
  const off = discountPercent(p.price, p.compare_at_price);
  const buyable = isPurchasable(p);
  const second = p.images[1]?.url;
  const money = (n: number) => `${symbol}${Math.round(n).toLocaleString("en-US")}`;
  return (
    <article className="group relative flex flex-col">
      <div className="relative">
      <Link href={`/product/${p.slug}`} className="relative block aspect-square overflow-hidden rounded-2xl bg-line/40" aria-label={p.name}>
        <Img src={p.images[0]?.url ?? ""} alt={p.images[0]?.alt || p.name} priority={priority}
          className={`transition duration-500 ease-out ${second ? "group-hover:opacity-0" : "group-hover:scale-105"} ${buyable ? "" : "opacity-60"}`} />
        {second && <Img src={second} alt="" className="opacity-0 transition duration-500 ease-out group-hover:opacity-100" />}
        <div className="absolute left-2.5 top-2.5 flex flex-wrap gap-1.5">
          {off > 0 && buyable && <span className="rounded-full bg-brand-2 px-2.5 py-1 text-[11px] font-bold text-white">{off}% off</span>}
          {p.is_new_arrival && buyable && <span className="rounded-full bg-deep px-2.5 py-1 text-[11px] font-bold text-white">New</span>}
          {!buyable && <span className="rounded-full bg-white px-2.5 py-1 text-[11px] font-bold text-[#0B0714]">Sold out</span>}
        </div>
        {rank && <span className="absolute bottom-2.5 left-3 font-display text-5xl font-extrabold text-white/90 drop-shadow">{rank}</span>}
      </Link>
      {buyable && <QuickAdd product={p} />}
      </div>
      <div className="mt-3 flex flex-1 flex-col px-0.5">
        <Link href={`/product/${p.slug}`} className="line-clamp-2 text-[15px] font-semibold leading-snug hover:text-brand-soft">{p.name}</Link>
        {(p.rating_count ?? 0) > 0 && (
          <div className="mt-1 flex items-center gap-1.5 text-xs text-muted"><Stars value={p.rating_avg ?? 0} size={12} /><span>({p.rating_count})</span></div>
        )}
        <div className="mt-1.5 flex items-baseline gap-2">
          <span className="font-display text-lg font-bold">{money(p.price)}</span>
          {p.compare_at_price && p.compare_at_price > p.price && <span className="text-sm text-muted line-through">{money(p.compare_at_price)}</span>}
        </div>
      </div>
    </article>
  );
}
