"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useCart } from "./CartProvider";
import type { Product } from "@/lib/types";

/** Round add-to-cart button on cards. Products with variants send you to the product page to choose. */
export default function QuickAdd({ product: p }: { product: Product }) {
  const { add } = useCart();
  const router = useRouter();
  const [done, setDone] = useState(false);
  function click(e: React.MouseEvent) {
    e.preventDefault();
    if (p.variants.length) { router.push(`/product/${p.slug}`); return; }
    add({ productId: p.id, slug: p.slug, name: p.name, price: p.price, image: p.images[0]?.url ?? null, variant: "", maxQty: p.stock_qty });
    setDone(true);
    setTimeout(() => setDone(false), 1400);
  }
  return (
    <button onClick={click} aria-label={p.variants.length ? `Choose options for ${p.name}` : `Add ${p.name} to cart`}
      className={`absolute bottom-2.5 right-2.5 z-10 hidden h-11 w-11 items-center justify-center rounded-full shadow-lg transition duration-200 active:scale-90 md:flex ${done ? "bg-emerald-500 text-white" : "bg-white text-[#0B0714] opacity-0 hover:bg-brand hover:text-white group-hover:opacity-100 focus-visible:opacity-100"}`}>
      {done ? (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 13l4 4L19 7" /></svg>
      ) : (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14" /></svg>
      )}
    </button>
  );
}
