"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState, useTransition } from "react";

interface Props { categories: { name: string; slug: string }[]; basePath: string; showCategory?: boolean; symbol: string; part: "bar" | "aside" }

const SORTS = [
  ["featured", "Featured"], ["newest", "Newest"], ["price-asc", "Price: low to high"], ["price-desc", "Price: high to low"], ["best", "Best selling"],
];

export default function ShopFilters({ categories, basePath, showCategory = true, symbol, part }: Props) {
  const router = useRouter();
  const sp = useSearchParams();
  const [pending, start] = useTransition();
  const [open, setOpen] = useState(false);
  const [min, setMin] = useState(sp.get("min") ?? "");
  const [max, setMax] = useState(sp.get("max") ?? "");
  useEffect(() => { setMin(sp.get("min") ?? ""); setMax(sp.get("max") ?? ""); }, [sp]);

  function set(updates: Record<string, string | null>) {
    const next = new URLSearchParams(sp.toString());
    for (const [k, v] of Object.entries(updates)) { if (v === null || v === "") next.delete(k); else next.set(k, v); }
    const qs = next.toString();
    start(() => router.push(qs ? `${basePath}?${qs}` : basePath, { scroll: false }));
  }
  const active = ["category", "min", "max", "stock", "rating"].filter((k) => sp.get(k)).length;
  const sort = sp.get("sort") ?? (sp.get("q") ? "" : "featured");

  const panel = (
    <div className="space-y-7">
      {showCategory && (
        <fieldset><legend className="mb-2.5 text-sm font-bold">Category</legend>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => set({ category: null })} aria-pressed={!sp.get("category")} className={`chip ${!sp.get("category") ? "!border-brand !bg-brand !text-white" : ""}`}>All</button>
            {categories.map((c) => <button key={c.slug} onClick={() => set({ category: c.slug })} aria-pressed={sp.get("category") === c.slug} className={`chip ${sp.get("category") === c.slug ? "!border-brand !bg-brand !text-white" : ""}`}>{c.name}</button>)}
          </div></fieldset>
      )}
      <fieldset><legend className="mb-2.5 text-sm font-bold">Price ({symbol})</legend>
        <form onSubmit={(e) => { e.preventDefault(); set({ min, max }); }} className="flex items-center gap-2">
          <input className="input !min-h-[42px]" inputMode="numeric" placeholder="Min" aria-label="Minimum price" value={min} onChange={(e) => setMin(e.target.value.replace(/\D/g, ""))} />
          <span className="text-muted">to</span>
          <input className="input !min-h-[42px]" inputMode="numeric" placeholder="Max" aria-label="Maximum price" value={max} onChange={(e) => setMax(e.target.value.replace(/\D/g, ""))} />
          <button className="btn-dark !min-h-[42px] !px-4" type="submit">Go</button>
        </form></fieldset>
      <fieldset><legend className="mb-2.5 text-sm font-bold">Availability</legend>
        <label className="flex min-h-[44px] cursor-pointer items-center gap-3 text-[15px]"><input type="checkbox" className="h-5 w-5 accent-[rgb(var(--brand))]" checked={sp.get("stock") === "1"} onChange={(e) => set({ stock: e.target.checked ? "1" : null })} />In stock only</label></fieldset>
      <fieldset><legend className="mb-2.5 text-sm font-bold">Rating</legend>
        <div className="flex gap-2">{[["", "Any"], ["4", "4★ & up"], ["3", "3★ & up"]].map(([v, l]) => (
          <button key={l} onClick={() => set({ rating: v || null })} aria-pressed={(sp.get("rating") ?? "") === v} className={`chip ${(sp.get("rating") ?? "") === v ? "!border-brand !bg-brand !text-white" : ""}`}>{l}</button>))}</div></fieldset>
      {active > 0 && <button onClick={() => set({ category: null, min: null, max: null, stock: null, rating: null })} className="text-sm font-semibold text-brand-soft hover:underline">Clear all filters</button>}
    </div>
  );

  if (part === "aside") return <aside className={`hidden lg:block ${pending ? "opacity-60" : ""}`} aria-label="Filters">{panel}</aside>;

  return (
    <>
      <div className="mb-5 flex items-center justify-between gap-3">
        <button onClick={() => setOpen(true)} className="btn-ghost !min-h-[44px] lg:hidden">Filters{active > 0 && <span className="rounded-full bg-brand px-2 text-xs text-white">{active}</span>}</button>
        <label className="ml-auto flex items-center gap-2 text-sm"><span className="hidden text-muted sm:inline">Sort by</span>
          <select value={sort} onChange={(e) => set({ sort: e.target.value })} className="input !min-h-[44px] !w-auto pr-8" aria-label="Sort products">
            {!sp.get("sort") && sp.get("q") && <option value="">Best match</option>}
            {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select></label>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Filters">
          <div className="absolute inset-0 animate-fadeIn bg-black/50" onClick={() => setOpen(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[85dvh] animate-slideUp overflow-y-auto rounded-t-3xl bg-paper p-5 pb-8">
            <div className="mb-5 flex items-center justify-between"><h2 className="font-display text-xl font-bold">Filters</h2><button onClick={() => setOpen(false)} className="btn-dark !min-h-[40px] !px-5">Show results</button></div>
            {panel}
          </div>
        </div>
      )}
    </>
  );
}
