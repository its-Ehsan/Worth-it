import Link from "next/link";
import { Suspense } from "react";
import ProductCard from "./ProductCard";
import ShopFilters from "./ShopFilters";
import type { Category, Product } from "@/lib/types";

interface Props {
  title: string; sub?: string; products: Product[]; categories: Category[]; basePath: string; symbol: string;
  showCategory?: boolean; empty?: React.ReactNode; breadcrumb?: { href: string; label: string }[];
}

export default function Listing({ title, sub, products, categories, basePath, symbol, showCategory = true, empty, breadcrumb }: Props) {
  const cats = categories.map((c) => ({ name: c.name, slug: c.slug }));
  return (
    <div className="container-x pt-4 sm:pt-8">
      {breadcrumb && (
        <nav aria-label="Breadcrumb" className="mb-3 text-[13px] text-muted">
          {breadcrumb.map((b, i) => <span key={b.href}>{i > 0 && " / "}<Link href={b.href} className="hover:text-ink">{b.label}</Link></span>)}
        </nav>
      )}
      <header className="mb-6 sm:mb-8"><h1 className="text-4xl font-extrabold sm:text-5xl">{title}</h1>{sub && <p className="mt-2 max-w-2xl text-muted">{sub}</p>}
        <p className="mt-2 text-sm text-muted" aria-live="polite">{products.length} {products.length === 1 ? "product" : "products"}</p></header>
      <div className="lg:grid lg:grid-cols-[250px_1fr] lg:gap-10">
        <Suspense fallback={null}><ShopFilters part="aside" categories={cats} basePath={basePath} showCategory={showCategory} symbol={symbol} /></Suspense>
        <div className="min-w-0">
          <Suspense fallback={<div className="skeleton mb-5 h-11" />}><ShopFilters part="bar" categories={cats} basePath={basePath} showCategory={showCategory} symbol={symbol} /></Suspense>
          {products.length === 0 ? (empty ?? (
            <div className="rounded-3xl border border-dashed border-line bg-surface p-10 text-center">
              <p className="font-display text-xl font-bold">Nothing matches those filters</p>
              <p className="mt-1 text-sm text-muted">Widen the price range or clear a filter to see more.</p>
              <Link href={basePath} className="btn-dark mt-5">Clear filters</Link>
            </div>
          )) : (
            <div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-5 xl:grid-cols-3">
              {products.map((p, i) => <ProductCard key={p.id} p={p} symbol={symbol} priority={i < 4} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
