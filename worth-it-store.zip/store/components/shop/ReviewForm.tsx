"use client";
import { useState, useTransition } from "react";
import { submitReview } from "@/app/actions/shop";

export default function ReviewForm({ productId, productName }: { productId: string; productName: string }) {
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();

  if (msg?.ok) return <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-5 text-sm text-emerald-200" role="status"><p className="font-bold">Thanks for your review</p><p className="mt-1">It will appear on the page once our team has approved it.</p></div>;
  if (!open) return <button onClick={() => setOpen(true)} className="btn-ghost">Write a review</button>;

  return (
    <form className="card space-y-4 p-5" onSubmit={(e) => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget);
      fd.set("product_id", productId); fd.set("rating", String(rating));
      setMsg(null);
      start(async () => { const r = await submitReview(fd); setMsg(r.ok ? { ok: true, text: "" } : { ok: false, text: r.error }); });
    }}>
      <div><h3 className="font-display text-lg font-bold">Review {productName}</h3><p className="text-[13px] text-muted">Only customers who ordered this product can review it. Use your order number and phone to verify.</p></div>
      <fieldset><legend className="label">Your rating</legend>
        <div className="flex gap-1" role="radiogroup" aria-label="Rating">
          {[1, 2, 3, 4, 5].map((n) => (
            <button type="button" key={n} role="radio" aria-checked={rating === n} aria-label={`${n} star${n > 1 ? "s" : ""}`} onClick={() => setRating(n)} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10">
              <svg width="28" height="28" viewBox="0 0 20 20" className={n <= rating ? "fill-[#F5A524]" : "fill-line"}><path d="M10 1.5l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L1.4 7.8l6-.8L10 1.5z" /></svg></button>))}
        </div></fieldset>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="rv-order">Order number</label><input id="rv-order" name="order_number" required className="input" placeholder="ORD-XXXXXXXX" autoCapitalize="characters" /></div>
        <div><label className="label" htmlFor="rv-phone">Phone used for the order</label><input id="rv-phone" name="phone" required inputMode="tel" className="input" placeholder="01XXXXXXXXX" /></div>
      </div>
      <div><label className="label" htmlFor="rv-name">Your name</label><input id="rv-name" name="name" required maxLength={60} className="input" /></div>
      <div><label className="label" htmlFor="rv-body">Your review</label><textarea id="rv-body" name="body" required minLength={10} maxLength={1200} rows={4} className="input !py-3" placeholder="What did you like? Anything to know before buying?" /></div>
      <div><label className="label" htmlFor="rv-img">Photo (optional)</label><input id="rv-img" name="image" type="file" accept="image/jpeg,image/png,image/webp" className="block w-full text-sm file:mr-3 file:rounded-full file:border-0 file:bg-deep file:px-4 file:py-2.5 file:font-semibold file:text-white" /></div>
      {msg && !msg.ok && <p role="alert" className="rounded-xl bg-red-500/10 px-4 py-3 text-sm font-medium text-red-300">{msg.text}</p>}
      <div className="flex gap-2"><button className="btn-primary" disabled={pending || rating === 0}>{pending ? "Sending…" : "Submit review"}</button><button type="button" className="btn-ghost" onClick={() => setOpen(false)}>Cancel</button></div>
    </form>
  );
}
