import Link from "next/link";

export default function Section({ title, sub, href, cta = "View all", children, className = "" }: { title: string; sub?: string; href?: string; cta?: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={`container-x pt-16 sm:pt-24 ${className}`}>
      <div className="mb-6 flex items-end justify-between gap-4 sm:mb-8">
        <div><h2 className="text-[28px] font-extrabold leading-tight sm:text-4xl">{title}</h2>{sub && <p className="mt-1.5 max-w-xl text-[15px] text-muted">{sub}</p>}</div>
        {href && <Link href={href} className="shrink-0 rounded-full border border-line bg-surface px-4 py-2 text-[14px] font-semibold hover:border-ink/40">{cta}</Link>}
      </div>
      {children}
    </section>
  );
}
