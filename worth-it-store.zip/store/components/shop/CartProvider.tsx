"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { CartItem } from "@/lib/types";

export interface ShopConfig {
  brandName: string;
  symbol: string;
  insideFee: number;
  outsideFee: number;
  freeAbove: number;
  codNote: string;
  insideEta: string;
  outsideEta: string;
}

interface Ctx {
  items: CartItem[]; count: number; subtotal: number; ready: boolean; bump: number;
  drawerOpen: boolean; setDrawerOpen: (v: boolean) => void;
  add: (item: Omit<CartItem, "key" | "qty">, qty?: number) => void;
  setQty: (key: string, qty: number) => void;
  remove: (key: string) => void;
  clear: () => void;
  config: ShopConfig;
  money: (n: number) => string;
}

const CartCtx = createContext<Ctx | null>(null);
const KEY = "cart:v1";

export function CartProvider({ children, config }: { children: React.ReactNode; config: ShopConfig }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);
  const [bump, setBump] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) setItems(JSON.parse(raw)); } catch { /* ignore corrupt storage */ }
    setReady(true);
  }, []);
  useEffect(() => { if (ready) try { localStorage.setItem(KEY, JSON.stringify(items)); } catch { /* storage full/blocked */ } }, [items, ready]);

  const add = useCallback<Ctx["add"]>((item, qty = 1) => {
    const key = `${item.productId}::${item.variant}`;
    setItems((cur) => {
      const found = cur.find((i) => i.key === key);
      const cap = item.maxQty ?? 99;
      if (found) return cur.map((i) => (i.key === key ? { ...i, ...item, qty: Math.min(cap, i.qty + qty) } : i));
      return [...cur, { ...item, key, qty: Math.min(cap, qty) }];
    });
    setBump((b) => b + 1);
  }, []);
  const setQty = useCallback((key: string, qty: number) => setItems((cur) => cur.map((i) => (i.key === key ? { ...i, qty: Math.max(1, Math.min(i.maxQty ?? 99, qty)) } : i))), []);
  const remove = useCallback((key: string) => setItems((cur) => cur.filter((i) => i.key !== key)), []);
  const clear = useCallback(() => setItems([]), []);

  const value = useMemo<Ctx>(() => ({
    items, ready, bump, drawerOpen, setDrawerOpen, add, setQty, remove, clear, config,
    count: items.reduce((n, i) => n + i.qty, 0),
    subtotal: items.reduce((n, i) => n + i.qty * i.price, 0),
    money: (n: number) => `${config.symbol}${Math.round(n).toLocaleString("en-US")}`,
  }), [items, ready, bump, drawerOpen, add, setQty, remove, clear, config]);

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const c = useContext(CartCtx);
  if (!c) throw new Error("useCart must be used inside CartProvider");
  return c;
}

export function deliveryFor(district: string, subtotal: number, cfg: ShopConfig) {
  if (!district) return 0;
  if (cfg.freeAbove > 0 && subtotal >= cfg.freeAbove) return 0;
  return district === "Dhaka" ? cfg.insideFee : cfg.outsideFee;
}
