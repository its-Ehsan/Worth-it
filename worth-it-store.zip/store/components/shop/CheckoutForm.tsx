"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { placeOrder, validateCoupon } from "@/app/actions/shop";
import { DISTRICTS } from "@/lib/bd";
import Img from "@/components/ui/Img";
import { deliveryFor, useCart } from "./CartProvider";

export default function CheckoutForm() {
  const { items, ready, subtotal, money, config, clear } = useCart();
  const router = useRouter();
  const [f, setF] = useState({ name: "", phone: "", district: "", area: "", address: "", notes: "", website: "" });
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState<{ code: string; discount: number } | null>(null);
  const [couponMsg, setCouponMsg] = useState<string | null>(null);
  const [error, setError] = useState<{ text: string; field?: string } | null>(null);
  const [pending, start] = useTransition();
  const [couponPending, startCoupon] = useTransition();

  if (!ready) return <div className="container-x pt-8"><div className="skeleton h-10 w-56" /><div className="skeleton mt-6 h-96" /></div>;
  if (items.length === 0) {
    return (
      <div className="container-x flex flex-col items-center py-24 text-center">
        <h1 className="text-3xl font-extrabold">Nothing to check out yet</h1>
        <p className="mt-2 text-muted">Add a gadget to your cart first.</p>
        <Link href="/shop" className="btn-primary mt-6">Browse gadgets</Link>
      </div>
    );
  }

  const discount = applied?.discount ?? 0;
  const fee = deliveryFor(f.district, subtotal, config);
  const total = subtotal - discount + fee;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => { setF((c) => ({ ...c, [k]: e.target.value })); if (error?.field === k) setError(null); };
  const invalid = (k: string) => error?.field === k;

  function applyCoupon() {
    setCouponMsg(null);
    startCoupon(async () => {
      const r = await validateCoupon(coupon, subtotal);
      if (r.ok) { setApplied({ code: r.code, discount: r.discount }); setCouponMsg(`Coupon applied. You save ${money(r.discount)}.`); }
      else { setApplied(null); setCouponMsg(r.error); }
    });
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    start(async () => {
      const r = await placeOrder({ ...f, coupon: applied?.code ?? "", items: items.map((i) => ({ productId: i.productId, qty: i.qty, variant: i.variant })) });
      if (r.ok) { clear(); router.push(`/order/${r.orderNumber}`); }
      else {
        setError({ text: r.error, field: r.field });
        if (r.field) document.getElementById(`co-${r.field}`)?.focus();
      }
    });
  }

  const err = (k: string) => invalid(k) ? <p role="alert" className="mt-1.5 text-[13px] font-medium text-red-400">{error!.text}</p> : null;
  const ring = (k: string) => (invalid(k) ? "!border-red-500 !ring-4 !ring-red-100" : "");

  return (
    <div className="container-x pt-4 sm:pt-8">
      <h1 className="mb-1 text-4xl font-extrabold sm:text-5xl">Checkout</h1>
      <p className="mb-8 text-muted">No account needed. You pay in cash when the parcel arrives.</p>
      <form onSubmit={submit} className="grid gap-8 lg:grid-cols-[1fr_400px] lg:items-start lg:gap-12" noValidate>
        <div className="space-y-5">
          <div className="card space-y-4 p-5 sm:p-6">
            <h2 className="font-display text-xl font-bold">Delivery details</h2>
            <div><label className="label" htmlFor="co-name">Full name</label><input id="co-name" className={`input ${ring("name")}`} value={f.name} onChange={set("name")} autoComplete="name" required />{err("name")}</div>
            <div><label className="label" htmlFor="co-phone">Phone number</label><input id="co-phone" className={`input ${ring("phone")}`} value={f.phone} onChange={set("phone")} inputMode="tel" autoComplete="tel" placeholder="01XXXXXXXXX" required />{err("phone")}</div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div><label className="label" htmlFor="co-district">District</label>
                <select id="co-district" className={`input ${ring("district")}`} value={f.district} onChange={set("district")} required>
                  <option value="">Select district</option>{DISTRICTS.map((d) => <option key={d}>{d}</option>)}</select>{err("district")}</div>
              <div><label className="label" htmlFor="co-area">Area / Thana</label><input id="co-area" className={`input ${ring("area")}`} value={f.area} onChange={set("area")} autoComplete="address-level2" required />{err("area")}</div>
            </div>
            <div><label className="label" htmlFor="co-address">Full address</label><textarea id="co-address" className={`input !py-3 ${ring("address")}`} rows={3} value={f.address} onChange={set("address")} autoComplete="street-address" placeholder="House, road, landmark" required />{err("address")}</div>
            <div><label className="label" htmlFor="co-notes">Notes for us <span className="font-normal text-muted">(optional)</span></label><textarea id="co-notes" className="input !py-3" rows={2} value={f.notes} onChange={set("notes")} placeholder="Delivery time, colour preference, anything else" /></div>
            <div className="hidden" aria-hidden><label>Website<input tabIndex={-1} autoComplete="off" value={f.website} onChange={set("website")} /></label></div>
          </div>
          <div className="card p-5 sm:p-6">
            <h2 className="font-display text-xl font-bold">Payment</h2>
            <label className="mt-3 flex items-start gap-3 rounded-xl border-2 border-ink bg-surface p-4">
              <input type="radio" checked readOnly className="mt-1 h-5 w-5 accent-[rgb(var(--brand))]" />
              <span><span className="block font-semibold">Cash on delivery</span><span className="text-[14px] text-muted">{config.codNote}</span></span>
            </label>
          </div>
        </div>

        <aside className="card p-5 sm:p-6 lg:sticky lg:top-24">
          <h2 className="font-display text-xl font-bold">Your order</h2>
          <ul className="mt-4 space-y-3">
            {items.map((i) => (
              <li key={i.key} className="flex items-center gap-3">
                <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-line/40"><Img src={i.image ?? ""} alt="" sizes="56px" /><span className="absolute -right-0 -top-0 rounded-bl-lg bg-deep px-1.5 text-[11px] font-bold text-white">{i.qty}</span></span>
                <span className="min-w-0 flex-1 text-sm"><span className="line-clamp-1 font-semibold">{i.name}</span>{i.variant && <span className="text-xs text-muted">{i.variant}</span>}</span>
                <span className="text-sm font-semibold">{money(i.price * i.qty)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-5">
            <label className="label" htmlFor="co-coupon">Coupon code</label>
            <div className="flex gap-2"><input id="co-coupon" className={`input !min-h-[44px] uppercase ${ring("coupon")}`} value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Have a code?" autoCapitalize="characters" />
              <button type="button" onClick={applyCoupon} disabled={couponPending || !coupon.trim()} className="btn-dark !min-h-[44px] !px-5">{couponPending ? "…" : "Apply"}</button></div>
            {couponMsg && <p className={`mt-1.5 text-[13px] font-medium ${applied ? "text-emerald-400" : "text-red-400"}`} role="status">{couponMsg}</p>}
          </div>
          <dl className="mt-5 space-y-2 border-t border-line pt-4 text-[15px]">
            <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{money(subtotal)}</dd></div>
            {discount > 0 && <div className="flex justify-between text-emerald-400"><dt>Discount</dt><dd>−{money(discount)}</dd></div>}
            <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd>{!f.district ? "Choose district" : fee === 0 ? "Free" : money(fee)}</dd></div>
            <div className="flex justify-between border-t border-line pt-3 font-display text-xl font-extrabold"><dt>Total</dt><dd>{money(total)}</dd></div>
          </dl>
          {error && !error.field && <p role="alert" className="mt-4 rounded-xl bg-red-500/10 px-4 py-3 text-sm font-medium text-red-300">{error.text}</p>}
          {error?.field && <p role="alert" className="mt-4 rounded-xl bg-red-500/10 px-4 py-3 text-sm font-medium text-red-300">Please fix the highlighted field.</p>}
          <button className="btn-primary mt-5 w-full !min-h-[52px] text-base" disabled={pending}>{pending ? "Placing your order…" : `Place order · ${money(total)}`}</button>
          <p className="mt-3 text-center text-[12px] text-muted">By ordering you agree to our <Link href="/terms" className="underline">terms</Link> and <Link href="/returns" className="underline">return policy</Link>.</p>
        </aside>
      </form>
    </div>
  );
}
