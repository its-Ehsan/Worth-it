"use client";
import { useEffect, useRef, useState } from "react";
import Img from "@/components/ui/Img";
import type { ProductImage } from "@/lib/types";

export default function Gallery({ images, name }: { images: ProductImage[]; name: string }) {
  const [i, setI] = useState(0);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const [light, setLight] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const list = images.length ? images : [{ url: "", alt: name }];

  useEffect(() => {
    if (!light) return;
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLight(false);
      if (e.key === "ArrowRight") setI((v) => (v + 1) % list.length);
      if (e.key === "ArrowLeft") setI((v) => (v - 1 + list.length) % list.length);
    };
    window.addEventListener("keydown", key);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", key); document.body.style.overflow = ""; };
  }, [light, list.length]);

  function onScroll() {
    const el = scroller.current; if (!el) return;
    setI(Math.round(el.scrollLeft / el.clientWidth));
  }
  function goto(n: number) {
    setI(n);
    const el = scroller.current;
    if (el && window.matchMedia("(max-width: 1023px)").matches) el.scrollTo({ left: n * el.clientWidth, behavior: "smooth" });
  }
  const move = (e: React.MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    setZoom({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 });
  };

  return (
    <div className="lg:sticky lg:top-24 lg:flex lg:flex-row-reverse lg:gap-4">
      <div className="relative flex-1">
        {/* Mobile: swipe carousel */}
        <div ref={scroller} onScroll={onScroll} className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto rounded-3xl lg:hidden">
          {list.map((im, n) => (
            <button key={n} onClick={() => { setI(n); setLight(true); }} className="relative aspect-square w-full shrink-0 snap-center bg-line/40" aria-label={`Open image ${n + 1} full screen`}>
              <Img src={im.url} alt={im.alt || `${name} ${n + 1}`} priority={n === 0} sizes="100vw" />
            </button>
          ))}
        </div>
        {/* Desktop: hover zoom */}
        <div className="relative hidden aspect-square cursor-zoom-in overflow-hidden rounded-3xl bg-line/40 lg:block"
          onMouseMove={move} onMouseLeave={() => setZoom(null)} onClick={() => setLight(true)} role="button" tabIndex={0}
          onKeyDown={(e) => e.key === "Enter" && setLight(true)} aria-label="Zoom product image">
          <div className="absolute inset-0 transition-transform duration-200 ease-out" style={zoom ? { transform: "scale(2)", transformOrigin: `${zoom.x}% ${zoom.y}%` } : undefined}>
            <Img src={list[i].url} alt={list[i].alt || name} priority sizes="(min-width:1024px) 600px, 100vw" />
          </div>
        </div>
        {list.length > 1 && (
          <div className="mt-3 flex justify-center gap-1.5 lg:hidden" aria-hidden>
            {list.map((_, n) => <span key={n} className={`h-1.5 rounded-full transition-all ${n === i ? "w-5 bg-deep" : "w-1.5 bg-black/25"}`} />)}
          </div>
        )}
      </div>
      {list.length > 1 && (
        <div className="mt-4 hidden gap-3 lg:mt-0 lg:flex lg:w-20 lg:flex-col" role="tablist" aria-label="Product images">
          {list.map((im, n) => (
            <button key={n} role="tab" aria-selected={n === i} onClick={() => goto(n)}
              className={`relative aspect-square overflow-hidden rounded-xl bg-line/40 ring-2 transition ${n === i ? "ring-brand" : "ring-transparent hover:ring-brand/30"}`}>
              <Img src={im.url} alt="" sizes="80px" />
            </button>
          ))}
        </div>
      )}
      {light && (
        <div className="fixed inset-0 z-[60] flex animate-fadeIn items-center justify-center bg-black/95 p-4" role="dialog" aria-modal="true" aria-label="Image viewer" onClick={() => setLight(false)}>
          <button className="absolute right-4 top-4 flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20" aria-label="Close viewer">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg></button>
          {list.length > 1 && <>
            <button onClick={(e) => { e.stopPropagation(); setI((i - 1 + list.length) % list.length); }} className="absolute left-3 flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-2xl text-white hover:bg-white/20" aria-label="Previous image">‹</button>
            <button onClick={(e) => { e.stopPropagation(); setI((i + 1) % list.length); }} className="absolute right-3 flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-2xl text-white hover:bg-white/20" aria-label="Next image">›</button></>}
          <div className="relative aspect-square w-full max-w-[min(90vw,85vh)] overflow-hidden rounded-2xl" onClick={(e) => e.stopPropagation()}>
            <Img src={list[i].url} alt={list[i].alt || name} sizes="90vw" className="!object-contain" />
          </div>
        </div>
      )}
    </div>
  );
}
