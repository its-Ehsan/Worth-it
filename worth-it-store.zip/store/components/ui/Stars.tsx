export default function Stars({ value, size = 14 }: { value: number; size?: number }) {
  const pct = Math.max(0, Math.min(100, (value / 5) * 100));
  const star = (
    <svg width={size} height={size} viewBox="0 0 20 20" aria-hidden><path d="M10 1.5l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L1.4 7.8l6-.8L10 1.5z" /></svg>
  );
  return (
    <span className="relative inline-flex" role="img" aria-label={`${value.toFixed(1)} out of 5 stars`}>
      <span className="flex fill-white/20">{[0, 1, 2, 3, 4].map((i) => <span key={i}>{star}</span>)}</span>
      <span className="absolute inset-0 flex overflow-hidden fill-[#F5A524]" style={{ width: `${pct}%` }}>
        {[0, 1, 2, 3, 4].map((i) => <span key={i} className="shrink-0">{star}</span>)}
      </span>
    </span>
  );
}
