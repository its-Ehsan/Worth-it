/** Renders admin-editable plain text: "## Heading", blank-line paragraphs, and "- " bullet lists. No raw HTML is ever injected. */
export default function Doc({ text }: { text: string }) {
  const blocks = text.replace(/\r/g, "").split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  return (
    <div className="prose-doc">
      {blocks.map((b, i) => {
        const lines = b.split("\n");
        const out: React.ReactNode[] = [];
        let bullets: string[] = [];
        const flush = () => { if (bullets.length) { out.push(<ul key={`u${out.length}`} className="mb-4 list-disc space-y-1.5 pl-5 text-ink/80">{bullets.map((x, k) => <li key={k}>{x}</li>)}</ul>); bullets = []; } };
        lines.forEach((l) => {
          if (l.startsWith("## ")) { flush(); out.push(<h2 key={`h${out.length}`}>{l.slice(3)}</h2>); }
          else if (l.startsWith("- ")) bullets.push(l.slice(2));
          else { flush(); out.push(<p key={`p${out.length}`}>{l}</p>); }
        });
        flush();
        return <div key={i}>{out}</div>;
      })}
    </div>
  );
}
