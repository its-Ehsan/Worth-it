import Image from "next/image";

interface Props { src: string; alt: string; sizes?: string; priority?: boolean; className?: string; fill?: boolean }

/** Optimised image wrapper. SVGs (demo art) and relative paths skip the optimiser; uploaded photos use next/image. */
export default function Img({ src, alt, sizes = "(max-width: 768px) 50vw, 25vw", priority, className = "" }: Props) {
  if (!src) return <div className={`absolute inset-0 bg-line/60 ${className}`} aria-hidden />;
  const plain = src.endsWith(".svg") || src.startsWith("data:");
  if (plain) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={alt} loading={priority ? "eager" : "lazy"} decoding="async" className={`absolute inset-0 h-full w-full object-cover ${className}`} />;
  }
  return <Image src={src} alt={alt} fill sizes={sizes} priority={priority} className={`object-cover ${className}`} />;
}
