"use client";
import { useRef, useState } from "react";
import { uploadImageAction } from "@/app/admin/actions";

/** Single image upload. Writes the resulting URL into a hidden input named `name`. */
export default function ImageField({ name, label, folder, initial = "", hint }: { name: string; label: string; folder: "homepage" | "categories" | "brand" | "products"; initial?: string; hint?: string }) {
  const [url, setUrl] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const input = useRef<HTMLInputElement>(null);

  async function pick(file: File | undefined) {
    if (!file) return;
    setBusy(true); setErr("");
    const fd = new FormData(); fd.set("file", file); fd.set("folder", folder);
    const r = await uploadImageAction(fd);
    setBusy(false);
    if (r.ok) setUrl(r.url); else setErr(r.error);
    if (input.current) input.current.value = "";
  }
  return (
    <div>
      <span className="a-label">{label}</span>
      <input type="hidden" name={name} value={url} />
      <div className="flex items-center gap-3">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-line bg-paper">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {url ? <img src={url} alt="" className="h-full w-full object-cover" /> : <span className="text-[10px] text-muted">No image</span>}
        </div>
        <div className="space-y-1.5">
          <div className="flex gap-2">
            <button type="button" className="a-btn-ghost !px-3 !py-1.5" onClick={() => input.current?.click()} disabled={busy}>{busy ? "Uploading…" : url ? "Replace" : "Upload"}</button>
            {url && <button type="button" className="a-btn-ghost !px-3 !py-1.5" onClick={() => setUrl("")}>Remove</button>}
          </div>
          {hint && <p className="text-[11px] text-muted">{hint}</p>}
          {err && <p className="text-xs font-medium text-red-600" role="alert">{err}</p>}
        </div>
      </div>
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp,image/avif" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
    </div>
  );
}
