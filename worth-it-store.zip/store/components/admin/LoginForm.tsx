"use client";
import { signIn } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "./ActionForm";

export default function LoginForm() {
  return (
    <ActionForm action={signIn} className="a-card space-y-4">
      <div><label className="a-label" htmlFor="l-email">Email</label><input id="l-email" name="email" type="email" required autoComplete="email" className="a-input !py-2.5" /></div>
      <div><label className="a-label" htmlFor="l-pass">Password</label><input id="l-pass" name="password" type="password" required autoComplete="current-password" className="a-input !py-2.5" /></div>
      <SubmitButton pendingText="Signing in…" className="a-btn w-full !py-2.5">Sign in</SubmitButton>
    </ActionForm>
  );
}
