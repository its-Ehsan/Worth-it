import type { OrderStatus } from "@/lib/types";

const TONE: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800", confirmed: "bg-sky-100 text-sky-800", processing: "bg-indigo-100 text-indigo-800", shipped: "bg-violet-100 text-violet-800",
  delivered: "bg-emerald-100 text-emerald-800", cancelled: "bg-red-100 text-red-700", returned: "bg-orange-100 text-orange-800",
  approved: "bg-emerald-100 text-emerald-800", rejected: "bg-red-100 text-red-700", live: "bg-emerald-100 text-emerald-800", draft: "bg-gray-200 text-gray-700",
};
export function Badge({ s, children }: { s: OrderStatus | string; children?: React.ReactNode }) {
  return <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-bold capitalize ${TONE[s] ?? "bg-gray-100 text-gray-700"}`}>{children ?? s}</span>;
}
export function PageHeader({ title, sub, children }: { title: string; sub?: string; children?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="text-2xl font-extrabold sm:text-3xl">{title}</h1>{sub && <p className="mt-1 text-sm text-muted">{sub}</p>}</div>{children}
    </div>
  );
}
export function Empty({ title, text }: { title: string; text?: string }) {
  return <div className="rounded-xl border border-dashed border-line bg-white p-10 text-center"><p className="font-bold">{title}</p>{text && <p className="mt-1 text-sm text-muted">{text}</p>}</div>;
}
export const fmtDate = (iso: string) => new Date(iso).toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
