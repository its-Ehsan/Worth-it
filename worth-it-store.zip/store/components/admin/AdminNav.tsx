"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "@/app/admin/actions";

const ITEMS = [
  ["/admin", "Dashboard"], ["/admin/products", "Products"], ["/admin/categories", "Categories"], ["/admin/orders", "Orders"], ["/admin/customers", "Customers"],
  ["/admin/reviews", "Reviews"], ["/admin/coupons", "Coupons"], ["/admin/homepage", "Homepage"], ["/admin/settings", "Settings"],
];

export default function AdminNav({ email }: { email: string }) {
  const path = usePathname();
  const active = (h: string) => (h === "/admin" ? path === "/admin" : path.startsWith(h));
  return (
    <>
      <aside className="sticky top-0 z-40 hidden h-screen w-60 shrink-0 flex-col border-r border-line bg-white p-4 md:flex">
        <p className="mb-6 px-3 font-display text-lg font-extrabold">Admin</p>
        <nav className="flex-1 space-y-1" aria-label="Admin">
          {ITEMS.map(([h, l]) => <Link key={h} href={h} className={`block rounded-lg px-3 py-2.5 text-sm font-semibold transition ${active(h) ? "bg-deep text-white" : "text-ink/70 hover:bg-paper"}`}>{l}</Link>)}
        </nav>
        <div className="space-y-2 border-t border-line pt-4">
          <Link href="/" target="_blank" className="a-btn-ghost w-full">View website ↗</Link>
          <p className="truncate px-1 text-xs text-muted">{email}</p>
          <form action={signOut}><button className="a-btn-ghost w-full">Sign out</button></form>
        </div>
      </aside>
      <header className="sticky top-0 z-40 border-b border-line bg-white md:hidden">
        <div className="flex items-center justify-between px-4 py-2.5"><p className="font-display font-extrabold">Admin</p>
          <div className="flex gap-2"><Link href="/" target="_blank" className="a-btn-ghost !px-3 !py-1.5">Site ↗</Link><form action={signOut}><button className="a-btn-ghost !px-3 !py-1.5">Sign out</button></form></div></div>
        <nav className="no-scrollbar flex gap-1 overflow-x-auto px-3 pb-2" aria-label="Admin">
          {ITEMS.map(([h, l]) => <Link key={h} href={h} className={`shrink-0 rounded-full px-3.5 py-2 text-sm font-semibold ${active(h) ? "bg-deep text-white" : "bg-paper text-ink/70"}`}>{l}</Link>)}
        </nav>
      </header>
    </>
  );
}
