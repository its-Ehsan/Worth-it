"use client";
import { useRef, useState } from "react";
import { uploadImageAction } from "@/app/admin/actions";
import type { ProductImage } from "@/lib/types";

/** Multi-image uploader with reordering. The first image is the cover. */
export default function ImageManager({ initial, name = "images_json" }: { initial: ProductImage[]; name?: string }) {
  const [images, setImages] = useState<ProductImage[]>(initial);
  const [busy, setBusy] = useState(0);
  const [err, setErr] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState<number | null>(null);

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setErr("");
    const list = Array.from(files).slice(0, Math.max(0, 12 - images.length));
    setBusy(list.length);
    const added: ProductImage[] = [];
    for (const f of list) {
      const fd = new FormData(); fd.set("file", f); fd.set("folder", "products");
      const r = await uploadImageAction(fd);
      if (r.ok) added.push({ url: r.url, alt: "" }); else setErr(`${f.name}: ${r.error}`);
      setBusy((b) => b - 1);
    }
    setImages((cur) => [...cur, ...added]);
    if (input.current) input.current.value = "";
  }
  const move = (from: number, to: number) => setImages((cur) => { if (to < 0 || to >= cur.length) return cur; const n = [...cur]; const [x] = n.splice(from, 1); n.splice(to, 0, x); return n; });

  return (
    <div>
      <input type="hidden" name={name} value={JSON.stringify(images)} />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {images.map((im, i) => (
          <div key={im.url + i} draggable onDragStart={() => setDrag(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (drag !== null) move(drag, i); setDrag(null); }}
            className="group relative overflow-hidden rounded-xl border border-line bg-white">
            <div className="aspect-square bg-paper">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={im.url} alt="" className="h-full w-full object-cover" /></div>
            {i === 0 && <span className="absolute left-2 top-2 rounded-full bg-deep px-2 py-0.5 text-[10px] font-bold text-white">Cover</span>}
            <div className="flex items-center justify-between gap-1 border-t border-line p-1.5">
              <div className="flex gap-1">
                <button type="button" onClick={() => move(i, i - 1)} disabled={i === 0} className="h-8 w-8 rounded-md border border-line text-sm hover:bg-paper disabled:opacity-30" aria-label="Move earlier">←</button>
                <button type="button" onClick={() => move(i, i + 1)} disabled={i === images.length - 1} className="h-8 w-8 rounded-md border border-line text-sm hover:bg-paper disabled:opacity-30" aria-label="Move later">→</button>
              </div>
              <button type="button" onClick={() => setImages((c) => c.filter((_, k) => k !== i))} className="h-8 rounded-md border border-red-200 px-2 text-xs font-semibold text-red-700 hover:bg-red-50">Remove</button>
            </div>
          </div>
        ))}
        {Array.from({ length: busy }).map((_, i) => <div key={`b${i}`} className="skeleton aspect-square" />)}
        {images.length + busy < 12 && (
          <button type="button" onClick={() => input.current?.click()} className="flex aspect-square flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-line text-sm font-semibold text-muted transition hover:border-brand hover:text-brand">
            <span className="text-2xl leading-none">+</span>Add images
          </button>
        )}
      </div>
      <p className="mt-2 text-xs text-muted">JPG, PNG, WebP or AVIF, up to 5 MB each, max 12. Drag to reorder or use the arrows. The first image is the cover.</p>
      {err && <p role="alert" className="mt-2 text-sm font-medium text-red-600">{err}</p>}
      <input ref={input} type="file" multiple accept="image/jpeg,image/png,image/webp,image/avif" className="hidden" onChange={(e) => upload(e.target.files)} />
    </div>
  );
}
