"use client";
import { useEffect, useRef, useState } from "react";
import { useFormState, useFormStatus } from "react-dom";
import type { Result } from "@/app/admin/actions";

export function SubmitButton({ children, pendingText = "Saving…", className = "a-btn" }: { children: React.ReactNode; pendingText?: string; className?: string }) {
  const { pending } = useFormStatus();
  return <button type="submit" disabled={pending} className={className}>{pending ? pendingText : children}</button>;
}

/** Form wrapper that shows success / error feedback from a server action. */
export default function ActionForm({ action, children, className = "", resetOnSuccess = false }: {
  action: (prev: Result, fd: FormData) => Promise<Result>; children: React.ReactNode; className?: string; resetOnSuccess?: boolean;
}) {
  const [state, formAction] = useFormState(action, {} as Result);
  const [show, setShow] = useState(false);
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => { if (resetOnSuccess && state.ok && state.ts) ref.current?.reset(); }, [resetOnSuccess, state.ok, state.ts]);
  useEffect(() => { if (state.ts) { setShow(true); const t = setTimeout(() => setShow(false), state.ok ? 4000 : 9000); return () => clearTimeout(t); } }, [state.ts, state.ok]);
  return (
    <form action={formAction} className={className} ref={ref}>
      {children}
      {show && (state.message || state.error) && (
        <div role={state.ok ? "status" : "alert"} className={`fixed bottom-5 left-1/2 z-[70] -translate-x-1/2 animate-fadeUp rounded-xl px-5 py-3 text-sm font-semibold shadow-xl ${state.ok ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
          {state.ok ? state.message : state.error}
        </div>
      )}
    </form>
  );
}
