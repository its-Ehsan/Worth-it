"use client";
import Link from "next/link";
import { useState } from "react";
import { saveProduct } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "./ActionForm";
import ImageManager from "./ImageManager";
import type { Category, Product, Spec, Variant } from "@/lib/types";

interface Props { product: Product | null; categories: Category[]; others: { id: string; name: string }[] }

export default function ProductForm({ product: p, categories, others }: Props) {
  const [price, setPrice] = useState(p ? String(p.price) : "");
  const [was, setWas] = useState(p?.compare_at_price ? String(p.compare_at_price) : "");
  const [pct, setPct] = useState("");
  const [specs, setSpecs] = useState<Spec[]>(p?.specs?.length ? p.specs : []);
  const [variants, setVariants] = useState<{ name: string; options: string }[]>((p?.variants ?? []).map((v: Variant) => ({ name: v.name, options: v.options.join(", ") })));
  const [related, setRelated] = useState<string[]>(p?.related_ids ?? []);
  const [relQ, setRelQ] = useState("");
  const [status, setStatus] = useState<string>(p?.stock_status ?? "in_stock");

  function applyDiscount(v: string) {
    setPct(v);
    const d = Number(v), w = Number(was);
    if (d > 0 && d < 100 && w > 0) setPrice(String(Math.round(w * (1 - d / 100))));
  }
  const livePct = Number(was) > Number(price) && Number(price) > 0 ? Math.round((1 - Number(price) / Number(was)) * 100) : 0;
  const Check = ({ name, label, def }: { name: string; label: string; def: boolean }) => (
    <label className="flex min-h-[40px] cursor-pointer items-center gap-2.5 text-sm"><input type="checkbox" name={name} defaultChecked={def} className="h-4 w-4 accent-[rgb(var(--brand))]" />{label}</label>
  );

  return (
    <ActionForm action={saveProduct} className="space-y-5 pb-24">
      {p && <input type="hidden" name="id" value={p.id} />}
      <section className="a-card space-y-4">
        <h2 className="font-bold">Basics</h2>
        <div><label className="a-label" htmlFor="pf-name">Product name</label><input id="pf-name" name="name" required defaultValue={p?.name} className="a-input" /></div>
        <div><label className="a-label" htmlFor="pf-short">Short description</label><input id="pf-short" name="short_description" maxLength={300} defaultValue={p?.short_description} className="a-input" placeholder="One line that sells it" /></div>
        <div><label className="a-label" htmlFor="pf-desc">Full description</label><textarea id="pf-desc" name="description" rows={7} defaultValue={p?.description} className="a-input" placeholder="Leave a blank line between paragraphs." /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="a-label" htmlFor="pf-cat">Category</label>
            <select id="pf-cat" name="category_id" defaultValue={p?.category_id ?? ""} className="a-input"><option value="">No category</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
          <div><label className="a-label" htmlFor="pf-sku">SKU</label><input id="pf-sku" name="sku" defaultValue={p?.sku ?? ""} className="a-input" /></div>
        </div>
        <div><label className="a-label" htmlFor="pf-tags">Tags <span className="font-normal text-muted">(comma separated, used by search)</span></label><input id="pf-tags" name="tags" defaultValue={p?.tags.join(", ")} className="a-input" placeholder="earbuds, wireless, anc" /></div>
        {p && <div><label className="a-label" htmlFor="pf-slug">Page URL</label><div className="flex items-center gap-2 text-sm text-muted">/product/<input id="pf-slug" name="slug" defaultValue={p.slug} className="a-input !w-auto flex-1" /></div></div>}
      </section>

      <section className="a-card"><h2 className="mb-3 font-bold">Images</h2><ImageManager initial={p?.images ?? []} /></section>

      <section className="a-card space-y-4">
        <h2 className="font-bold">Price</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <div><label className="a-label" htmlFor="pf-was">Previous price</label><input id="pf-was" name="compare_at_price" inputMode="decimal" value={was} onChange={(e) => setWas(e.target.value)} className="a-input" placeholder="Optional" /></div>
          <div><label className="a-label" htmlFor="pf-pct">Discount % <span className="font-normal text-muted">(helper)</span></label><input id="pf-pct" inputMode="decimal" value={pct} onChange={(e) => applyDiscount(e.target.value)} className="a-input" placeholder="e.g. 20" disabled={!Number(was)} /></div>
          <div><label className="a-label" htmlFor="pf-price">Selling price</label><input id="pf-price" name="price" required inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} className="a-input" /></div>
        </div>
        <p className="text-xs text-muted">{livePct > 0 ? `Customers will see ${livePct}% off.` : "Enter a previous price higher than the selling price to show a discount."}</p>
      </section>

      <section className="a-card space-y-4">
        <h2 className="font-bold">Stock</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="a-label" htmlFor="pf-status">Availability</label>
            <select id="pf-status" name="stock_status" value={status} onChange={(e) => setStatus(e.target.value)} className="a-input"><option value="in_stock">In stock</option><option value="out_of_stock">Out of stock</option></select></div>
          <div><label className="a-label" htmlFor="pf-qty">Quantity available</label><input id="pf-qty" name="stock_qty" inputMode="numeric" defaultValue={p?.stock_qty ?? ""} className="a-input" placeholder="Leave empty for “Available”" /></div>
        </div>
        <p className="text-xs text-muted">Type a number (for example 7) to count stock down with every order, or leave it empty to simply show “In stock”. Reaching 0 marks it sold out automatically.</p>
        <Check name="cod_available" label="Cash on delivery available" def={p?.cod_available ?? true} />
      </section>

      <section className="a-card space-y-3">
        <h2 className="font-bold">Features</h2>
        <textarea name="features" rows={5} defaultValue={p?.features.join("\n")} className="a-input" placeholder={"One highlight per line\n32 hours of battery\nIPX4 sweat resistance"} />
      </section>

      <section className="a-card space-y-3">
        <div className="flex items-center justify-between"><h2 className="font-bold">Specifications</h2><button type="button" className="a-btn-ghost" onClick={() => setSpecs([...specs, { label: "", value: "" }])}>Add row</button></div>
        <input type="hidden" name="specs_json" value={JSON.stringify(specs.filter((s) => s.label.trim() && s.value.trim()))} />
        {specs.length === 0 && <p className="text-sm text-muted">No specifications yet.</p>}
        {specs.map((s, i) => (
          <div key={i} className="flex gap-2">
            <input className="a-input" placeholder="Label (Battery)" aria-label="Spec label" value={s.label} onChange={(e) => setSpecs(specs.map((x, k) => (k === i ? { ...x, label: e.target.value } : x)))} />
            <input className="a-input" placeholder="Value (10 days)" aria-label="Spec value" value={s.value} onChange={(e) => setSpecs(specs.map((x, k) => (k === i ? { ...x, value: e.target.value } : x)))} />
            <button type="button" className="a-btn-ghost" aria-label="Remove row" onClick={() => setSpecs(specs.filter((_, k) => k !== i))}>×</button>
          </div>))}
      </section>

      <section className="a-card space-y-3">
        <div className="flex items-center justify-between"><h2 className="font-bold">Variants</h2>{variants.length < 3 && <button type="button" className="a-btn-ghost" onClick={() => setVariants([...variants, { name: "", options: "" }])}>Add variant</button>}</div>
        <input type="hidden" name="variants_json" value={JSON.stringify(variants.map((v) => ({ name: v.name.trim(), options: v.options.split(",").map((o) => o.trim()).filter(Boolean) })).filter((v) => v.name && v.options.length))} />
        {variants.length === 0 && <p className="text-sm text-muted">No variants. Add one for things like Colour or Size. Customers choose before adding to cart.</p>}
        {variants.map((v, i) => (
          <div key={i} className="flex gap-2">
            <input className="a-input !w-40" placeholder="Name (Colour)" aria-label="Variant name" value={v.name} onChange={(e) => setVariants(variants.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} />
            <input className="a-input" placeholder="Options, comma separated (Black, White)" aria-label="Variant options" value={v.options} onChange={(e) => setVariants(variants.map((x, k) => (k === i ? { ...x, options: e.target.value } : x)))} />
            <button type="button" className="a-btn-ghost" aria-label="Remove variant" onClick={() => setVariants(variants.filter((_, k) => k !== i))}>×</button>
          </div>))}
      </section>

      <section className="a-card space-y-3">
        <h2 className="font-bold">Related products</h2>
        <input type="hidden" name="related_json" value={JSON.stringify(related)} />
        <input className="a-input" placeholder="Search products to relate…" value={relQ} onChange={(e) => setRelQ(e.target.value)} aria-label="Search related products" />
        <div className="max-h-48 divide-y divide-line overflow-y-auto rounded-lg border border-line">
          {others.filter((o) => o.id !== p?.id && o.name.toLowerCase().includes(relQ.toLowerCase())).map((o) => (
            <label key={o.id} className="flex min-h-[40px] cursor-pointer items-center gap-2.5 px-3 text-sm hover:bg-paper">
              <input type="checkbox" className="h-4 w-4 accent-[rgb(var(--brand))]" checked={related.includes(o.id)} onChange={(e) => setRelated(e.target.checked ? [...related, o.id] : related.filter((x) => x !== o.id))} />{o.name}</label>))}
          {others.length <= 1 && <p className="p-3 text-sm text-muted">Add more products to link them here.</p>}
        </div>
        <p className="text-xs text-muted">If you pick none, similar products from the same category are shown automatically.</p>
      </section>

      <section className="a-card space-y-1">
        <h2 className="mb-1 font-bold">Where it appears</h2>
        <div className="grid gap-x-6 sm:grid-cols-2">
          <Check name="is_featured" label="Featured product" def={p?.is_featured ?? false} />
          <Check name="is_trending" label="Trending" def={p?.is_trending ?? false} />
          <Check name="is_best_seller" label="Best seller" def={p?.is_best_seller ?? false} />
          <Check name="is_new_arrival" label="New arrival" def={p?.is_new_arrival ?? false} />
        </div>
      </section>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 p-3 backdrop-blur md:left-60">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3">
          <label className="flex cursor-pointer items-center gap-2.5 text-sm font-semibold"><input type="checkbox" name="is_published" defaultChecked={p?.is_published ?? true} className="h-5 w-5 accent-[rgb(var(--brand))]" />Published (visible on the website)</label>
          <div className="flex gap-2"><Link href="/admin/products" className="a-btn-ghost">Back</Link><SubmitButton>{p ? "Save changes" : "Create product"}</SubmitButton></div>
        </div>
      </div>
    </ActionForm>
  );
}
