-- =====================================================================
-- Gadget store schema. Run once in Supabase -> SQL Editor.
-- Security model: RLS is ON everywhere. The public (anon) key can only
-- READ published catalog data + approved reviews + settings. Every write
-- goes through server actions using the service-role key after an admin
-- check, so the browser can never modify products/orders directly.
-- =====================================================================
create extension if not exists "pgcrypto";

create table if not exists admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now()
);

create table if not exists settings (
  id int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now()
);
insert into settings (id, data) values (1, '{}') on conflict do nothing;

create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text default '',
  image_url text,
  sort_order int default 0,
  is_demo boolean default false,
  created_at timestamptz default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  short_description text default '',
  description text default '',
  price numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2),
  stock_status text not null default 'in_stock' check (stock_status in ('in_stock','out_of_stock')),
  stock_qty int,                       -- null = "Available" (untracked), number = exact count
  sku text,
  category_id uuid references categories(id) on delete set null,
  tags text[] default '{}',
  images jsonb default '[]'::jsonb,    -- [{url, alt}] in display order
  specs jsonb default '[]'::jsonb,     -- [{label, value}]
  features text[] default '{}',
  variants jsonb default '[]'::jsonb,  -- [{name, options: []}]
  related_ids uuid[] default '{}',
  is_featured boolean default false,
  is_trending boolean default false,
  is_best_seller boolean default false,
  is_new_arrival boolean default false,
  is_published boolean default false,
  cod_available boolean default true,
  sold_count int default 0,
  is_demo boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists products_published_idx on products (is_published, created_at desc);
create index if not exists products_category_idx on products (category_id);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_name text not null,
  phone text not null,
  district text not null,
  area text not null,
  address text not null,
  notes text default '',
  items jsonb not null,                -- snapshot: [{product_id,name,sku,price,qty,variant,image}]
  subtotal numeric(12,2) not null,
  discount numeric(12,2) not null default 0,
  delivery_fee numeric(12,2) not null default 0,
  total numeric(12,2) not null,
  coupon_code text,
  payment_method text not null default 'cod',
  status text not null default 'pending'
    check (status in ('pending','confirmed','processing','shipped','delivered','cancelled','returned')),
  admin_note text default '',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists orders_created_idx on orders (created_at desc);
create index if not exists orders_phone_idx on orders (phone);

create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  order_number text,
  author_name text not null,
  rating int not null check (rating between 1 and 5),
  body text not null,
  image_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  is_demo boolean default false,
  created_at timestamptz default now()
);
create index if not exists reviews_product_idx on reviews (product_id, status);

create table if not exists coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  type text not null check (type in ('fixed','percent')),
  value numeric(12,2) not null check (value > 0),
  min_order numeric(12,2) default 0,
  max_discount numeric(12,2),
  expires_at timestamptz,
  usage_limit int,
  used_count int default 0,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- ---------- Row Level Security ----------
alter table admins enable row level security;
alter table settings enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table reviews enable row level security;
alter table coupons enable row level security;

drop policy if exists "public read settings" on settings;
create policy "public read settings" on settings for select using (true);
drop policy if exists "public read categories" on categories;
create policy "public read categories" on categories for select using (true);
drop policy if exists "public read published products" on products;
create policy "public read published products" on products for select using (is_published = true);
drop policy if exists "public read approved reviews" on reviews;
create policy "public read approved reviews" on reviews for select using (status = 'approved');
-- admins, orders, coupons: no policies => inaccessible to anon/authenticated keys.
-- The service-role key (server only) bypasses RLS.

-- ---------- Storage ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 5242880, array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/avif'];
-- Public bucket: anyone can VIEW files. Uploads only happen server-side (service role).
