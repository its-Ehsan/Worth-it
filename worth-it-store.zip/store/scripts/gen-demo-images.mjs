// Generates abstract studio-style placeholder images for DEMO products only.
// Real product photos are uploaded from the admin panel (Supabase Storage).
import fs from "node:fs";
const out = "public/demo";
fs.mkdirSync(out, { recursive: true });

const shapes = {
  earbuds: (c) => `<g><rect x="250" y="190" width="70" height="170" rx="35" fill="${c.body}"/><circle cx="285" cy="215" r="22" fill="${c.hi}"/><rect x="480" y="190" width="70" height="170" rx="35" fill="${c.body}"/><circle cx="515" cy="215" r="22" fill="${c.hi}"/><rect x="300" y="380" width="200" height="110" rx="55" fill="${c.dark}"/><rect x="380" y="418" width="40" height="8" rx="4" fill="${c.hi}"/></g>`,
  watch: (c) => `<g><rect x="340" y="90" width="120" height="130" rx="30" fill="${c.dark}"/><rect x="340" y="420" width="120" height="130" rx="30" fill="${c.dark}"/><rect x="300" y="190" width="200" height="220" rx="56" fill="${c.body}"/><rect x="316" y="206" width="168" height="188" rx="44" fill="#0b0f19"/><circle cx="400" cy="300" r="52" fill="none" stroke="${c.hi}" stroke-width="10"/><rect x="396" y="262" width="8" height="40" rx="4" fill="${c.hi}"/></g>`,
  powerbank: (c) => `<g><rect x="290" y="130" width="220" height="360" rx="34" fill="${c.body}"/><rect x="320" y="170" width="160" height="14" rx="7" fill="${c.hi}"/><circle cx="330" cy="430" r="7" fill="${c.hi}"/><circle cx="360" cy="430" r="7" fill="${c.hi}"/><circle cx="390" cy="430" r="7" fill="${c.hi}"/><circle cx="420" cy="430" r="7" fill="${c.dark}"/><rect x="340" y="250" width="120" height="70" rx="12" fill="${c.dark}"/></g>`,
  pad: (c) => `<g><rect x="250" y="250" width="300" height="300" rx="150" fill="${c.body}"/><circle cx="400" cy="400" r="95" fill="${c.dark}"/><circle cx="400" cy="400" r="40" fill="${c.hi}"/><rect x="330" y="150" width="140" height="70" rx="16" fill="${c.dark}"/></g>`,
  keyboard: (c) => { let k = ""; for (let r = 0; r < 4; r++) for (let i = 0; i < 12; i++) k += `<rect x="${215 + i * 31}" y="${260 + r * 40}" width="26" height="32" rx="6" fill="${r === 0 && i > 8 ? c.hi : c.dark}"/>`; return `<g><rect x="190" y="235" width="420" height="190" rx="22" fill="${c.body}"/>${k}</g>`; },
  mouse: (c) => `<g><path d="M400 150c85 0 130 70 130 170v70c0 85-55 130-130 130s-130-45-130-130v-70c0-100 45-170 130-170z" fill="${c.body}"/><rect x="394" y="170" width="12" height="90" rx="6" fill="${c.dark}"/><rect x="380" y="200" width="40" height="20" rx="10" fill="${c.hi}"/></g>`,
  speaker: (c) => `<g><rect x="290" y="150" width="220" height="360" rx="70" fill="${c.body}"/><circle cx="400" cy="270" r="62" fill="${c.dark}"/><circle cx="400" cy="270" r="26" fill="${c.hi}"/><circle cx="400" cy="410" r="40" fill="${c.dark}"/></g>`,
  charger: (c) => `<g><rect x="320" y="150" width="14" height="60" rx="4" fill="${c.dark}"/><rect x="466" y="150" width="14" height="60" rx="4" fill="${c.dark}"/><rect x="290" y="205" width="220" height="250" rx="40" fill="${c.body}"/><rect x="360" y="400" width="80" height="22" rx="11" fill="${c.dark}"/><circle cx="400" cy="300" r="28" fill="${c.hi}"/></g>`,
  webcam: (c) => `<g><rect x="360" y="440" width="80" height="90" rx="10" fill="${c.dark}"/><rect x="300" y="520" width="200" height="22" rx="11" fill="${c.dark}"/><circle cx="400" cy="300" r="140" fill="${c.body}"/><circle cx="400" cy="300" r="92" fill="${c.dark}"/><circle cx="400" cy="300" r="46" fill="#0b0f19"/><circle cx="380" cy="280" r="12" fill="${c.hi}"/></g>`,
  lamp: (c) => `<g><rect x="300" y="520" width="170" height="26" rx="13" fill="${c.dark}"/><path d="M385 520 L345 330 L470 180" stroke="${c.body}" stroke-width="22" fill="none" stroke-linecap="round" stroke-linejoin="round"/><rect x="430" y="150" width="140" height="60" rx="30" transform="rotate(-35 500 180)" fill="${c.body}"/><ellipse cx="520" cy="228" rx="46" ry="14" transform="rotate(-35 520 228)" fill="${c.hi}" opacity=".85"/></g>`,
  tracker: (c) => `<g><circle cx="400" cy="320" r="130" fill="${c.body}"/><circle cx="400" cy="320" r="98" fill="${c.dark}"/><circle cx="400" cy="320" r="30" fill="${c.hi}"/><circle cx="400" cy="180" r="18" fill="none" stroke="${c.dark}" stroke-width="10"/></g>`,
  hub: (c) => `<g><rect x="230" y="270" width="340" height="120" rx="30" fill="${c.body}"/>${[0,1,2,3,4].map(i=>`<rect x="${265+i*62}" y="312" width="44" height="22" rx="6" fill="${c.dark}"/>`).join("")}<rect x="370" y="390" width="60" height="120" rx="14" fill="${c.dark}"/><circle cx="400" cy="290" r="6" fill="${c.hi}"/></g>`,
};

const products = [
  ["earbuds","earbuds",222],["watch","watch",215],["powerbank","powerbank",160],["pad","pad",270],
  ["keyboard","keyboard",250],["mouse","mouse",200],["speaker","speaker",18],["charger","charger",150],
  ["webcam","webcam",190],["lamp","lamp",38],["tracker","tracker",180],["hub","hub",205],
];

function svg(kind, hue, variant) {
  // Dark purple studio look to match the storefront theme; `hue` only tints the accent so each product feels distinct.
  const bg1 = variant === 1 ? "#1B0F36" : "#150B2B";
  const bg2 = variant === 2 ? "#341566" : "#2A1254";
  const accent = `hsl(${262 + ((hue % 40) - 20)} 90% 66%)`;
  const c = { body: variant === 2 ? "#2A2140" : "#ECE8F7", dark: variant === 2 ? "#0F0A1F" : "#2B2342", hi: accent };
  const t = variant === 1 ? "translate(400 330) scale(0.78) translate(-400 -330)" : variant === 2 ? "translate(400 330) rotate(-8) scale(1.05) translate(-400 -330)" : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" role="img"><defs><radialGradient id="g" cx="50%" cy="38%" r="75%"><stop offset="0" stop-color="${bg2}"/><stop offset="1" stop-color="${bg1}"/></radialGradient><radialGradient id="glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${accent}" stop-opacity=".45"/><stop offset="1" stop-color="${accent}" stop-opacity="0"/></radialGradient><filter id="s" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="26" stdDeviation="24" flood-color="#000" flood-opacity=".55"/></filter></defs><rect width="800" height="800" fill="url(#g)"/><ellipse cx="400" cy="420" rx="330" ry="300" fill="url(#glow)"/><ellipse cx="400" cy="610" rx="240" ry="24" fill="${accent}" opacity=".28"/><g filter="url(#s)" transform="${t}">${shapes[kind](c)}</g></svg>`;
}

for (const [slug, kind, hue] of products) {
  for (let v = 0; v < 3; v++) fs.writeFileSync(`${out}/${slug}-${v + 1}.svg`, svg(kind, hue, v));
}
// Category + hero placeholders
for (const [name, hue] of [["audio",222],["wearables",215],["power",160],["desk",250]]) {
  fs.writeFileSync(`${out}/cat-${name}.svg`, svg(name === "audio" ? "earbuds" : name === "wearables" ? "watch" : name === "power" ? "powerbank" : "keyboard", hue, 1));
}
console.log("generated");
