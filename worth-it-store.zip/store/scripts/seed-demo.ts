/** Usage: npm run seed:demo   |   npm run clear:demo
 *  Copies lib/demo-data.ts into Supabase flagged is_demo=true. `clear:demo` deletes only is_demo rows. */
import { config } from "dotenv";
import { createClient } from "@supabase/supabase-js";
import { DEMO_CATEGORIES, DEMO_PRODUCTS, DEMO_REVIEWS } from "../lib/demo-data";

config({ path: ".env.local" });
const url = process.env.NEXT_PUBLIC_SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error("Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env.local"); process.exit(1); }
const db = createClient(url, key, { auth: { persistSession: false } });

async function main() {
  if (process.argv.includes("--clear")) {
    await db.from("reviews").delete().eq("is_demo", true);
    const p = await db.from("products").delete().eq("is_demo", true);
    const c = await db.from("categories").delete().eq("is_demo", true);
    if (p.error || c.error) throw p.error ?? c.error;
    console.log("Demo data removed. Your own products, categories and orders were not touched.");
    return;
  }
  const c = await db.from("categories").upsert(DEMO_CATEGORIES.map((x) => ({ ...x, is_demo: true })), { onConflict: "id" });
  if (c.error) throw c.error;
  const p = await db.from("products").upsert(DEMO_PRODUCTS.map(({ rating_avg, rating_count, ...x }) => ({ ...x, is_demo: true })), { onConflict: "id" });
  if (p.error) throw p.error;
  const r = await db.from("reviews").upsert(DEMO_REVIEWS.map((x) => ({ ...x, is_demo: true })), { onConflict: "id" });
  if (r.error) throw r.error;
  console.log(`Seeded ${DEMO_CATEGORIES.length} categories, ${DEMO_PRODUCTS.length} products, ${DEMO_REVIEWS.length} reviews (all flagged demo).`);
}
main().catch((e) => { console.error(e); process.exit(1); });
