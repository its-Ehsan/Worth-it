/** Usage: npm run create-admin -- you@example.com "a-strong-password"
 *  Creates (or promotes) a Supabase Auth user and adds them to the admins table. */
import { config } from "dotenv";
import { createClient } from "@supabase/supabase-js";

config({ path: ".env.local" });
const [email, password] = process.argv.slice(2);
const url = process.env.NEXT_PUBLIC_SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error("Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env.local"); process.exit(1); }
if (!email || !password || password.length < 10) { console.error('Usage: npm run create-admin -- you@example.com "password-at-least-10-chars"'); process.exit(1); }
const db = createClient(url, key, { auth: { persistSession: false } });

async function main() {
  let id: string | undefined;
  const created = await db.auth.admin.createUser({ email, password, email_confirm: true });
  if (created.data.user) id = created.data.user.id;
  else {
    const list = await db.auth.admin.listUsers({ page: 1, perPage: 1000 });
    const u = list.data.users.find((x) => x.email?.toLowerCase() === email.toLowerCase());
    if (!u) throw created.error ?? new Error("Could not create user");
    id = u.id;
    await db.auth.admin.updateUserById(id, { password });
  }
  const { error } = await db.from("admins").upsert({ user_id: id });
  if (error) throw error;
  console.log(`Admin ready: ${email}. Sign in at /admin/login`);
}
main().catch((e) => { console.error(e.message ?? e); process.exit(1); });
