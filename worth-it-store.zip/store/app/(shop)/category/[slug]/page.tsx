import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCategories, getProducts, getSettings } from "@/lib/data";
import { filterProducts, parseFilters } from "@/lib/catalog";
import Listing from "@/components/shop/Listing";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const cat = (await getCategories()).find((c) => c.slug === params.slug);
  if (!cat) return { title: "Category not found" };
  return { title: cat.name, description: cat.description || `Shop ${cat.name} with cash on delivery across Bangladesh.`, alternates: { canonical: `/category/${cat.slug}` } };
}

export default async function CategoryPage({ params, searchParams }: { params: { slug: string }; searchParams: Record<string, string | string[] | undefined> }) {
  const [products, cats, s] = await Promise.all([getProducts(), getCategories(), getSettings()]);
  const cat = cats.find((c) => c.slug === params.slug);
  if (!cat) notFound();
  const list = filterProducts(products, cats, { ...parseFilters(searchParams), q: undefined, category: cat.slug });
  return <Listing title={cat.name} sub={cat.description} products={list} categories={cats} basePath={`/category/${cat.slug}`} symbol={s.delivery.currency_symbol} showCategory={false}
    breadcrumb={[{ href: "/", label: "Home" }, { href: "/shop", label: "Shop" }]} />;
}
