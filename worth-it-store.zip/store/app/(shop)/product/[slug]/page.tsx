import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCategories, getProductBySlug, getProducts, getReviews, getSettings } from "@/lib/data";
import { relatedProducts } from "@/lib/catalog";
import Gallery from "@/components/shop/Gallery";
import PurchasePanel from "@/components/shop/PurchasePanel";
import ProductCard from "@/components/shop/ProductCard";
import ReviewForm from "@/components/shop/ReviewForm";
import RecentlyViewed from "@/components/shop/RecentlyViewed";
import Stars from "@/components/ui/Stars";
import { discountPercent, isPurchasable, siteUrl, stockLabel, timeAgo } from "@/lib/utils";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProductBySlug(params.slug);
  if (!p) return { title: "Product not found" };
  const desc = p.short_description || p.description.slice(0, 155);
  const img = p.images[0]?.url;
  return {
    title: p.name, description: desc, alternates: { canonical: `/product/${p.slug}` },
    openGraph: { type: "website", title: p.name, description: desc, url: `${siteUrl()}/product/${p.slug}`, images: img ? [{ url: img.startsWith("http") ? img : `${siteUrl()}${img}` }] : undefined },
  };
}

export default async function ProductPage({ params }: Props) {
  const [p, all, cats, s] = await Promise.all([getProductBySlug(params.slug), getProducts(), getCategories(), getSettings()]);
  if (!p) notFound();
  const reviews = await getReviews(p.id);
  const cat = cats.find((c) => c.id === p.category_id);
  const related = relatedProducts(all, p, 4);
  const sym = s.delivery.currency_symbol;
  const money = (n: number) => `${sym}${Math.round(n).toLocaleString("en-US")}`;
  const off = discountPercent(p.price, p.compare_at_price);
  const stock = stockLabel(p);
  const abs = (u: string) => (u.startsWith("http") ? u : `${siteUrl()}${u}`);

  const ld = {
    "@context": "https://schema.org", "@type": "Product", name: p.name, description: p.short_description || p.description.slice(0, 300),
    image: p.images.map((i) => abs(i.url)), sku: p.sku || undefined, brand: { "@type": "Brand", name: s.brand.name },
    category: cat?.name,
    offers: { "@type": "Offer", url: `${siteUrl()}/product/${p.slug}`, priceCurrency: "BDT", price: p.price, itemCondition: "https://schema.org/NewCondition",
      availability: isPurchasable(p) ? "https://schema.org/InStock" : "https://schema.org/OutOfStock" },
    ...(reviews.length ? { aggregateRating: { "@type": "AggregateRating", ratingValue: p.rating_avg, reviewCount: p.rating_count } } : {}),
  };
  const crumbs = { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [
    { "@type": "ListItem", position: 1, name: "Home", item: siteUrl() }, { "@type": "ListItem", position: 2, name: "Shop", item: `${siteUrl()}/shop` },
    ...(cat ? [{ "@type": "ListItem", position: 3, name: cat.name, item: `${siteUrl()}/category/${cat.slug}` }] : []),
    { "@type": "ListItem", position: cat ? 4 : 3, name: p.name } ] };

  const paragraphs = p.description.split(/\n{2,}/).filter(Boolean);
  const mini = all.map((x) => ({ slug: x.slug, name: x.name, price: x.price, image: x.images[0]?.url ?? "" }));

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(crumbs) }} />
      <div className="container-x pt-2 sm:pt-6">
        <nav aria-label="Breadcrumb" className="mb-4 text-[13px] text-muted">
          <Link href="/" className="hover:text-ink">Home</Link> / <Link href="/shop" className="hover:text-ink">Shop</Link>
          {cat && <> / <Link href={`/category/${cat.slug}`} className="hover:text-ink">{cat.name}</Link></>}
        </nav>
        <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr] lg:gap-14">
          <Gallery images={p.images} name={p.name} />
          <div>
            <div className="flex flex-wrap items-center gap-2">
              {p.is_new_arrival && <span className="rounded-full bg-deep px-2.5 py-1 text-[11px] font-bold text-white">New</span>}
              {p.is_best_seller && <span className="rounded-full bg-brand/20 px-2.5 py-1 text-[11px] font-bold text-brand-soft">Best seller</span>}
            </div>
            <h1 className="mt-2 text-3xl font-extrabold leading-tight sm:text-4xl">{p.name}</h1>
            {(p.rating_count ?? 0) > 0 && (
              <a href="#reviews" className="mt-2 inline-flex items-center gap-2 text-sm"><Stars value={p.rating_avg ?? 0} size={16} /><span className="font-semibold">{p.rating_avg?.toFixed(1)}</span><span className="text-muted underline-offset-2 hover:underline">{p.rating_count} reviews</span></a>
            )}
            <p className="mt-3 text-[16px] leading-relaxed text-muted">{p.short_description}</p>
            <div className="mt-5 flex flex-wrap items-baseline gap-3">
              <span className="font-display text-4xl font-extrabold">{money(p.price)}</span>
              {p.compare_at_price && p.compare_at_price > p.price && <span className="text-lg text-muted line-through">{money(p.compare_at_price)}</span>}
              {off > 0 && <span className="rounded-full bg-brand-2/15 px-2.5 py-1 text-[13px] font-bold text-brand-2">Save {off}%</span>}
            </div>
            <p className={`mt-2 inline-flex items-center gap-2 text-sm font-semibold ${stock.tone === "out" ? "text-red-400" : stock.tone === "low" ? "text-amber-400" : "text-emerald-400"}`}>
              <span className="h-2 w-2 rounded-full bg-current" />{stock.text}</p>
            <div className="mt-6"><PurchasePanel product={p} /></div>
            {p.sku && <p className="mt-4 text-xs text-muted">SKU: {p.sku}</p>}
          </div>
        </div>

        <div className="mt-14 grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:gap-14">
          <div>
            <h2 className="mb-4 text-2xl font-extrabold">About this product</h2>
            <div className="max-w-[68ch] space-y-4 text-[16px] leading-relaxed text-ink/80">{paragraphs.map((t, i) => <p key={i}>{t}</p>)}</div>
            {p.features.length > 0 && (
              <><h3 className="mb-3 mt-8 text-xl font-bold">Highlights</h3>
                <ul className="grid gap-2.5 sm:grid-cols-2">{p.features.map((f, i) => (
                  <li key={i} className="flex gap-3 rounded-xl border border-line bg-surface p-3.5 text-[15px]"><span className="mt-0.5 font-bold text-brand-soft" aria-hidden>✓</span>{f}</li>))}</ul></>
            )}
          </div>
          {p.specs.length > 0 && (
            <div><h2 className="mb-4 text-2xl font-extrabold">Specifications</h2>
              <dl className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                {p.specs.map((sp, i) => (<div key={i} className="grid grid-cols-[130px_1fr] gap-3 px-4 py-3 text-[14px] sm:grid-cols-[170px_1fr]"><dt className="font-semibold text-muted">{sp.label}</dt><dd>{sp.value}</dd></div>))}
              </dl></div>
          )}
        </div>

        <section id="reviews" className="mt-16 scroll-mt-24" aria-labelledby="rev-h">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div><h2 id="rev-h" className="text-2xl font-extrabold sm:text-3xl">Customer reviews</h2>
              {(p.rating_count ?? 0) > 0 && <p className="mt-1 flex items-center gap-2 text-sm text-muted"><Stars value={p.rating_avg ?? 0} size={16} />{p.rating_avg?.toFixed(1)} from {p.rating_count} {p.rating_count === 1 ? "review" : "reviews"}</p>}</div>
          </div>
          <div className="grid gap-6 lg:grid-cols-[1fr_420px]">
            <div>
              {reviews.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-line bg-surface p-8 text-center"><p className="font-display text-lg font-bold">No reviews yet</p><p className="mt-1 text-sm text-muted">Bought this? Be the first to tell others how it is.</p></div>
              ) : (
                <ul className="space-y-4">{reviews.map((r) => (
                  <li key={r.id} className="rounded-2xl border border-line bg-surface p-5">
                    <div className="flex items-center justify-between gap-3"><Stars value={r.rating} size={15} /><span className="text-xs text-muted">{timeAgo(r.created_at)}</span></div>
                    <p className="mt-2.5 text-[15px] leading-relaxed">{r.body}</p>
                    {r.image_url && /* eslint-disable-next-line @next/next/no-img-element */ <img src={r.image_url} alt={`Photo from ${r.author_name}`} loading="lazy" className="mt-3 h-24 w-24 rounded-xl object-cover" />}
                    <p className="mt-3 text-[13px]"><span className="font-semibold">{r.author_name}</span> <span className="text-emerald-400">· Verified buyer</span></p>
                  </li>))}</ul>
              )}
            </div>
            <div><ReviewForm productId={p.id} productName={p.name} /></div>
          </div>
        </section>
      </div>

      {related.length > 0 && (
        <section className="container-x pt-16 sm:pt-20" aria-labelledby="rel-h">
          <h2 id="rel-h" className="mb-6 text-2xl font-extrabold sm:text-3xl">You might also like</h2>
          <div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-5 lg:grid-cols-4">{related.map((r) => <ProductCard key={r.id} p={r} symbol={sym} />)}</div>
        </section>
      )}
      <RecentlyViewed currentSlug={p.slug} all={mini} />
      <div className="h-24 lg:hidden" aria-hidden />
    </>
  );
}
