import type { Metadata } from "next";
import Link from "next/link";
import { getSettings } from "@/lib/data";
import { serviceClient } from "@/lib/supabase/admin";
import { isSupabaseConfigured } from "@/lib/supabase/public";
import type { Order } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export const metadata: Metadata = { title: "Order confirmed", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function OrderConfirmation({ params }: { params: { orderNumber: string } }) {
  const s = await getSettings();
  const num = decodeURIComponent(params.orderNumber).toUpperCase().slice(0, 30);
  let order: Order | null = null;
  if (isSupabaseConfigured() && process.env.SUPABASE_SERVICE_ROLE_KEY && !num.startsWith("DEMO-")) {
    const { data } = await serviceClient().from("orders").select("*").eq("order_number", num).maybeSingle();
    order = data as Order | null;
  }
  const sym = s.delivery.currency_symbol;
  const wa = s.contact.whatsapp.replace(/\D/g, "");
  return (
    <div className="container-x py-10 sm:py-16">
      <div className="mx-auto max-w-2xl">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-white"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 13l4 4L19 7" /></svg></div>
        <h1 className="mt-5 text-4xl font-extrabold sm:text-5xl">Thank you, your order is in.</h1>
        <p className="mt-3 text-muted">We&apos;ll call or message you to confirm shortly. Keep your order number handy.</p>
        <div className="mt-6 rounded-2xl border border-line bg-surface p-5">
          <p className="text-sm text-muted">Order number</p>
          <p className="font-display text-3xl font-extrabold tracking-wide">{num}</p>
          {num.startsWith("DEMO-") && <p className="mt-2 text-xs text-amber-700">Preview mode: this order was not saved.</p>}
        </div>
        {order && (
          <div className="mt-4 rounded-2xl border border-line bg-surface p-5">
            <ul className="divide-y divide-line">
              {order.items.map((i, k) => (
                <li key={k} className="flex justify-between gap-4 py-2.5 text-[15px]"><span>{i.name}{i.variant ? ` (${i.variant})` : ""} × {i.qty}</span><span className="font-semibold">{formatPrice(i.price * i.qty, sym)}</span></li>))}
            </ul>
            <dl className="mt-3 space-y-1.5 border-t border-line pt-3 text-[15px]">
              {order.discount > 0 && <div className="flex justify-between text-emerald-400"><dt>Discount</dt><dd>−{formatPrice(order.discount, sym)}</dd></div>}
              <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd>{order.delivery_fee ? formatPrice(order.delivery_fee, sym) : "Free"}</dd></div>
              <div className="flex justify-between font-display text-xl font-extrabold"><dt>Total to pay on delivery</dt><dd>{formatPrice(order.total, sym)}</dd></div>
            </dl>
            <p className="mt-4 text-[14px] text-muted">Delivering to {order.customer_name}, {order.area}, {order.district}.</p>
          </div>
        )}
        <div className="mt-5 rounded-2xl bg-deep p-5 text-[15px] text-white/85">
          <h2 className="font-display text-lg font-bold text-white">What happens next</h2>
          <ol className="mt-2 list-decimal space-y-1 pl-5"><li>We confirm your order by phone or message.</li><li>We check and pack your gadget.</li><li>The courier delivers in {s.delivery.outside_dhaka_eta} (Dhaka: {s.delivery.inside_dhaka_eta}). Pay in cash and check the parcel on arrival.</li></ol>
        </div>
        <div className="mt-6 flex flex-wrap gap-3"><Link href="/shop" className="btn-primary">Continue shopping</Link>
          {wa && <a href={`https://wa.me/${wa}?text=${encodeURIComponent(`Hi, my order number is ${num}`)}`} target="_blank" rel="noopener noreferrer" className="btn-ghost">Message us on WhatsApp</a>}</div>
      </div>
    </div>
  );
}
