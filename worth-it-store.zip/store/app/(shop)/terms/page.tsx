import type { Metadata } from "next";
import { getSettings } from "@/lib/data";
import Doc from "@/components/ui/Doc";

export const metadata: Metadata = { title: "Terms & conditions", description: "The terms that apply when you order from us." };

export default async function Page() {
  const s = await getSettings();
  return (
    <div className="container-x py-8 sm:py-14">
      <article className="mx-auto max-w-2xl">
        <h1 className="mb-8 text-4xl font-extrabold sm:text-5xl">Terms & conditions</h1>
        <Doc text={s.pages.terms} />
      </article>
    </div>
  );
}
