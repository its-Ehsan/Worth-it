import Link from "next/link";
import { getCategories, getProducts, getReviews, getSettings } from "@/lib/data";
import ProductCard from "@/components/shop/ProductCard";
import Section from "@/components/shop/Section";
import Discovery, { type DiscoveryItem } from "@/components/shop/Discovery";
import Img from "@/components/ui/Img";
import Reveal from "@/components/ui/Reveal";
import Stars from "@/components/ui/Stars";
import { discountPercent, isPurchasable } from "@/lib/utils";

export default async function HomePage() {
  const [s, products, cats, reviews] = await Promise.all([getSettings(), getProducts(), getCategories(), getReviews()]);
  const h = s.homepage;
  const sym = s.delivery.currency_symbol;
  const money = (n: number) => `${sym}${Math.round(n).toLocaleString("en-US")}`;
  const live = products.filter((p) => isPurchasable(p));
  const pick = <T,>(arr: T[], n: number) => arr.slice(0, n);

  const heroProduct = products.find((p) => p.id === h.hero.product_id) ?? live.find((p) => p.is_featured) ?? live[0];
  const trending = pick(products.filter((p) => p.is_trending), 8);
  const fresh = pick(products.filter((p) => p.is_new_arrival), 4);
  const best = pick([...products.filter((p) => p.is_best_seller)].sort((a, b) => b.sold_count - a.sold_count), 4);
  const counts = new Map<string, number>();
  products.forEach((p) => p.category_id && counts.set(p.category_id, (counts.get(p.category_id) ?? 0) + 1));

  const items: DiscoveryItem[] = products.map((p) => ({
    slug: p.slug, name: p.name, price: p.price, compare: p.compare_at_price, image: p.images[0]?.url ?? "", categoryId: p.category_id,
    rating: p.rating_avg ?? 0, ratingCount: p.rating_count ?? 0, sold: p.sold_count, buyable: isPurchasable(p), short: p.short_description,
  }));
  const off = heroProduct ? discountPercent(heroProduct.price, heroProduct.compare_at_price) : 0;

  return (
    <>
      {/* HERO */}
      <section className="container-x pt-2 sm:pt-4">
        <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[radial-gradient(120%_120%_at_85%_0%,rgb(var(--brand)/.35),rgb(var(--deep))_55%)] text-white sm:rounded-[36px]">
          <div aria-hidden className="pointer-events-none absolute -right-24 -top-24 h-[420px] w-[420px] rounded-full bg-brand/40 blur-[110px]" />
          <div className="relative grid items-center gap-8 p-6 sm:p-10 lg:grid-cols-[1.05fr_1fr] lg:gap-12 lg:p-14">
            <div className="animate-fadeUp">
              {h.hero.eyebrow && <p className="mb-4 inline-block rounded-full border border-white/20 px-3.5 py-1.5 text-[13px] font-semibold text-white/80">{h.hero.eyebrow}</p>}
              <h1 className="text-[40px] font-extrabold leading-[1.02] sm:text-6xl lg:text-[68px]">{h.hero.title}</h1>
              <p className="mt-5 max-w-lg text-base leading-relaxed text-white/70 sm:text-lg">{h.hero.subtitle}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href={h.hero.cta_link || "/shop"} className="btn-primary">{h.hero.cta_text}</Link>
                {h.hero.secondary_text && <Link href={h.hero.secondary_link || "/shop"} className="btn border border-white/25 text-white hover:bg-white/10">{h.hero.secondary_text}</Link>}
              </div>
              <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-[13px] font-medium text-white/70">
                <li>Cash on delivery</li><li>{s.delivery.outside_dhaka_eta} delivery</li><li>7-day returns</li>
              </ul>
            </div>
            <div className="relative mx-auto aspect-square w-full max-w-[520px] animate-fadeIn">
              <div className="absolute inset-0 overflow-hidden rounded-[28px] bg-white/5 ring-1 ring-white/10">
                <Img src={h.hero.image || heroProduct?.images[0]?.url || ""} alt={heroProduct?.name ?? s.brand.name} priority sizes="(max-width:1024px) 90vw, 520px" />
              </div>
              {heroProduct && (
                <Link href={`/product/${heroProduct.slug}`} className="group absolute -bottom-3 left-3 right-3 flex items-center justify-between gap-3 rounded-2xl bg-white p-3.5 text-[#0B0714] shadow-2xl transition hover:-translate-y-0.5 sm:left-auto sm:right-[-14px] sm:w-[300px]">
                  <span className="min-w-0"><span className="block truncate font-display text-[17px] font-bold">{heroProduct.name}</span>
                    <span className="mt-0.5 flex items-baseline gap-2"><span className="font-bold">{money(heroProduct.price)}</span>
                      {off > 0 && <span className="rounded-full bg-brand-2/15 px-2 py-0.5 text-[11px] font-bold text-brand-2">{off}% off</span>}</span></span>
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-deep text-white transition group-hover:bg-brand" aria-hidden>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg></span>
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* EXPLORE */}
      {cats.length > 0 && (
        <Section title="Explore gadgets" sub="Start with what you need. Everything is checked before it ships.">
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 lg:grid-rows-2">
            {cats.slice(0, 5).map((c, i) => (
              <Reveal key={c.id} delay={i * 60} className={i === 0 ? "col-span-2 lg:row-span-2" : ""}>
                <Link href={`/category/${c.slug}`} className={`group relative block overflow-hidden rounded-3xl bg-line/50 ${i === 0 ? "aspect-[4/3] lg:aspect-auto lg:h-full lg:min-h-[420px]" : "aspect-[4/3]"}`}>
                  <Img src={c.image_url ?? ""} alt="" sizes={i === 0 ? "(max-width:1024px) 100vw, 50vw" : "(max-width:1024px) 50vw, 25vw"} className="transition duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-4 text-white sm:p-5">
                    <h3 className={`font-bold ${i === 0 ? "text-2xl sm:text-3xl" : "text-lg sm:text-xl"}`}>{c.name}</h3>
                    <p className="mt-0.5 text-[13px] text-white/75">{counts.get(c.id) ?? 0} products</p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </Section>
      )}

      {/* TRENDING */}
      {h.sections.trending && trending.length > 0 && (
        <Section title="Trending now" sub="What people are adding to their carts this week." href="/shop?sort=best">
          <div className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-2 sm:-mx-6 sm:px-6 lg:mx-0 lg:grid lg:grid-cols-4 lg:gap-5 lg:overflow-visible lg:px-0">
            {trending.slice(0, 8).map((p, i) => (
              <div key={p.id} className="w-[62%] shrink-0 snap-start sm:w-[34%] lg:w-auto"><ProductCard p={p} symbol={sym} priority={i < 2} /></div>
            ))}
          </div>
        </Section>
      )}

      {/* BANNERS */}
      {h.banners.length > 0 && (
        <section className="container-x pt-16 sm:pt-24">
          <div className="grid gap-4 md:grid-cols-2">
            {h.banners.slice(0, 2).map((b, i) => (
              <Reveal key={i} delay={i * 80}>
                <Link href={b.link || "/shop"} className={`group relative flex min-h-[220px] items-end overflow-hidden rounded-3xl p-6 text-white sm:min-h-[280px] sm:p-8 ${i === 0 ? "bg-brand" : "bg-deep"}`}>
                  {b.image && <Img src={b.image} alt="" sizes="(max-width:768px) 100vw, 50vw" className="opacity-60 transition duration-700 group-hover:scale-105" />}
                  <div aria-hidden className={`absolute -right-10 -top-10 h-48 w-48 rounded-full blur-3xl ${i === 0 ? "bg-white/25" : "bg-brand/50"}`} />
                  <div className="relative max-w-sm"><h3 className="text-2xl font-extrabold sm:text-3xl">{b.title}</h3><p className="mt-2 text-[15px] text-white/80">{b.subtitle}</p>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-[14px] font-semibold underline-offset-4 group-hover:underline">Shop now</span></div>
                </Link>
              </Reveal>
            ))}
          </div>
        </section>
      )}

      {/* NEW */}
      {h.sections.new_arrivals && fresh.length > 0 && (
        <Section title="New arrivals" sub="Just landed. Be the first to pick them up." href="/shop?sort=newest">
          <div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-5 lg:grid-cols-4">{fresh.map((p) => <ProductCard key={p.id} p={p} symbol={sym} />)}</div>
        </Section>
      )}

      {/* DISCOVERY */}
      {h.sections.discovery && products.length > 0 && (
        <Section title="Find your fit" sub="Pick a category and a budget. We'll show what sells best in that range.">
          <Discovery items={items} categories={cats.map((c) => ({ id: c.id, name: c.name }))} symbol={sym} />
        </Section>
      )}

      {/* BEST SELLERS */}
      {h.sections.best_sellers && best.length > 0 && (
        <Section title="Best sellers" sub="The ones people come back to buy again." href="/shop?sort=best">
          <div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-5 lg:grid-cols-4">{best.map((p, i) => <ProductCard key={p.id} p={p} symbol={sym} rank={i + 1} />)}</div>
        </Section>
      )}

      {/* WHY US */}
      <section className="container-x pt-16 sm:pt-24">
        <div className="rounded-[28px] border border-line bg-surface p-6 sm:p-10">
          <h2 className="max-w-md text-[28px] font-extrabold leading-tight sm:text-4xl">Why people order from {s.brand.name}</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {h.trust.map((t, i) => (<Reveal key={i} delay={i * 70}><h3 className="text-lg font-bold">{t.title}</h3><p className="mt-1.5 text-[15px] leading-relaxed text-muted">{t.text}</p></Reveal>))}
          </div>
          {h.stats.length > 0 && (
            <dl className="mt-10 grid grid-cols-1 gap-4 border-t border-line pt-8 sm:grid-cols-3">
              {h.stats.map((st, i) => (<div key={i}><dt className="sr-only">{st.label}</dt><dd className="font-display text-4xl font-extrabold text-brand-soft">{st.value}</dd><p className="mt-0.5 text-sm text-muted">{st.label}</p></div>))}
            </dl>
          )}
        </div>
      </section>

      {/* REVIEWS */}
      {h.sections.reviews && reviews.length > 0 && (
        <Section title="From real orders" sub="Reviews come from customers who bought and received the product.">
          <div className="grid gap-4 md:grid-cols-3">
            {reviews.slice(0, 3).map((r, i) => (
              <Reveal key={r.id} delay={i * 80}>
                <figure className="flex h-full flex-col rounded-2xl border border-line bg-surface p-5">
                  <Stars value={r.rating} size={16} />
                  <blockquote className="mt-3 flex-1 text-[15px] leading-relaxed">{r.body}</blockquote>
                  <figcaption className="mt-4 text-[13px]"><span className="font-semibold">{r.author_name}</span>{r.product_name && <span className="text-muted">, bought {r.product_name}</span>}</figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </Section>
      )}

      {/* FAQ */}
      {h.sections.faq && s.pages.faq.length > 0 && (
        <Section title="Quick answers" href="/faq" cta="All questions">
          <div className="divide-y divide-line rounded-2xl border border-line bg-surface">
            {s.pages.faq.slice(0, 5).map((f, i) => (
              <details key={i} className="group px-5 py-4 [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">{f.q}
                  <span className="text-xl leading-none text-muted transition group-open:rotate-45" aria-hidden>+</span></summary>
                <p className="mt-2 max-w-2xl text-[15px] leading-relaxed text-muted">{f.a}</p>
              </details>
            ))}
          </div>
        </Section>
      )}

      {/* FINAL CTA */}
      <section className="container-x pt-16 sm:pt-24">
        <div className="relative overflow-hidden rounded-[28px] bg-brand p-8 text-white sm:rounded-[36px] sm:p-14">
          <div aria-hidden className="absolute -bottom-20 -right-10 h-72 w-72 rounded-full bg-white/20 blur-3xl" />
          <h2 className="relative max-w-xl text-3xl font-extrabold leading-tight sm:text-5xl">{h.final_cta.title}</h2>
          <p className="relative mt-3 max-w-lg text-white/85">{h.final_cta.subtitle}</p>
          <Link href={h.final_cta.button_link || "/shop"} className="btn-light relative mt-7">{h.final_cta.button_text}</Link>
        </div>
      </section>
    </>
  );
}
