import type { Metadata } from "next";
import { getSettings } from "@/lib/data";

export const metadata: Metadata = { title: "Contact us", description: "Call, message or email us. We reply fast." };

export default async function ContactPage() {
  const s = await getSettings(); const c = s.contact;
  const wa = c.whatsapp.replace(/\D/g, "");
  const rows = [
    wa && { label: "WhatsApp", value: "Message us", href: `https://wa.me/${wa}`, external: true },
    c.phone && { label: "Call", value: c.phone, href: `tel:${c.phone}` },
    c.email && { label: "Email", value: c.email, href: `mailto:${c.email}` },
    c.facebook && { label: "Facebook", value: "Send a message", href: c.facebook, external: true },
    c.instagram && { label: "Instagram", value: "Send a message", href: c.instagram, external: true },
  ].filter(Boolean) as { label: string; value: string; href: string; external?: boolean }[];
  return (
    <div className="container-x py-8 sm:py-14">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-4xl font-extrabold sm:text-5xl">Contact us</h1>
        <p className="mt-3 text-muted">Questions about a product or an order? Reach us any of these ways. {c.hours && `We're here ${c.hours.toLowerCase()}.`}</p>
        <ul className="mt-8 grid gap-3 sm:grid-cols-2">
          {rows.map((r) => (
            <li key={r.label}><a href={r.href} {...(r.external ? { target: "_blank", rel: "noopener noreferrer" } : {})} className="card block p-5 transition hover:border-ink/40">
              <span className="text-sm text-muted">{r.label}</span><span className="mt-0.5 block font-display text-lg font-bold">{r.value}</span></a></li>))}
        </ul>
        {c.address && <p className="mt-8 text-[15px]"><span className="font-semibold">Address:</span> {c.address}</p>}
      </div>
    </div>
  );
}
