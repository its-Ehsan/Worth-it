import type { Metadata } from "next";
import { getSettings } from "@/lib/data";
import Doc from "@/components/ui/Doc";

export const metadata: Metadata = { title: "About us", description: "Who we are and what we care about." };

export default async function Page() {
  const s = await getSettings();
  return (
    <div className="container-x py-8 sm:py-14">
      <article className="mx-auto max-w-2xl">
        <h1 className="mb-8 text-4xl font-extrabold sm:text-5xl">About us</h1>
        <Doc text={s.pages.about} />
      </article>
    </div>
  );
}
