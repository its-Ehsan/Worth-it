import type { Metadata } from "next";
import Link from "next/link";
import { getCategories, getProducts, getSettings } from "@/lib/data";
import { filterProducts, parseFilters } from "@/lib/catalog";
import Listing from "@/components/shop/Listing";
import ProductCard from "@/components/shop/ProductCard";

export const metadata: Metadata = { title: "Search", robots: { index: false, follow: true } };

export default async function SearchPage({ searchParams }: { searchParams: Record<string, string | string[] | undefined> }) {
  const [products, cats, s] = await Promise.all([getProducts(), getCategories(), getSettings()]);
  const f = parseFilters(searchParams);
  const q = f.q?.trim() ?? "";
  const list = q ? filterProducts(products, cats, f) : [];
  const sym = s.delivery.currency_symbol;
  const empty = (
    <div className="rounded-3xl border border-dashed border-line bg-surface p-8 text-center sm:p-12">
      <p className="font-display text-2xl font-bold">{q ? `No results for “${q}”` : "Search for a gadget"}</p>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted">{q ? "Check the spelling or try a broader word, like “charger” or “speaker”. You can also clear the filters." : "Type a product, category or feature in the search box."}</p>
      <div className="mt-5 flex flex-wrap justify-center gap-2">{cats.map((c) => <Link key={c.id} href={`/category/${c.slug}`} className="chip">{c.name}</Link>)}</div>
      {products.length > 0 && (
        <div className="mt-10 text-left"><h2 className="mb-4 text-lg font-bold">Popular right now</h2>
          <div className="grid grid-cols-2 gap-x-3 gap-y-6 md:grid-cols-4">{products.filter((p) => p.is_best_seller || p.is_trending).slice(0, 4).map((p) => <ProductCard key={p.id} p={p} symbol={sym} />)}</div></div>
      )}
    </div>
  );
  return <Listing title={q ? `Results for “${q}”` : "Search"} products={list} categories={cats} basePath="/search" symbol={sym} empty={empty} />;
}
