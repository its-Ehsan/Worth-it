import type { Metadata } from "next";
import Link from "next/link";
import { getSettings } from "@/lib/data";

export const metadata: Metadata = { title: "FAQ", description: "Answers about ordering, delivery, cash on delivery and returns." };

export default async function FaqPage() {
  const s = await getSettings();
  const ld = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: s.pages.faq.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) };
  return (
    <div className="container-x py-8 sm:py-14">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-8 text-4xl font-extrabold sm:text-5xl">Frequently asked questions</h1>
        <div className="divide-y divide-line rounded-2xl border border-line bg-surface">
          {s.pages.faq.map((f, i) => (
            <details key={i} className="group px-5 py-4 [&_summary::-webkit-details-marker]:hidden">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">{f.q}<span className="text-xl leading-none text-muted transition group-open:rotate-45" aria-hidden>+</span></summary>
              <p className="mt-2 text-[15px] leading-relaxed text-muted">{f.a}</p>
            </details>))}
        </div>
        <p className="mt-8 text-muted">Still have a question? <Link href="/contact" className="font-semibold text-brand-soft underline">Contact us</Link>.</p>
      </div>
    </div>
  );
}
