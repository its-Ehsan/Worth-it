import type { Metadata } from "next";
import { getCategories, getProducts, getSettings } from "@/lib/data";
import { filterProducts, parseFilters } from "@/lib/catalog";
import Listing from "@/components/shop/Listing";

export const metadata: Metadata = { title: "Shop all gadgets", description: "Browse every gadget: audio, wearables, power and desk gear. Cash on delivery across Bangladesh." };

export default async function ShopPage({ searchParams }: { searchParams: Record<string, string | string[] | undefined> }) {
  const [products, cats, s] = await Promise.all([getProducts(), getCategories(), getSettings()]);
  const list = filterProducts(products, cats, { ...parseFilters(searchParams), q: undefined });
  return <Listing title="All gadgets" sub="Everything we sell, in one place." products={list} categories={cats} basePath="/shop" symbol={s.delivery.currency_symbol} />;
}
