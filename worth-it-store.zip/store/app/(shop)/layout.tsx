import Link from "next/link";
import { getCategories, getSettings, isDemoMode } from "@/lib/data";
import { CartProvider } from "@/components/shop/CartProvider";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import CartDrawer from "@/components/layout/CartDrawer";
import MobileBar from "@/components/layout/MobileBar";

export default async function ShopLayout({ children }: { children: React.ReactNode }) {
  const [s, cats] = await Promise.all([getSettings(), getCategories()]);
  const a = s.homepage.announcement;
  const config = {
    brandName: s.brand.name, symbol: s.delivery.currency_symbol, insideFee: s.delivery.inside_dhaka_fee, outsideFee: s.delivery.outside_dhaka_fee,
    freeAbove: s.delivery.free_above, codNote: s.delivery.cod_note, insideEta: s.delivery.inside_dhaka_eta, outsideEta: s.delivery.outside_dhaka_eta,
  };
  const org = {
    "@context": "https://schema.org", "@type": "Organization", name: s.brand.name, url: process.env.NEXT_PUBLIC_SITE_URL, logo: s.brand.logo_url || undefined,
    sameAs: [s.contact.facebook, s.contact.instagram, s.contact.youtube, s.contact.tiktok].filter(Boolean),
    contactPoint: s.contact.phone ? [{ "@type": "ContactPoint", telephone: s.contact.phone, contactType: "customer service", areaServed: "BD" }] : undefined,
  };
  return (
    <CartProvider config={config}>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[60] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2">Skip to content</a>
      {a.enabled && a.text && (
        <div className="border-b border-white/10 bg-deep text-center text-[13px] font-medium text-white">
          {a.link ? <Link href={a.link} className="block px-4 py-2.5 hover:underline">{a.text}</Link> : <p className="px-4 py-2.5">{a.text}</p>}
        </div>
      )}
      <Header brandName={s.brand.name} logoUrl={s.brand.logo_url} showName={s.brand.logo_with_name} categories={cats.map((c) => ({ name: c.name, slug: c.slug }))} />
      {isDemoMode() && (
        <p className="bg-amber-500/15 px-4 py-1.5 text-center text-xs font-medium text-amber-200">Preview mode: showing demo products. Connect Supabase to use the admin panel and real orders.</p>
      )}
      <main id="main" className="min-h-[60vh] pb-4">{children}</main>
      <Footer s={s} categories={cats} />
      <CartDrawer />
      <MobileBar whatsapp={s.contact.whatsapp} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(org) }} />
    </CartProvider>
  );
}
