import type { Metadata } from "next";
import { getSettings } from "@/lib/data";
import Doc from "@/components/ui/Doc";

export const metadata: Metadata = { title: "Privacy policy", description: "How we handle your personal information." };

export default async function Page() {
  const s = await getSettings();
  return (
    <div className="container-x py-8 sm:py-14">
      <article className="mx-auto max-w-2xl">
        <h1 className="mb-8 text-4xl font-extrabold sm:text-5xl">Privacy policy</h1>
        <Doc text={s.pages.privacy} />
      </article>
    </div>
  );
}
