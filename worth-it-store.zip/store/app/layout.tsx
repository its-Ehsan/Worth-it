import type { Metadata, Viewport } from "next";
import "./globals.css";
import { getSettings } from "@/lib/data";
import { hexToRgbTriplet, lightenHex, siteUrl } from "@/lib/utils";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  const title = s.seo.title || `${s.brand.name}: ${s.brand.tagline}`;
  return {
    metadataBase: new URL(siteUrl()),
    title: { default: title, template: `%s | ${s.brand.name}` },
    description: s.seo.description,
    applicationName: s.brand.name,
    icons: s.brand.favicon_url ? { icon: s.brand.favicon_url } : undefined,
    openGraph: {
      type: "website", siteName: s.brand.name, title, description: s.seo.description,
      images: s.brand.og_image ? [s.brand.og_image] : undefined,
    },
    twitter: { card: "summary_large_image" },
  };
}

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0B0714" };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const s = await getSettings();
  const vars = `:root{--brand:${hexToRgbTriplet(s.brand.primary_color, "124 58 237")};--brand-2:${hexToRgbTriplet(s.brand.secondary_color, "192 38 211")};--brand-soft:${hexToRgbTriplet(lightenHex(s.brand.primary_color, 0.4), "167 139 250")};--font-display:'Bricolage Grotesque';--font-body:'Manrope'}`;
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Manrope:wght@400..800&display=swap"
        />
        <style dangerouslySetInnerHTML={{ __html: vars }} />
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
