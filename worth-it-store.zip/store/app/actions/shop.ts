"use server";
import { randomBytes } from "node:crypto";
import { revalidateTag } from "next/cache";
import { z } from "zod";
import { serviceClient } from "@/lib/supabase/admin";
import { isSupabaseConfigured } from "@/lib/supabase/public";
import { mergeSettings } from "@/lib/default-settings";
import { DISTRICTS, BD_PHONE, normalizePhone } from "@/lib/bd";
import { applyCoupon } from "@/lib/coupons";
import { uploadImage } from "@/lib/upload";
import { DEMO_PRODUCTS } from "@/lib/demo-data";
import type { Coupon, OrderItem, Product } from "@/lib/types";

const hasDb = () => isSupabaseConfigured() && !!process.env.SUPABASE_SERVICE_ROLE_KEY;

export async function validateCoupon(code: string, subtotal: number) {
  const c = String(code ?? "").trim().toUpperCase().slice(0, 40);
  if (!c) return { ok: false as const, error: "Enter a coupon code." };
  if (!hasDb()) return { ok: false as const, error: "Coupons need the database connected." };
  const { data } = await serviceClient().from("coupons").select("*").ilike("code", c).maybeSingle();
  const r = applyCoupon(data as Coupon | null, Math.max(0, Number(subtotal) || 0));
  return r.ok ? { ok: true as const, discount: r.discount, code: c } : r;
}

const OrderInput = z.object({
  name: z.string().trim().min(2, "Enter your full name").max(80),
  phone: z.string().trim().refine((v) => BD_PHONE.test(v.replace(/[\s-]/g, "")), "Enter a valid Bangladeshi mobile number, like 01712345678"),
  district: z.string().refine((d) => DISTRICTS.includes(d), "Choose your district"),
  area: z.string().trim().min(2, "Enter your area or thana").max(80),
  address: z.string().trim().min(6, "Enter your full address").max(300),
  notes: z.string().trim().max(500).optional().default(""),
  coupon: z.string().trim().max(40).optional().default(""),
  website: z.string().max(0).optional(), // honeypot: real people leave this empty
  items: z.array(z.object({ productId: z.string().uuid(), qty: z.number().int().min(1).max(50), variant: z.string().max(120).default("") })).min(1, "Your cart is empty").max(30),
});

export type OrderResult = { ok: true; orderNumber: string } | { ok: false; error: string; field?: string };

function orderNumber() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const b = randomBytes(8);
  return "ORD-" + Array.from(b, (x) => A[x % A.length]).join("");
}

export async function placeOrder(raw: unknown): Promise<OrderResult> {
  const parsed = OrderInput.safeParse(raw);
  if (!parsed.success) {
    const i = parsed.error.issues[0];
    return { ok: false, error: i.message, field: String(i.path[0] ?? "") };
  }
  const input = parsed.data;
  if (input.website) return { ok: false, error: "Something went wrong. Please try again." };
  const phone = normalizePhone(input.phone);

  // Preview mode (no database): simulate so the full flow can be demoed.
  if (!hasDb()) {
    const demo = DEMO_PRODUCTS.filter((p) => input.items.some((i) => i.productId === p.id));
    if (!demo.length) return { ok: false, error: "Those products are no longer available." };
    return { ok: true, orderNumber: "DEMO-" + orderNumber().slice(4) };
  }

  const db = serviceClient();
  // Basic abuse guard: no more than 5 open orders from one phone per hour.
  const since = new Date(Date.now() - 3600_000).toISOString();
  const { count } = await db.from("orders").select("id", { count: "exact", head: true }).eq("phone", phone).gte("created_at", since);
  if ((count ?? 0) >= 5) return { ok: false, error: "Too many orders from this number. Please call us to place more." };

  const ids = [...new Set(input.items.map((i) => i.productId))];
  const [{ data: prods }, { data: st }] = await Promise.all([
    db.from("products").select("*").in("id", ids).eq("is_published", true),
    db.from("settings").select("data").eq("id", 1).maybeSingle(),
  ]);
  const settings = mergeSettings(st?.data);
  const byId = new Map((prods as Product[] | null ?? []).map((p) => [p.id, p]));

  // Merge duplicate lines, validate against live data. Prices ALWAYS come from the database.
  const lines = new Map<string, { p: Product; qty: number; variant: string }>();
  for (const it of input.items) {
    const p = byId.get(it.productId);
    if (!p) return { ok: false, error: "One of the products in your cart is no longer available." };
    const okVariant = p.variants.length === 0
      ? it.variant === ""
      : (() => { const parts = it.variant.split(" / "); return parts.length === p.variants.length && parts.every((part, idx) => p.variants[idx].options.includes(part)); })();
    if (!okVariant) return { ok: false, error: `Please choose options again for ${p.name}.` };
    const key = `${p.id}::${it.variant}`;
    const cur = lines.get(key);
    lines.set(key, { p, variant: it.variant, qty: (cur?.qty ?? 0) + it.qty });
  }
  const perProduct = new Map<string, number>();
  for (const l of lines.values()) perProduct.set(l.p.id, (perProduct.get(l.p.id) ?? 0) + l.qty);
  for (const [id, qty] of perProduct) {
    const p = byId.get(id)!;
    if (p.stock_status === "out_of_stock" || p.stock_qty === 0) return { ok: false, error: `${p.name} just sold out. Please remove it from your cart.` };
    if (p.stock_qty !== null && qty > p.stock_qty) return { ok: false, error: `Only ${p.stock_qty} of ${p.name} left. Please lower the quantity.` };
    if (!p.cod_available) return { ok: false, error: `${p.name} isn't available for cash on delivery.` };
  }

  const items: OrderItem[] = [...lines.values()].map(({ p, qty, variant }) => ({
    product_id: p.id, name: p.name, sku: p.sku, price: Number(p.price), qty, variant, image: p.images?.[0]?.url ?? null,
  }));
  const subtotal = items.reduce((n, i) => n + i.price * i.qty, 0);

  let discount = 0; let couponRow: Coupon | null = null;
  if (input.coupon) {
    const { data } = await db.from("coupons").select("*").ilike("code", input.coupon).maybeSingle();
    couponRow = data as Coupon | null;
    const r = applyCoupon(couponRow, subtotal);
    if (!r.ok) return { ok: false, error: r.error, field: "coupon" };
    discount = r.discount;
  }
  const d = settings.delivery;
  const fee = d.free_above > 0 && subtotal >= d.free_above ? 0 : input.district === "Dhaka" ? d.inside_dhaka_fee : d.outside_dhaka_fee;
  const total = subtotal - discount + fee;

  // Reserve stock (optimistic concurrency so two buyers can't take the last unit).
  const done: { id: string; stock: number | null; sold: number }[] = [];
  async function rollback() {
    for (const r of done) await db.from("products").update({ stock_qty: r.stock, sold_count: r.sold }).eq("id", r.id);
  }
  for (const [id, qty] of perProduct) {
    let ok = false;
    for (let attempt = 0; attempt < 3 && !ok; attempt++) {
      const { data: cur } = await db.from("products").select("stock_qty,sold_count").eq("id", id).single();
      if (!cur) break;
      if (cur.stock_qty !== null && cur.stock_qty < qty) { await rollback(); return { ok: false, error: `${byId.get(id)!.name} just sold out. Please update your cart.` }; }
      const next = { stock_qty: cur.stock_qty === null ? null : cur.stock_qty - qty, sold_count: (cur.sold_count ?? 0) + qty };
      let q = db.from("products").update(next).eq("id", id).eq("sold_count", cur.sold_count ?? 0);
      q = cur.stock_qty === null ? q.is("stock_qty", null) : q.eq("stock_qty", cur.stock_qty);
      const { data: upd } = await q.select("id");
      if (upd && upd.length) { ok = true; done.push({ id, stock: cur.stock_qty, sold: cur.sold_count ?? 0 }); }
    }
    if (!ok) { await rollback(); return { ok: false, error: "We're busy right now. Please try placing the order again." }; }
  }

  const number = orderNumber();
  const { error } = await db.from("orders").insert({
    order_number: number, customer_name: input.name, phone, district: input.district, area: input.area, address: input.address, notes: input.notes,
    items, subtotal, discount, delivery_fee: fee, total, coupon_code: couponRow?.code ?? null, payment_method: "cod", status: "pending",
  });
  if (error) { await rollback(); return { ok: false, error: "We couldn't save your order. Please try again." }; }

  if (couponRow) await db.from("coupons").update({ used_count: couponRow.used_count + 1 }).eq("id", couponRow.id);
  revalidateTag("catalog");
  return { ok: true, orderNumber: number };
}

export type ReviewResult = { ok: true } | { ok: false; error: string };

export async function submitReview(fd: FormData): Promise<ReviewResult> {
  const schema = z.object({
    product_id: z.string().uuid(),
    order_number: z.string().trim().toUpperCase().min(6).max(30),
    phone: z.string().trim().refine((v) => BD_PHONE.test(v.replace(/[\s-]/g, "")), "Enter the phone number you used for the order"),
    name: z.string().trim().min(2, "Enter your name").max(60),
    rating: z.coerce.number().int().min(1, "Choose a star rating").max(5),
    body: z.string().trim().min(10, "Write at least a few words about the product").max(1200),
  });
  const p = schema.safeParse(Object.fromEntries(["product_id", "order_number", "phone", "name", "rating", "body"].map((k) => [k, fd.get(k) ?? ""])));
  if (!p.success) return { ok: false, error: p.error.issues[0].message };
  if (!hasDb()) return { ok: false, error: "Reviews need the database connected." };
  const v = p.data; const db = serviceClient();

  const { data: order } = await db.from("orders").select("items,status,phone").eq("order_number", v.order_number).maybeSingle();
  const mismatch = !order || order.phone !== normalizePhone(v.phone) || !(order.items as OrderItem[]).some((i) => i.product_id === v.product_id);
  if (mismatch) return { ok: false, error: "We couldn't find that product on an order with this order number and phone." };
  if (["cancelled", "returned"].includes(order!.status)) return { ok: false, error: "Reviews are only for orders that weren't cancelled or returned." };
  const { count } = await db.from("reviews").select("id", { count: "exact", head: true }).eq("order_number", v.order_number).eq("product_id", v.product_id);
  if ((count ?? 0) > 0) return { ok: false, error: "You've already reviewed this product for that order." };

  let image_url: string | null = null;
  const file = fd.get("image");
  if (file instanceof File && file.size > 0) {
    try { image_url = await uploadImage(db, file, "reviews", 3 * 1024 * 1024); } catch (e) { return { ok: false, error: (e as Error).message }; }
  }
  const { error } = await db.from("reviews").insert({ product_id: v.product_id, order_number: v.order_number, author_name: v.name, rating: v.rating, body: v.body, image_url, status: "pending" });
  if (error) return { ok: false, error: "Couldn't save your review. Please try again." };
  return { ok: true };
}
