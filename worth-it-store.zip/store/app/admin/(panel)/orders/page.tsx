import Link from "next/link";
import { adminOrders, adminSettings } from "@/lib/admin-data";
import { Badge, Empty, PageHeader, fmtDate } from "@/components/admin/ui";
import { ORDER_STATUSES } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export const metadata = { title: "Orders" };

export default async function OrdersPage({ searchParams }: { searchParams: { status?: string; q?: string } }) {
  const [all, s] = await Promise.all([adminOrders(), adminSettings()]);
  const sym = s.delivery.currency_symbol;
  const status = searchParams.status ?? "";
  const q = (searchParams.q ?? "").toLowerCase().trim();
  const list = all.filter((o) => (!status || o.status === status) && (!q || o.order_number.toLowerCase().includes(q) || o.phone.includes(q) || o.customer_name.toLowerCase().includes(q)));
  const tab = (v: string, label: string, n: number) => (
    <Link key={v} href={v ? `/admin/orders?status=${v}` : "/admin/orders"} className={`shrink-0 rounded-full px-3.5 py-2 text-sm font-semibold ${status === v ? "bg-deep text-white" : "bg-white text-ink/70 hover:bg-paper"} border border-line`}>{label} <span className="opacity-60">{n}</span></Link>
  );
  return (
    <>
      <PageHeader title="Orders" sub={`${all.length} total`} />
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto">{tab("", "All", all.length)}{ORDER_STATUSES.map((st) => tab(st, st[0].toUpperCase() + st.slice(1), all.filter((o) => o.status === st).length))}</div>
      <form className="mb-4 flex gap-2">{status && <input type="hidden" name="status" value={status} />}<input name="q" defaultValue={searchParams.q} placeholder="Search order number, name or phone" className="a-input !w-72" aria-label="Search orders" /><button className="a-btn-ghost">Search</button></form>
      {list.length === 0 ? <Empty title="No orders found" text="New orders from the website appear here automatically." /> : (
        <div className="overflow-x-auto rounded-xl border border-line bg-white">
          <table className="w-full min-w-[720px]">
            <thead className="border-b border-line bg-paper/60"><tr><th className="a-th">Order</th><th className="a-th">Customer</th><th className="a-th">Items</th><th className="a-th">Total</th><th className="a-th">Status</th></tr></thead>
            <tbody className="divide-y divide-line">{list.map((o) => (
              <tr key={o.id} className="hover:bg-paper/50">
                <td className="a-td"><Link href={`/admin/orders/${o.id}`} className="block font-semibold text-brand">{o.order_number}</Link><span className="text-xs text-muted">{fmtDate(o.created_at)}</span></td>
                <td className="a-td"><span className="block font-semibold">{o.customer_name}</span><span className="text-xs text-muted">{o.phone} · {o.district}</span></td>
                <td className="a-td text-muted">{o.items.reduce((n, i) => n + i.qty, 0)} item(s)</td>
                <td className="a-td font-semibold">{formatPrice(o.total, sym)}</td>
                <td className="a-td"><Badge s={o.status} /></td></tr>))}</tbody>
          </table>
        </div>)}
    </>
  );
}
