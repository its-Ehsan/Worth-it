import Link from "next/link";
import { notFound } from "next/navigation";
import { adminSettings, db } from "@/lib/admin-data";
import { updateOrder } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "@/components/admin/ActionForm";
import { Badge, PageHeader, fmtDate } from "@/components/admin/ui";
import { ORDER_STATUSES, type Order } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export const metadata = { title: "Order" };

export default async function OrderPage({ params }: { params: { id: string } }) {
  if (!/^[0-9a-f-]{36}$/i.test(params.id)) notFound();
  const [{ data }, s] = await Promise.all([db().from("orders").select("*").eq("id", params.id).maybeSingle(), adminSettings()]);
  if (!data) notFound();
  const o = data as Order; const sym = s.delivery.currency_symbol;
  const wa = o.phone.replace(/^0/, "880");
  return (
    <>
      <PageHeader title={o.order_number} sub={`Placed ${fmtDate(o.created_at)}`}><Badge s={o.status} /></PageHeader>
      <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr] lg:items-start">
        <div className="space-y-4">
          <section className="a-card">
            <h2 className="mb-3 font-bold">Items</h2>
            <ul className="divide-y divide-line">{o.items.map((i, k) => (
              <li key={k} className="flex items-center gap-3 py-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <span className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-paper">{i.image && <img src={i.image} alt="" className="h-full w-full object-cover" />}</span>
                <span className="min-w-0 flex-1 text-sm"><span className="block font-semibold">{i.name}</span><span className="text-xs text-muted">{[i.variant, i.sku].filter(Boolean).join(" · ")}</span></span>
                <span className="text-sm text-muted">{formatPrice(i.price, sym)} × {i.qty}</span><span className="w-24 text-right text-sm font-semibold">{formatPrice(i.price * i.qty, sym)}</span></li>))}</ul>
            <dl className="mt-3 space-y-1.5 border-t border-line pt-3 text-sm">
              <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{formatPrice(o.subtotal, sym)}</dd></div>
              {o.discount > 0 && <div className="flex justify-between"><dt className="text-muted">Discount {o.coupon_code && `(${o.coupon_code})`}</dt><dd>−{formatPrice(o.discount, sym)}</dd></div>}
              <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd>{formatPrice(o.delivery_fee, sym)}</dd></div>
              <div className="flex justify-between font-display text-lg font-extrabold"><dt>Collect on delivery</dt><dd>{formatPrice(o.total, sym)}</dd></div>
            </dl>
          </section>
          <section className="a-card"><h2 className="mb-3 font-bold">Customer</h2>
            <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
              <div><dt className="text-xs text-muted">Name</dt><dd className="font-semibold">{o.customer_name}</dd></div>
              <div><dt className="text-xs text-muted">Phone</dt><dd className="font-semibold"><a href={`tel:${o.phone}`} className="text-brand">{o.phone}</a> · <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className="text-brand">WhatsApp</a></dd></div>
              <div className="sm:col-span-2"><dt className="text-xs text-muted">Address</dt><dd className="font-semibold">{o.address}, {o.area}, {o.district}</dd></div>
              <div><dt className="text-xs text-muted">Payment</dt><dd className="font-semibold">Cash on delivery</dd></div>
              <div className="sm:col-span-2"><dt className="text-xs text-muted">Customer notes</dt><dd>{o.notes || <span className="text-muted">None</span>}</dd></div>
            </dl></section>
        </div>
        <section className="a-card lg:sticky lg:top-6">
          <h2 className="mb-3 font-bold">Update order</h2>
          <ActionForm action={updateOrder} className="space-y-3">
            <input type="hidden" name="id" value={o.id} />
            <div><label className="a-label" htmlFor="o-status">Status</label>
              <select id="o-status" name="status" defaultValue={o.status} className="a-input">{ORDER_STATUSES.map((st) => <option key={st} value={st}>{st[0].toUpperCase() + st.slice(1)}</option>)}</select></div>
            <div><label className="a-label" htmlFor="o-note">Internal note</label><textarea id="o-note" name="admin_note" rows={3} defaultValue={o.admin_note} className="a-input" placeholder="Only visible to you" /></div>
            <p className="text-xs text-muted">Cancelling or returning an order puts the stock back automatically.</p>
            <SubmitButton>Save status</SubmitButton>
          </ActionForm>
          <Link href="/admin/orders" className="mt-4 inline-block text-sm font-semibold text-brand">← All orders</Link>
        </section>
      </div>
    </>
  );
}
