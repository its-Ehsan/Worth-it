import { adminCategories, adminProducts } from "@/lib/admin-data";
import { deleteCategory, saveCategory } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "@/components/admin/ActionForm";
import ConfirmButton from "@/components/admin/ConfirmButton";
import ImageField from "@/components/admin/ImageField";
import { PageHeader } from "@/components/admin/ui";
import type { Category } from "@/lib/types";

export const metadata = { title: "Categories" };

function CatForm({ c }: { c?: Category }) {
  return (
    <ActionForm action={saveCategory} className="space-y-3" resetOnSuccess={!c}>
      {c && <input type="hidden" name="id" value={c.id} />}
      <div className="grid gap-3 sm:grid-cols-[1fr_1fr_90px]">
        <div><label className="a-label">Name</label><input name="name" required defaultValue={c?.name} className="a-input" /></div>
        <div><label className="a-label">URL name</label><input name="slug" defaultValue={c?.slug} className="a-input" placeholder="auto" /></div>
        <div><label className="a-label">Order</label><input name="sort_order" inputMode="numeric" defaultValue={c?.sort_order ?? 0} className="a-input" /></div>
      </div>
      <div><label className="a-label">Description</label><input name="description" defaultValue={c?.description} maxLength={300} className="a-input" /></div>
      <ImageField name="image_url" label="Image" folder="categories" initial={c?.image_url ?? ""} hint="Shown on the homepage category tiles." />
      <SubmitButton>{c ? "Save category" : "Add category"}</SubmitButton>
    </ActionForm>
  );
}

export default async function CategoriesPage() {
  const [cats, products] = await Promise.all([adminCategories(), adminProducts()]);
  const count = (id: string) => products.filter((p) => p.category_id === id).length;
  return (
    <>
      <PageHeader title="Categories" sub="Shown in the menu, footer and homepage tiles. The first one becomes the large tile." />
      <div className="grid gap-4 lg:grid-cols-[1fr_1.4fr] lg:items-start">
        <section className="a-card"><h2 className="mb-3 font-bold">Add category</h2><CatForm /></section>
        <section className="space-y-3">
          {cats.length === 0 && <p className="a-card text-sm text-muted">No categories yet.</p>}
          {cats.map((c) => (
            <details key={c.id} className="a-card group">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3"><span className="font-semibold">{c.name} <span className="font-normal text-muted">· {count(c.id)} products</span></span><span className="text-sm font-semibold text-brand">Edit</span></summary>
              <div className="mt-4 space-y-4 border-t border-line pt-4"><CatForm c={c} />
                <form action={deleteCategory}><input type="hidden" name="id" value={c.id} /><ConfirmButton message={`Delete “${c.name}”? Its products stay but become uncategorised.`}>Delete category</ConfirmButton></form></div>
            </details>))}
        </section>
      </div>
    </>
  );
}
