import { adminOrders, adminSettings } from "@/lib/admin-data";
import { Empty, PageHeader, fmtDate } from "@/components/admin/ui";
import { formatPrice } from "@/lib/utils";

export const metadata = { title: "Customers" };

export default async function CustomersPage({ searchParams }: { searchParams: { q?: string } }) {
  const [orders, s] = await Promise.all([adminOrders(), adminSettings()]);
  const map = new Map<string, { name: string; phone: string; district: string; orders: number; spent: number; last: string }>();
  for (const o of orders) { // newest first
    const c = map.get(o.phone) ?? { name: o.customer_name, phone: o.phone, district: o.district, orders: 0, spent: 0, last: o.created_at };
    c.orders += 1; if (!["cancelled", "returned"].includes(o.status)) c.spent += Number(o.total);
    map.set(o.phone, c);
  }
  const q = (searchParams.q ?? "").toLowerCase().trim();
  const list = [...map.values()].filter((c) => !q || c.name.toLowerCase().includes(q) || c.phone.includes(q)).sort((a, b) => b.spent - a.spent);
  return (
    <>
      <PageHeader title="Customers" sub="Built from orders. Customers check out as guests, so they are grouped by phone number." />
      <form className="mb-4 flex gap-2"><input name="q" defaultValue={searchParams.q} placeholder="Search name or phone" className="a-input !w-72" aria-label="Search customers" /><button className="a-btn-ghost">Search</button></form>
      {list.length === 0 ? <Empty title="No customers yet" text="They appear after the first order." /> : (
        <div className="overflow-x-auto rounded-xl border border-line bg-white">
          <table className="w-full min-w-[640px]">
            <thead className="border-b border-line bg-paper/60"><tr><th className="a-th">Customer</th><th className="a-th">District</th><th className="a-th">Orders</th><th className="a-th">Spent</th><th className="a-th">Last order</th></tr></thead>
            <tbody className="divide-y divide-line">{list.map((c) => (
              <tr key={c.phone}><td className="a-td"><span className="block font-semibold">{c.name}</span><a href={`tel:${c.phone}`} className="text-xs text-brand">{c.phone}</a></td>
                <td className="a-td">{c.district}</td><td className="a-td">{c.orders}</td><td className="a-td font-semibold">{formatPrice(c.spent, s.delivery.currency_symbol)}</td><td className="a-td text-muted">{fmtDate(c.last)}</td></tr>))}</tbody>
          </table>
        </div>)}
    </>
  );
}
