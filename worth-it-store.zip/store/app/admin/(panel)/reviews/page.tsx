import Link from "next/link";
import { adminReviews } from "@/lib/admin-data";
import { deleteReview, setReviewStatus } from "@/app/admin/actions";
import ConfirmButton from "@/components/admin/ConfirmButton";
import Stars from "@/components/ui/Stars";
import { Badge, Empty, PageHeader, fmtDate } from "@/components/admin/ui";

export const metadata = { title: "Reviews" };

export default async function ReviewsPage({ searchParams }: { searchParams: { status?: string } }) {
  const all = await adminReviews();
  const status = searchParams.status ?? "pending";
  const list = all.filter((r) => r.status === status);
  const tab = (v: string, label: string) => <Link key={v} href={`/admin/reviews?status=${v}`} className={`rounded-full border border-line px-3.5 py-2 text-sm font-semibold ${status === v ? "bg-deep text-white" : "bg-white text-ink/70"}`}>{label} <span className="opacity-60">{all.filter((r) => r.status === v).length}</span></Link>;
  const act = (id: string, st: string, label: string, cls = "a-btn-ghost") => (<form action={setReviewStatus}><input type="hidden" name="id" value={id} /><input type="hidden" name="status" value={st} /><button className={`${cls} !px-3 !py-1.5 text-xs`}>{label}</button></form>);
  return (
    <>
      <PageHeader title="Reviews" sub="Only approved reviews are shown on the website." />
      <div className="mb-4 flex gap-2">{tab("pending", "Pending")}{tab("approved", "Approved")}{tab("rejected", "Rejected")}</div>
      {list.length === 0 ? <Empty title={`No ${status} reviews`} text="Customers can review products they have ordered, from the product page." /> : (
        <ul className="space-y-3">{list.map((r) => (
          <li key={r.id} className="a-card">
            <div className="flex flex-wrap items-center justify-between gap-2"><div className="flex items-center gap-2"><Stars value={r.rating} size={16} /><Badge s={r.status} /></div><span className="text-xs text-muted">{fmtDate(r.created_at)}</span></div>
            <p className="mt-2 text-sm leading-relaxed">{r.body}</p>
            {r.image_url && /* eslint-disable-next-line @next/next/no-img-element */ <img src={r.image_url} alt="Customer upload" className="mt-2 h-24 w-24 rounded-lg object-cover" />}
            <p className="mt-2 text-xs text-muted"><b>{r.author_name}</b> on {r.product_name ?? "deleted product"}{r.order_number ? ` · ${r.order_number}` : ""}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {r.status !== "approved" && act(r.id, "approved", "Approve", "a-btn")}
              {r.status !== "rejected" && act(r.id, "rejected", "Reject")}
              <form action={deleteReview}><input type="hidden" name="id" value={r.id} /><ConfirmButton message="Delete this review permanently?" className="a-btn-danger !px-3 !py-1.5 text-xs">Delete</ConfirmButton></form>
            </div>
          </li>))}</ul>)}
    </>
  );
}
