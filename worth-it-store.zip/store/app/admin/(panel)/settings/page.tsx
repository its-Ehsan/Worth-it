import { adminSettings } from "@/lib/admin-data";
import { saveSettings } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "@/components/admin/ActionForm";
import ImageField from "@/components/admin/ImageField";
import { PageHeader } from "@/components/admin/ui";

export const metadata = { title: "Settings" };

const F = ({ label, name, v, hint, type = "text" }: { label: string; name: string; v: string | number; hint?: string; type?: string }) => (
  <div><label className="a-label" htmlFor={name}>{label}</label><input id={name} name={name} type={type} defaultValue={v} className="a-input" />{hint && <p className="mt-1 text-[11px] text-muted">{hint}</p>}</div>
);
const T = ({ label, name, v, rows = 8, hint }: { label: string; name: string; v: string; rows?: number; hint?: string }) => (
  <div><label className="a-label" htmlFor={name}>{label}</label><textarea id={name} name={name} rows={rows} defaultValue={v} className="a-input font-mono !text-[13px]" />{hint && <p className="mt-1 text-[11px] text-muted">{hint}</p>}</div>
);

export default async function SettingsPage() {
  const s = await adminSettings();
  const faq = s.pages.faq.map((f) => `Q: ${f.q}\nA: ${f.a}`).join("\n\n");
  return (
    <>
      <PageHeader title="Settings" sub="Brand, contact details, delivery and the text of your policy pages." />
      <ActionForm action={saveSettings} className="max-w-3xl space-y-5 pb-24">
        <section className="a-card space-y-3"><h2 className="font-bold">Brand</h2>
          <div className="grid gap-3 sm:grid-cols-2"><F label="Brand name" name="brand_name" v={s.brand.name} /><F label="Tagline" name="brand_tagline" v={s.brand.tagline} /></div>
          <label className="flex min-h-[40px] cursor-pointer items-center gap-2.5 text-sm"><input type="checkbox" name="brand_logo_with_name" defaultChecked={s.brand.logo_with_name} className="h-4 w-4 accent-[rgb(var(--brand))]" />Show the brand name next to the logo (turn off if your logo already contains the name)</label>
          <div className="grid gap-4 sm:grid-cols-2">
            <ImageField name="brand_logo" label="Logo" folder="brand" initial={s.brand.logo_url} hint="Wide logos work best (PNG or WebP with transparent background). Empty = brand name as text." />
            <ImageField name="brand_favicon" label="Favicon" folder="brand" initial={s.brand.favicon_url} hint="Square, at least 64x64." />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="a-label" htmlFor="brand_primary">Primary colour</label><input id="brand_primary" name="brand_primary" type="color" defaultValue={s.brand.primary_color} className="h-11 w-full cursor-pointer rounded-lg border border-line bg-white p-1" /><p className="mt-1 text-[11px] text-muted">Buttons, links and highlights.</p></div>
            <div><label className="a-label" htmlFor="brand_secondary">Secondary colour</label><input id="brand_secondary" name="brand_secondary" type="color" defaultValue={s.brand.secondary_color} className="h-11 w-full cursor-pointer rounded-lg border border-line bg-white p-1" /><p className="mt-1 text-[11px] text-muted">Discount badges.</p></div>
          </div>
          <ImageField name="brand_og" label="Social sharing image" folder="brand" initial={s.brand.og_image} hint="Shown when your site is shared on Facebook or WhatsApp. 1200x630 is ideal." />
        </section>

        <section className="a-card space-y-3"><h2 className="font-bold">Contact & social</h2>
          <div className="grid gap-3 sm:grid-cols-2"><F label="Phone" name="c_phone" v={s.contact.phone} /><F label="WhatsApp number" name="c_whatsapp" v={s.contact.whatsapp} hint="Digits with country code, like 8801XXXXXXXXX" /><F label="Email" name="c_email" v={s.contact.email} /><F label="Opening hours" name="c_hours" v={s.contact.hours} /></div>
          <F label="Address" name="c_address" v={s.contact.address} />
          <div className="grid gap-3 sm:grid-cols-2"><F label="Facebook page link" name="c_facebook" v={s.contact.facebook} /><F label="Instagram link" name="c_instagram" v={s.contact.instagram} /><F label="YouTube link" name="c_youtube" v={s.contact.youtube} /><F label="TikTok link" name="c_tiktok" v={s.contact.tiktok} /></div></section>

        <section className="a-card space-y-3"><h2 className="font-bold">Delivery</h2>
          <div className="grid gap-3 sm:grid-cols-3"><F label="Inside Dhaka fee" name="d_in_fee" v={s.delivery.inside_dhaka_fee} type="number" /><F label="Outside Dhaka fee" name="d_out_fee" v={s.delivery.outside_dhaka_fee} type="number" /><F label="Free delivery above" name="d_free" v={s.delivery.free_above} type="number" hint="0 = never free" /></div>
          <div className="grid gap-3 sm:grid-cols-3"><F label="Inside Dhaka time" name="d_in_eta" v={s.delivery.inside_dhaka_eta} /><F label="Outside Dhaka time" name="d_out_eta" v={s.delivery.outside_dhaka_eta} /><F label="Currency symbol" name="d_symbol" v={s.delivery.currency_symbol} /></div>
          <F label="Cash on delivery note" name="d_cod" v={s.delivery.cod_note} />
          <F label="Low-stock warning at or below" name="low_stock" v={s.low_stock_threshold} type="number" hint="Used on the dashboard." /></section>

        <section className="a-card space-y-3"><h2 className="font-bold">Search engines</h2>
          <F label="Homepage title" name="seo_title" v={s.seo.title} hint="Empty = brand name and tagline." /><F label="Description" name="seo_description" v={s.seo.description} /></section>

        <section className="a-card space-y-4"><h2 className="font-bold">Page text</h2>
          <p className="text-xs text-muted">Start a heading with “## ”, start list items with “- ”, and leave a blank line between paragraphs.</p>
          <T label="About" name="p_about" v={s.pages.about} /><T label="Shipping & delivery" name="p_shipping" v={s.pages.shipping} /><T label="Return & refund policy" name="p_returns" v={s.pages.returns} />
          <T label="Privacy policy" name="p_privacy" v={s.pages.privacy} /><T label="Terms & conditions" name="p_terms" v={s.pages.terms} />
          <T label="FAQ" name="p_faq" v={faq} rows={14} hint={'Write "Q: question" then "A: answer". Leave a blank line between questions.'} /></section>

        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 p-3 backdrop-blur md:left-60"><div className="mx-auto flex max-w-3xl justify-end"><SubmitButton>Save settings</SubmitButton></div></div>
      </ActionForm>
    </>
  );
}
