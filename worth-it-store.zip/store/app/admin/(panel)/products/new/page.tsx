import { adminCategories, adminProducts } from "@/lib/admin-data";
import { PageHeader } from "@/components/admin/ui";
import ProductForm from "@/components/admin/ProductForm";

export const metadata = { title: "Add product" };

export default async function NewProduct() {
  const [cats, products] = await Promise.all([adminCategories(), adminProducts()]);
  return (<><PageHeader title="Add product" sub="Fill this in, upload images, and publish. It appears on the website immediately." /><div className="max-w-4xl"><ProductForm product={null} categories={cats} others={products.map((p) => ({ id: p.id, name: p.name }))} /></div></>);
}
