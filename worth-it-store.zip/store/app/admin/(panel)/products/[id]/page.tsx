import Link from "next/link";
import { notFound } from "next/navigation";
import { adminCategories, adminProducts, db } from "@/lib/admin-data";
import { deleteProduct } from "@/app/admin/actions";
import { PageHeader } from "@/components/admin/ui";
import ConfirmButton from "@/components/admin/ConfirmButton";
import ProductForm from "@/components/admin/ProductForm";
import type { Product } from "@/lib/types";

export const metadata = { title: "Edit product" };

export default async function EditProduct({ params, searchParams }: { params: { id: string }; searchParams: { created?: string } }) {
  if (!/^[0-9a-f-]{36}$/i.test(params.id)) notFound();
  const { data } = await db().from("products").select("*").eq("id", params.id).maybeSingle();
  if (!data) notFound();
  const p = data as Product;
  const [cats, products] = await Promise.all([adminCategories(), adminProducts()]);
  return (
    <>
      <PageHeader title={p.name} sub={p.is_published ? "Published on the website" : "Unpublished: only you can see it"}>
        <div className="flex gap-2">{p.is_published && <Link href={`/product/${p.slug}`} target="_blank" className="a-btn-ghost">View on site ↗</Link>}
          <form action={deleteProduct}><input type="hidden" name="id" value={p.id} /><ConfirmButton message="Delete this product permanently? Past orders keep their details. To just hide it, use Unpublish instead.">Delete</ConfirmButton></form></div>
      </PageHeader>
      {searchParams.created && <p className="mb-4 rounded-lg bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">Product created{p.is_published ? " and live on the website." : ". It's unpublished until you publish it."}</p>}
      <div className="max-w-4xl"><ProductForm product={p} categories={cats} others={products.map((x) => ({ id: x.id, name: x.name }))} /></div>
    </>
  );
}
