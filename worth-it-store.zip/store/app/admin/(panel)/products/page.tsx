import Link from "next/link";
import { adminCategories, adminProducts } from "@/lib/admin-data";
import { quickStock, setProductFlag } from "@/app/admin/actions";
import { Badge, Empty, PageHeader } from "@/components/admin/ui";
import { formatPrice } from "@/lib/utils";

export const metadata = { title: "Products" };

export default async function ProductsPage({ searchParams }: { searchParams: { q?: string; show?: string } }) {
  const [products, cats] = await Promise.all([adminProducts(), adminCategories()]);
  const catName = new Map(cats.map((c) => [c.id, c.name]));
  const q = (searchParams.q ?? "").toLowerCase();
  const show = searchParams.show ?? "all";
  const list = products.filter((p) => (!q || p.name.toLowerCase().includes(q) || (p.sku ?? "").toLowerCase().includes(q)) && (show === "all" || (show === "live" ? p.is_published : show === "draft" ? !p.is_published : p.is_demo)));
  const demoCount = products.filter((p) => p.is_demo).length;
  return (
    <>
      <PageHeader title="Products" sub={`${products.length} total`}><Link href="/admin/products/new" className="a-btn">Add product</Link></PageHeader>
      <form className="mb-4 flex flex-wrap gap-2">
        <input name="q" defaultValue={searchParams.q} placeholder="Search name or SKU" className="a-input !w-64" aria-label="Search products" />
        <select name="show" defaultValue={show} className="a-input !w-auto" aria-label="Filter"><option value="all">All</option><option value="live">Published</option><option value="draft">Unpublished</option>{demoCount > 0 && <option value="demo">Demo products</option>}</select>
        <button className="a-btn-ghost">Filter</button>
      </form>
      {demoCount > 0 && <p className="mb-4 rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-900">You have {demoCount} demo products. When you are ready, run <code>npm run clear:demo</code> to remove them. Your own products are never touched.</p>}
      {list.length === 0 ? <Empty title="No products found" text="Add your first product to see it on the website instantly." /> : (
        <div className="overflow-x-auto rounded-xl border border-line bg-white">
          <table className="w-full min-w-[760px]">
            <thead className="border-b border-line bg-paper/60"><tr><th className="a-th">Product</th><th className="a-th">Price</th><th className="a-th">Stock</th><th className="a-th">Status</th><th className="a-th" /></tr></thead>
            <tbody className="divide-y divide-line">
              {list.map((p) => (
                <tr key={p.id}>
                  <td className="a-td"><Link href={`/admin/products/${p.id}`} className="flex items-center gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <span className="h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-paper">{p.images[0] && <img src={p.images[0].url} alt="" className="h-full w-full object-cover" loading="lazy" />}</span>
                    <span><span className="block font-semibold hover:text-brand">{p.name}{p.is_demo && <span className="ml-2 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">DEMO</span>}</span>
                      <span className="text-xs text-muted">{catName.get(p.category_id ?? "") ?? "No category"}{p.sku ? ` · ${p.sku}` : ""}</span></span></Link></td>
                  <td className="a-td font-semibold">{formatPrice(p.price)}</td>
                  <td className="a-td">
                    <form action={quickStock} className="flex items-center gap-1.5"><input type="hidden" name="id" value={p.id} />
                      <input name="stock_qty" defaultValue={p.stock_qty ?? ""} placeholder="Avail." inputMode="numeric" aria-label={`Stock for ${p.name}`} className="a-input !w-20 !py-1.5" />
                      <button className="a-btn-ghost !px-2.5 !py-1.5 text-xs">Set</button></form>
                    {(p.stock_status === "out_of_stock" || p.stock_qty === 0) && <span className="mt-1 block text-[11px] font-bold text-red-600">Out of stock</span>}
                  </td>
                  <td className="a-td"><Badge s={p.is_published ? "live" : "draft"}>{p.is_published ? "Published" : "Unpublished"}</Badge></td>
                  <td className="a-td text-right"><div className="flex justify-end gap-1.5">
                    <form action={setProductFlag}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="field" value="is_published" /><input type="hidden" name="value" value={String(!p.is_published)} /><button className="a-btn-ghost !px-3 !py-1.5 text-xs">{p.is_published ? "Unpublish" : "Publish"}</button></form>
                    <Link href={`/admin/products/${p.id}`} className="a-btn-ghost !px-3 !py-1.5 text-xs">Edit</Link></div></td>
                </tr>))}
            </tbody>
          </table>
        </div>)}
    </>
  );
}
