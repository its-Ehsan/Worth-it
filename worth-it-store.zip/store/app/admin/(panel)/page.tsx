import Link from "next/link";
import { adminOrders, adminProducts, adminSettings } from "@/lib/admin-data";
import { Badge, PageHeader, fmtDate } from "@/components/admin/ui";
import { formatPrice } from "@/lib/utils";

export const metadata = { title: "Dashboard" };

export default async function Dashboard() {
  const [orders, products, s] = await Promise.all([adminOrders(), adminProducts(), adminSettings()]);
  const sym = s.delivery.currency_symbol;
  const count = (st: string) => orders.filter((o) => o.status === st).length;
  const counted = orders.filter((o) => !["cancelled", "returned"].includes(o.status));
  const revenue = counted.reduce((n, o) => n + Number(o.total), 0);
  const delivered = orders.filter((o) => o.status === "delivered").reduce((n, o) => n + Number(o.total), 0);
  const low = products.filter((p) => p.stock_status === "out_of_stock" || (p.stock_qty !== null && p.stock_qty <= s.low_stock_threshold));
  const best = [...products].sort((a, b) => b.sold_count - a.sold_count).filter((p) => p.sold_count > 0).slice(0, 5);

  const days = Array.from({ length: 14 }, (_, i) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (13 - i)); return d; });
  const series = days.map((d) => {
    const next = new Date(d); next.setDate(d.getDate() + 1);
    const day = counted.filter((o) => { const t = new Date(o.created_at); return t >= d && t < next; });
    return { label: d.toLocaleDateString("en-GB", { day: "numeric", month: "short" }), total: day.reduce((n, o) => n + Number(o.total), 0), n: day.length };
  });
  const maxV = Math.max(1, ...series.map((x) => x.total));

  const Stat = ({ label, value, href, tone }: { label: string; value: string | number; href?: string; tone?: string }) => (
    <Link href={href ?? "#"} className="a-card block transition hover:border-ink/30"><p className="text-xs font-semibold text-muted">{label}</p><p className={`mt-1 font-display text-2xl font-extrabold ${tone ?? ""}`}>{value}</p></Link>
  );
  return (
    <>
      <PageHeader title="Dashboard" sub="How the store is doing." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total orders" value={orders.length} href="/admin/orders" />
        <Stat label="Pending" value={count("pending")} href="/admin/orders?status=pending" tone="text-amber-600" />
        <Stat label="Confirmed" value={count("confirmed")} href="/admin/orders?status=confirmed" />
        <Stat label="Delivered" value={count("delivered")} href="/admin/orders?status=delivered" tone="text-emerald-600" />
        <Stat label="Cancelled" value={count("cancelled")} href="/admin/orders?status=cancelled" tone="text-red-600" />
        <Stat label="Revenue (excl. cancelled)" value={formatPrice(revenue, sym)} />
        <Stat label="Delivered revenue" value={formatPrice(delivered, sym)} />
        <Stat label="Products" value={products.length} href="/admin/products" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <section className="a-card">
          <h2 className="font-bold">Sales, last 14 days</h2>
          <div className="mt-4 flex h-44 items-end gap-1.5" role="img" aria-label="Daily sales for the last 14 days">
            {series.map((d) => (
              <div key={d.label} className="group flex h-full flex-1 flex-col justify-end" title={`${d.label}: ${formatPrice(d.total, sym)} (${d.n} orders)`}>
                <div className="w-full rounded-t-md bg-brand/80 transition group-hover:bg-brand" style={{ height: `${Math.max(d.total ? 4 : 1, (d.total / maxV) * 100)}%`, opacity: d.total ? 1 : 0.2 }} />
              </div>))}
          </div>
          <div className="mt-2 flex justify-between text-[11px] text-muted"><span>{series[0].label}</span><span>{series[13].label}</span></div>
        </section>
        <section className="a-card">
          <h2 className="font-bold">Best sellers</h2>
          {best.length === 0 ? <p className="mt-3 text-sm text-muted">Sales will show up here after your first orders.</p> : (
            <ol className="mt-3 space-y-2.5">{best.map((p) => <li key={p.id} className="flex items-center justify-between gap-3 text-sm"><Link href={`/admin/products/${p.id}`} className="truncate font-semibold hover:text-brand">{p.name}</Link><span className="shrink-0 text-muted">{p.sold_count} sold</span></li>)}</ol>)}
        </section>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <section className="a-card">
          <div className="flex items-center justify-between"><h2 className="font-bold">Recent orders</h2><Link href="/admin/orders" className="text-sm font-semibold text-brand">View all</Link></div>
          {orders.length === 0 ? <p className="mt-3 text-sm text-muted">No orders yet. They appear here the moment a customer checks out.</p> : (
            <ul className="mt-3 divide-y divide-line">{orders.slice(0, 8).map((o) => (
              <li key={o.id}><Link href={`/admin/orders/${o.id}`} className="flex items-center justify-between gap-3 py-2.5 text-sm hover:text-brand">
                <span className="min-w-0"><span className="block font-semibold">{o.order_number}</span><span className="block truncate text-xs text-muted">{o.customer_name} · {fmtDate(o.created_at)}</span></span>
                <span className="flex shrink-0 items-center gap-3"><span className="font-semibold">{formatPrice(o.total, sym)}</span><Badge s={o.status} /></span></Link></li>))}</ul>)}
        </section>
        <section className="a-card">
          <h2 className="font-bold">Low stock</h2>
          {low.length === 0 ? <p className="mt-3 text-sm text-muted">All products are well stocked.</p> : (
            <ul className="mt-3 divide-y divide-line">{low.slice(0, 8).map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3 py-2.5 text-sm"><Link href={`/admin/products/${p.id}`} className="truncate font-semibold hover:text-brand">{p.name}</Link>
                <span className={`shrink-0 text-xs font-bold ${p.stock_status === "out_of_stock" || p.stock_qty === 0 ? "text-red-600" : "text-amber-600"}`}>{p.stock_status === "out_of_stock" || p.stock_qty === 0 ? "Out of stock" : `${p.stock_qty} left`}</span></li>))}</ul>)}
        </section>
      </div>
    </>
  );
}
