import { adminProducts, adminSettings } from "@/lib/admin-data";
import { saveHomepage } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "@/components/admin/ActionForm";
import ImageField from "@/components/admin/ImageField";
import { PageHeader } from "@/components/admin/ui";

export const metadata = { title: "Homepage" };

const F = ({ label, name, v, max, hint, area }: { label: string; name: string; v: string; max?: number; hint?: string; area?: boolean }) => (
  <div><label className="a-label" htmlFor={name}>{label}</label>{area ? <textarea id={name} name={name} rows={3} maxLength={max} defaultValue={v} className="a-input" /> : <input id={name} name={name} maxLength={max} defaultValue={v} className="a-input" />}{hint && <p className="mt-1 text-[11px] text-muted">{hint}</p>}</div>
);

export default async function HomepageAdmin() {
  const [s, products] = await Promise.all([adminSettings(), adminProducts()]);
  const h = s.homepage;
  const toggle = (name: string, label: string, on: boolean) => <label className="flex min-h-[40px] cursor-pointer items-center gap-2.5 text-sm"><input type="checkbox" name={name} defaultChecked={on} className="h-4 w-4 accent-[rgb(var(--brand))]" />{label}</label>;
  return (
    <>
      <PageHeader title="Homepage" sub="Everything on the front page. Product rows (trending, new, best sellers) are controlled by the switches on each product." />
      <ActionForm action={saveHomepage} className="max-w-3xl space-y-5 pb-24">
        <section className="a-card space-y-3"><h2 className="font-bold">Announcement bar</h2>
          {toggle("ann_enabled", "Show announcement bar", h.announcement.enabled)}
          <F label="Text" name="ann_text" v={h.announcement.text} max={200} /><F label="Link (optional)" name="ann_link" v={h.announcement.link} hint="Example: /shop or /shipping" /></section>

        <section className="a-card space-y-3"><h2 className="font-bold">Hero</h2>
          <F label="Small line above the title" name="hero_eyebrow" v={h.hero.eyebrow} max={80} />
          <F label="Title" name="hero_title" v={h.hero.title} max={140} /><F label="Subtitle" name="hero_subtitle" v={h.hero.subtitle} max={400} area />
          <div className="grid gap-3 sm:grid-cols-2"><F label="Button text" name="hero_cta_text" v={h.hero.cta_text} max={40} /><F label="Button link" name="hero_cta_link" v={h.hero.cta_link} /><F label="Second button text" name="hero_sec_text" v={h.hero.secondary_text} max={40} /><F label="Second button link" name="hero_sec_link" v={h.hero.secondary_link} /></div>
          <div><label className="a-label" htmlFor="hero_product_id">Featured hero product</label>
            <select id="hero_product_id" name="hero_product_id" defaultValue={h.hero.product_id} className="a-input"><option value="">Automatic (first featured product)</option>{products.filter((p) => p.is_published).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
          <ImageField name="hero_image" label="Hero image (optional)" folder="homepage" initial={h.hero.image} hint="Square works best. Leave empty to use the hero product's photo." />
        </section>

        <section className="a-card space-y-4"><h2 className="font-bold">Promotional banners</h2>
          {[0, 1].map((i) => { const b = h.banners[i]; return (
            <div key={i} className="space-y-3 rounded-lg border border-line p-4"><p className="text-sm font-semibold">Banner {i + 1}</p>
              <div className="grid gap-3 sm:grid-cols-2"><F label="Title" name={`banner_${i}_title`} v={b?.title ?? ""} max={80} /><F label="Link" name={`banner_${i}_link`} v={b?.link ?? ""} /></div>
              <F label="Subtitle" name={`banner_${i}_subtitle`} v={b?.subtitle ?? ""} max={200} />
              <ImageField name={`banner_${i}_image`} label="Background image (optional)" folder="homepage" initial={b?.image ?? ""} /></div>); })}
          <p className="text-xs text-muted">Leave a banner title empty to hide it.</p></section>

        <section className="a-card"><h2 className="mb-2 font-bold">Sections to show</h2>
          <div className="grid gap-x-6 sm:grid-cols-2">{toggle("sec_trending", "Trending products", h.sections.trending)}{toggle("sec_new_arrivals", "New arrivals", h.sections.new_arrivals)}{toggle("sec_best_sellers", "Best sellers", h.sections.best_sellers)}{toggle("sec_discovery", "Find your fit", h.sections.discovery)}{toggle("sec_reviews", "Customer reviews", h.sections.reviews)}{toggle("sec_faq", "FAQ", h.sections.faq)}</div></section>

        <section className="a-card space-y-3"><h2 className="font-bold">Why choose us (up to 4)</h2>
          {[0, 1, 2, 3].map((i) => <div key={i} className="grid gap-3 sm:grid-cols-[1fr_2fr]"><F label={`Title ${i + 1}`} name={`trust_${i}_title`} v={h.trust[i]?.title ?? ""} max={60} /><F label="Text" name={`trust_${i}_text`} v={h.trust[i]?.text ?? ""} max={200} /></div>)}</section>

        <section className="a-card space-y-3"><h2 className="font-bold">Social proof numbers (up to 3)</h2>
          {[0, 1, 2].map((i) => <div key={i} className="grid gap-3 sm:grid-cols-[1fr_2fr]"><F label="Number" name={`stat_${i}_value`} v={h.stats[i]?.value ?? ""} max={20} /><F label="Label" name={`stat_${i}_label`} v={h.stats[i]?.label ?? ""} max={60} /></div>)}
          <p className="text-xs text-muted">Only use numbers that are true for your store.</p></section>

        <section className="a-card space-y-3"><h2 className="font-bold">Final call to action</h2>
          <F label="Title" name="cta_title" v={h.final_cta.title} max={140} /><F label="Subtitle" name="cta_subtitle" v={h.final_cta.subtitle} max={300} />
          <div className="grid gap-3 sm:grid-cols-2"><F label="Button text" name="cta_button_text" v={h.final_cta.button_text} max={40} /><F label="Button link" name="cta_button_link" v={h.final_cta.button_link} /></div></section>

        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 p-3 backdrop-blur md:left-60"><div className="mx-auto flex max-w-3xl justify-end"><SubmitButton>Save homepage</SubmitButton></div></div>
      </ActionForm>
    </>
  );
}
