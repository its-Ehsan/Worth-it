import { adminCoupons, adminSettings } from "@/lib/admin-data";
import { deleteCoupon, saveCoupon, toggleCoupon } from "@/app/admin/actions";
import ActionForm, { SubmitButton } from "@/components/admin/ActionForm";
import ConfirmButton from "@/components/admin/ConfirmButton";
import { Badge, Empty, PageHeader } from "@/components/admin/ui";
import { formatPrice } from "@/lib/utils";

export const metadata = { title: "Coupons" };

export default async function CouponsPage() {
  const [coupons, s] = await Promise.all([adminCoupons(), adminSettings()]);
  const sym = s.delivery.currency_symbol;
  return (
    <>
      <PageHeader title="Coupons" sub="Customers enter these at checkout." />
      <div className="grid gap-4 lg:grid-cols-[380px_1fr] lg:items-start">
        <section className="a-card">
          <h2 className="mb-3 font-bold">New coupon</h2>
          <ActionForm action={saveCoupon} className="space-y-3" resetOnSuccess>
            <div><label className="a-label" htmlFor="cp-code">Code</label><input id="cp-code" name="code" required className="a-input uppercase" placeholder="WELCOME10" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="a-label" htmlFor="cp-type">Type</label><select id="cp-type" name="type" className="a-input"><option value="percent">Percentage (%)</option><option value="fixed">Fixed amount ({sym})</option></select></div>
              <div><label className="a-label" htmlFor="cp-val">Value</label><input id="cp-val" name="value" required inputMode="decimal" className="a-input" /></div>
              <div><label className="a-label" htmlFor="cp-min">Minimum order</label><input id="cp-min" name="min_order" inputMode="decimal" className="a-input" placeholder="0" /></div>
              <div><label className="a-label" htmlFor="cp-max">Max discount</label><input id="cp-max" name="max_discount" inputMode="decimal" className="a-input" placeholder="No cap" /></div>
              <div><label className="a-label" htmlFor="cp-lim">Usage limit</label><input id="cp-lim" name="usage_limit" inputMode="numeric" className="a-input" placeholder="Unlimited" /></div>
              <div><label className="a-label" htmlFor="cp-exp">Expires on</label><input id="cp-exp" name="expires_at" type="date" className="a-input" /></div>
            </div>
            <SubmitButton>Create coupon</SubmitButton>
          </ActionForm>
        </section>
        <section>
          {coupons.length === 0 ? <Empty title="No coupons yet" text="Create one to offer a discount code." /> : (
            <div className="overflow-x-auto rounded-xl border border-line bg-white"><table className="w-full min-w-[600px]">
              <thead className="border-b border-line bg-paper/60"><tr><th className="a-th">Code</th><th className="a-th">Discount</th><th className="a-th">Rules</th><th className="a-th">Used</th><th className="a-th">Status</th><th className="a-th" /></tr></thead>
              <tbody className="divide-y divide-line">{coupons.map((c) => {
                const expired = c.expires_at && new Date(c.expires_at) < new Date();
                return (
                  <tr key={c.id}><td className="a-td font-mono font-bold">{c.code}</td>
                    <td className="a-td">{c.type === "percent" ? `${c.value}%` : formatPrice(c.value, sym)}{c.max_discount ? <span className="block text-xs text-muted">up to {formatPrice(c.max_discount, sym)}</span> : null}</td>
                    <td className="a-td text-xs text-muted">{c.min_order > 0 ? `Min ${formatPrice(c.min_order, sym)}` : "No minimum"}<br />{c.expires_at ? `Expires ${new Date(c.expires_at).toLocaleDateString("en-GB")}` : "No expiry"}</td>
                    <td className="a-td">{c.used_count}{c.usage_limit ? ` / ${c.usage_limit}` : ""}</td>
                    <td className="a-td"><Badge s={expired ? "cancelled" : c.is_active ? "live" : "draft"}>{expired ? "Expired" : c.is_active ? "Active" : "Inactive"}</Badge></td>
                    <td className="a-td"><div className="flex justify-end gap-1.5">
                      <form action={toggleCoupon}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="value" value={String(!c.is_active)} /><button className="a-btn-ghost !px-3 !py-1.5 text-xs">{c.is_active ? "Deactivate" : "Activate"}</button></form>
                      <form action={deleteCoupon}><input type="hidden" name="id" value={c.id} /><ConfirmButton message={`Delete coupon ${c.code}?`} className="a-btn-danger !px-3 !py-1.5 text-xs">Delete</ConfirmButton></form></div></td></tr>);
              })}</tbody></table></div>)}
        </section>
      </div>
    </>
  );
}
