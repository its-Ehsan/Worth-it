"use server";
import { revalidatePath, revalidateTag } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { assertAdmin } from "@/lib/auth";
import { authClient } from "@/lib/supabase/server";
import { serviceClient } from "@/lib/supabase/admin";
import { mergeSettings } from "@/lib/default-settings";
import { uploadImage } from "@/lib/upload";
import { slugify } from "@/lib/utils";
import { ORDER_STATUSES, type OrderItem, type OrderStatus } from "@/lib/types";

export type Result = { ok?: boolean; message?: string; error?: string; ts?: number };
const done = (message: string): Result => ({ ok: true, message, ts: Date.now() });
const fail = (error: string): Result => ({ ok: false, error, ts: Date.now() });

function refresh() {
  revalidateTag("catalog");
  revalidatePath("/", "layout");
}

/* ---------------- auth ---------------- */
export async function signIn(_: Result, fd: FormData): Promise<Result> {
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const password = String(fd.get("password") ?? "");
  if (!email || !password) return fail("Enter your email and password.");
  const auth = authClient();
  const { data, error } = await auth.auth.signInWithPassword({ email, password });
  if (error || !data.user) return fail("Wrong email or password.");
  const { data: row } = await serviceClient().from("admins").select("user_id").eq("user_id", data.user.id).maybeSingle();
  if (!row) { await auth.auth.signOut(); return fail("This account doesn't have admin access."); }
  redirect("/admin");
}

export async function signOut() {
  await authClient().auth.signOut();
  redirect("/admin/login");
}

/* ---------------- uploads ---------------- */
export async function uploadImageAction(fd: FormData): Promise<{ ok: true; url: string } | { ok: false; error: string }> {
  try {
    await assertAdmin();
    const folder = String(fd.get("folder") ?? "products");
    if (!["products", "categories", "homepage", "brand"].includes(folder)) return { ok: false, error: "Invalid upload folder." };
    const file = fd.get("file");
    if (!(file instanceof File)) return { ok: false, error: "No file selected." };
    const url = await uploadImage(serviceClient(), file, folder as "products", 5 * 1024 * 1024);
    return { ok: true, url };
  } catch (e) { return { ok: false, error: (e as Error).message }; }
}

/* ---------------- products ---------------- */
const num = (v: FormDataEntryValue | null) => { const s = String(v ?? "").trim(); if (s === "") return null; const n = Number(s); return Number.isFinite(n) ? n : NaN; };
const json = <T,>(v: FormDataEntryValue | null, fallback: T): T => { try { return JSON.parse(String(v ?? "")) as T; } catch { return fallback; } };

const ProductSchema = z.object({
  name: z.string().trim().min(2, "Enter a product name").max(140),
  slug: z.string().trim().max(100).optional(),
  short_description: z.string().trim().max(300),
  description: z.string().trim().max(8000),
  price: z.number({ invalid_type_error: "Enter a price" }).min(0, "Price can't be negative").max(10_000_000),
  compare_at_price: z.number().min(0).max(10_000_000).nullable(),
  stock_status: z.enum(["in_stock", "out_of_stock"]),
  stock_qty: z.number().int().min(0).max(1_000_000).nullable(),
  sku: z.string().trim().max(60),
  category_id: z.string().uuid().nullable(),
  tags: z.array(z.string().trim().min(1).max(40)).max(30),
  features: z.array(z.string().trim().min(1).max(200)).max(30),
  images: z.array(z.object({ url: z.string().min(1).max(600), alt: z.string().max(200).optional() })).max(12),
  specs: z.array(z.object({ label: z.string().trim().min(1).max(60), value: z.string().trim().min(1).max(200) })).max(40),
  variants: z.array(z.object({ name: z.string().trim().min(1).max(40), options: z.array(z.string().trim().min(1).max(40)).min(1).max(20) })).max(3),
  related_ids: z.array(z.string().uuid()).max(12),
});

export async function saveProduct(_: Result, fd: FormData): Promise<Result> {
  await assertAdmin();
  const id = String(fd.get("id") ?? "") || null;
  const price = num(fd.get("price")), compare = num(fd.get("compare_at_price")), qty = num(fd.get("stock_qty"));
  const parsed = ProductSchema.safeParse({
    name: fd.get("name") ?? "", slug: fd.get("slug") ?? "", short_description: fd.get("short_description") ?? "", description: fd.get("description") ?? "",
    price: price ?? undefined, compare_at_price: compare, stock_status: fd.get("stock_status") ?? "in_stock", stock_qty: qty, sku: fd.get("sku") ?? "",
    category_id: String(fd.get("category_id") ?? "") || null,
    tags: String(fd.get("tags") ?? "").split(",").map((t) => t.trim().toLowerCase()).filter(Boolean),
    features: String(fd.get("features") ?? "").split("\n").map((t) => t.trim()).filter(Boolean),
    images: json(fd.get("images_json"), []), specs: json(fd.get("specs_json"), []), variants: json(fd.get("variants_json"), []), related_ids: json(fd.get("related_json"), []),
  });
  if (!parsed.success) { const i = parsed.error.issues[0]; return fail(`${i.path.join(" › ") || "Form"}: ${i.message}`); }
  const v = parsed.data;
  if (v.compare_at_price !== null && v.compare_at_price < v.price) return fail("Previous price should be higher than the current price (or leave it empty).");
  // Only allow images from our own storage or the bundled demo art
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
  if (v.images.some((i) => !(i.url.startsWith("/demo/") || (base && i.url.startsWith(base))))) return fail("Images must be uploaded through the uploader.");

  const db = serviceClient();
  let slug = slugify(v.slug || v.name) || "product";
  for (let n = 1; ; n++) {
    const candidate = n === 1 ? slug : `${slug}-${n}`;
    const { data: clash } = await db.from("products").select("id").eq("slug", candidate).maybeSingle();
    if (!clash || clash.id === id) { slug = candidate; break; }
    if (n > 50) return fail("Couldn't create a unique URL. Edit the URL field.");
  }
  const row = {
    ...v, slug, sku: v.sku || null,
    stock_status: v.stock_status,
    is_featured: fd.get("is_featured") === "on", is_trending: fd.get("is_trending") === "on", is_best_seller: fd.get("is_best_seller") === "on",
    is_new_arrival: fd.get("is_new_arrival") === "on", is_published: fd.get("is_published") === "on", cod_available: fd.get("cod_available") === "on",
    updated_at: new Date().toISOString(),
  };
  if (id) {
    const { error } = await db.from("products").update(row).eq("id", id);
    if (error) return fail(error.message.includes("sku") ? "That SKU is already used." : "Couldn't save the product. Please try again.");
    refresh();
    return done("Product saved. Changes are live.");
  }
  const { data, error } = await db.from("products").insert({ ...row, is_demo: false }).select("id").single();
  if (error || !data) return fail("Couldn't create the product. Please try again.");
  refresh();
  redirect(`/admin/products/${data.id}?created=1`);
}

export async function deleteProduct(fd: FormData) {
  await assertAdmin();
  const id = String(fd.get("id") ?? "");
  if (id) await serviceClient().from("products").delete().eq("id", id);
  refresh();
  redirect("/admin/products");
}

export async function setProductFlag(fd: FormData) {
  await assertAdmin();
  const id = String(fd.get("id") ?? ""); const field = String(fd.get("field") ?? ""); const value = fd.get("value") === "true";
  if (!id || !["is_published", "is_featured", "is_trending", "is_best_seller", "is_new_arrival"].includes(field)) return;
  await serviceClient().from("products").update({ [field]: value, updated_at: new Date().toISOString() }).eq("id", id);
  refresh();
}

export async function quickStock(fd: FormData) {
  await assertAdmin();
  const id = String(fd.get("id") ?? ""); const q = num(fd.get("stock_qty"));
  if (!id || (q !== null && (Number.isNaN(q) || q < 0))) return;
  await serviceClient().from("products").update({ stock_qty: q === null ? null : Math.floor(q), stock_status: q === 0 ? "out_of_stock" : "in_stock", updated_at: new Date().toISOString() }).eq("id", id);
  refresh();
}

/* ---------------- categories ---------------- */
export async function saveCategory(_: Result, fd: FormData): Promise<Result> {
  await assertAdmin();
  const id = String(fd.get("id") ?? "") || null;
  const name = String(fd.get("name") ?? "").trim();
  if (name.length < 2) return fail("Enter a category name.");
  const slug = slugify(String(fd.get("slug") ?? "") || name);
  const row = { name: name.slice(0, 60), slug, description: String(fd.get("description") ?? "").slice(0, 300), image_url: String(fd.get("image_url") ?? "") || null, sort_order: Math.floor(Number(fd.get("sort_order") ?? 0)) || 0 };
  const db = serviceClient();
  const { error } = id ? await db.from("categories").update(row).eq("id", id) : await db.from("categories").insert(row);
  if (error) return fail(error.message.includes("duplicate") ? "A category with that URL already exists." : "Couldn't save the category.");
  refresh();
  return done(id ? "Category saved." : "Category added.");
}

export async function deleteCategory(fd: FormData) {
  await assertAdmin();
  const id = String(fd.get("id") ?? "");
  if (id) await serviceClient().from("categories").delete().eq("id", id);
  refresh();
}

/* ---------------- orders ---------------- */
export async function updateOrder(_: Result, fd: FormData): Promise<Result> {
  await assertAdmin();
  const id = String(fd.get("id") ?? "");
  const status = String(fd.get("status") ?? "") as OrderStatus;
  if (!id || !ORDER_STATUSES.includes(status)) return fail("Choose a valid status.");
  const db = serviceClient();
  const { data: order } = await db.from("orders").select("status,items").eq("id", id).single();
  if (!order) return fail("Order not found.");
  const inactive = (s: string) => s === "cancelled" || s === "returned";
  const items = order.items as OrderItem[];
  // Put stock back when an order is cancelled/returned, and take it again if it is reactivated.
  if (inactive(status) !== inactive(order.status)) {
    const sign = inactive(status) ? 1 : -1;
    for (const it of items) {
      const { data: p } = await db.from("products").select("stock_qty,sold_count").eq("id", it.product_id).maybeSingle();
      if (!p) continue;
      await db.from("products").update({ stock_qty: p.stock_qty === null ? null : Math.max(0, p.stock_qty + sign * it.qty), sold_count: Math.max(0, (p.sold_count ?? 0) - sign * it.qty) }).eq("id", it.product_id);
    }
    revalidateTag("catalog");
  }
  const { error } = await db.from("orders").update({ status, admin_note: String(fd.get("admin_note") ?? "").slice(0, 1000), updated_at: new Date().toISOString() }).eq("id", id);
  if (error) return fail("Couldn't update the order.");
  revalidatePath("/admin/orders");
  return done(`Order marked as ${status}.`);
}

/* ---------------- reviews ---------------- */
export async function setReviewStatus(fd: FormData) {
  await assertAdmin();
  const id = String(fd.get("id") ?? ""); const status = String(fd.get("status") ?? "");
  if (!id || !["approved", "rejected", "pending"].includes(status)) return;
  await serviceClient().from("reviews").update({ status }).eq("id", id);
  refresh(); revalidatePath("/admin/reviews");
}
export async function deleteReview(fd: FormData) {
  await assertAdmin();
  const id = String(fd.get("id") ?? "");
  if (id) await serviceClient().from("reviews").delete().eq("id", id);
  refresh(); revalidatePath("/admin/reviews");
}

/* ---------------- coupons ---------------- */
export async function saveCoupon(_: Result, fd: FormData): Promise<Result> {
  await assertAdmin();
  const code = String(fd.get("code") ?? "").trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "");
  const type = fd.get("type") === "percent" ? "percent" : "fixed";
  const value = num(fd.get("value")), min = num(fd.get("min_order")), max = num(fd.get("max_discount")), limit = num(fd.get("usage_limit"));
  const exp = String(fd.get("expires_at") ?? "");
  if (code.length < 3) return fail("Coupon code needs at least 3 letters or numbers.");
  if (value === null || Number.isNaN(value) || value <= 0) return fail("Enter a discount amount above 0.");
  if (type === "percent" && value > 100) return fail("A percentage discount can't be over 100.");
  const { error } = await serviceClient().from("coupons").insert({
    code, type, value, min_order: min && !Number.isNaN(min) ? min : 0, max_discount: max && !Number.isNaN(max) ? max : null,
    usage_limit: limit && !Number.isNaN(limit) ? Math.floor(limit) : null, expires_at: exp ? new Date(`${exp}T23:59:59+06:00`).toISOString() : null, is_active: true,
  });
  if (error) return fail(error.message.includes("duplicate") ? "That code already exists." : "Couldn't create the coupon.");
  revalidatePath("/admin/coupons");
  return done(`Coupon ${code} created.`);
}
export async function toggleCoupon(fd: FormData) {
  await assertAdmin();
  await serviceClient().from("coupons").update({ is_active: fd.get("value") === "true" }).eq("id", String(fd.get("id") ?? ""));
  revalidatePath("/admin/coupons");
}
export async function deleteCoupon(fd: FormData) {
  await assertAdmin();
  await serviceClient().from("coupons").delete().eq("id", String(fd.get("id") ?? ""));
  revalidatePath("/admin/coupons");
}

/* ---------------- settings + homepage ---------------- */
async function patchSettings(patch: (cur: ReturnType<typeof mergeSettings>) => unknown) {
  const db = serviceClient();
  const { data } = await db.from("settings").select("data").eq("id", 1).maybeSingle();
  const next = patch(mergeSettings(data?.data));
  const { error } = await db.from("settings").upsert({ id: 1, data: next, updated_at: new Date().toISOString() });
  return error;
}
const t = (fd: FormData, k: string, max = 500) => String(fd.get(k) ?? "").trim().slice(0, max);
const color = (v: string, d: string) => (/^#[0-9a-fA-F]{6}$/.test(v) ? v : d);
const url = (v: string) => (v === "" || /^(https?:\/\/|\/|tel:|mailto:)/.test(v) ? v : "");

export async function saveHomepage(_: Result, fd: FormData): Promise<Result> {
  await assertAdmin();
  const err = await patchSettings((cur) => ({
    ...cur,
    homepage: {
      announcement: { enabled: fd.get("ann_enabled") === "on", text: t(fd, "ann_text", 200), link: url(t(fd, "ann_link", 200)) },
      hero: {
        eyebrow: t(fd, "hero_eyebrow", 80), title: t(fd, "hero_title", 140), subtitle: t(fd, "hero_subtitle", 400), image: t(fd, "hero_image", 600),
        cta_text: t(fd, "hero_cta_text", 40) || "Shop now", cta_link: url(t(fd, "hero_cta_link", 200)) || "/shop",
        secondary_text: t(fd, "hero_sec_text", 40), secondary_link: url(t(fd, "hero_sec_link", 200)), product_id: t(fd, "hero_product_id", 60),
      },
      banners: [0, 1].map((i) => ({ title: t(fd, `banner_${i}_title`, 80), subtitle: t(fd, `banner_${i}_subtitle`, 200), image: t(fd, `banner_${i}_image`, 600), link: url(t(fd, `banner_${i}_link`, 200)) })).filter((b) => b.title),
      sections: Object.fromEntries(["trending", "new_arrivals", "best_sellers", "discovery", "reviews", "faq"].map((k) => [k, fd.get(`sec_${k}`) === "on"])),
      trust: [0, 1, 2, 3].map((i) => ({ title: t(fd, `trust_${i}_title`, 60), text: t(fd, `trust_${i}_text`, 200) })).filter((x) => x.title),
      stats: [0, 1, 2].map((i) => ({ value: t(fd, `stat_${i}_value`, 20), label: t(fd, `stat_${i}_label`, 60) })).filter((x) => x.value),
      final_cta: { title: t(fd, "cta_title", 140), subtitle: t(fd, "cta_subtitle", 300), button_text: t(fd, "cta_button_text", 40) || "Shop now", button_link: url(t(fd, "cta_button_link", 200)) || "/shop" },
    },
  }));
  if (err) return fail("Couldn't save the homepage.");
  refresh();
  return done("Homepage updated. Changes are live.");
}

function parseFaq(text: string) {
  return text.replace(/\r/g, "").split(/\n{2,}/).map((b) => {
    const lines = b.trim().split("\n");
    const q = lines[0]?.replace(/^Q:\s*/i, "").trim();
    const a = lines.slice(1).join(" ").replace(/^A:\s*/i, "").trim();
    return { q, a };
  }).filter((f) => f.q && f.a);
}

export async function saveSettings(_: Result, fd: FormData): Promise<Result> {
  await assertAdmin();
  const err = await patchSettings((cur) => ({
    ...cur,
    brand: { name: t(fd, "brand_name", 40) || "BRAND", tagline: t(fd, "brand_tagline", 120), logo_url: t(fd, "brand_logo", 600), logo_with_name: fd.get("brand_logo_with_name") === "on", favicon_url: t(fd, "brand_favicon", 600), og_image: t(fd, "brand_og", 600),
      primary_color: color(t(fd, "brand_primary", 9), cur.brand.primary_color), secondary_color: color(t(fd, "brand_secondary", 9), cur.brand.secondary_color) },
    contact: { email: t(fd, "c_email", 120), phone: t(fd, "c_phone", 30), whatsapp: t(fd, "c_whatsapp", 30), address: t(fd, "c_address", 200), hours: t(fd, "c_hours", 120),
      facebook: url(t(fd, "c_facebook", 300)), instagram: url(t(fd, "c_instagram", 300)), youtube: url(t(fd, "c_youtube", 300)), tiktok: url(t(fd, "c_tiktok", 300)) },
    delivery: { inside_dhaka_fee: Math.max(0, Number(fd.get("d_in_fee")) || 0), outside_dhaka_fee: Math.max(0, Number(fd.get("d_out_fee")) || 0), free_above: Math.max(0, Number(fd.get("d_free")) || 0),
      inside_dhaka_eta: t(fd, "d_in_eta", 60), outside_dhaka_eta: t(fd, "d_out_eta", 60), cod_note: t(fd, "d_cod", 300), currency_symbol: t(fd, "d_symbol", 4) || "৳" },
    pages: { about: t(fd, "p_about", 8000), shipping: t(fd, "p_shipping", 8000), returns: t(fd, "p_returns", 8000), privacy: t(fd, "p_privacy", 8000), terms: t(fd, "p_terms", 8000), faq: parseFaq(t(fd, "p_faq", 12000)) },
    seo: { title: t(fd, "seo_title", 70), description: t(fd, "seo_description", 200) },
    low_stock_threshold: Math.max(0, Math.floor(Number(fd.get("low_stock")) || 5)),
  }));
  if (err) return fail("Couldn't save settings.");
  refresh();
  return done("Settings saved. Changes are live.");
}
