import { redirect } from "next/navigation";
import { getAdminUser } from "@/lib/auth";
import { isSupabaseConfigured } from "@/lib/supabase/public";
import { getSettings } from "@/lib/data";
import LoginForm from "@/components/admin/LoginForm";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  if (await getAdminUser()) redirect("/admin");
  const s = await getSettings();
  const configured = isSupabaseConfigured() && !!process.env.SUPABASE_SERVICE_ROLE_KEY;
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <p className="mb-6 text-center font-display text-2xl font-extrabold">{s.brand.name} <span className="text-muted">Admin</span></p>
        {configured ? <LoginForm /> : (
          <div className="a-card text-sm leading-relaxed">
            <p className="font-bold">Database not connected yet</p>
            <p className="mt-2 text-muted">Copy <code>.env.example</code> to <code>.env.local</code>, add your Supabase URL, anon key and service-role key, run <code>supabase/schema.sql</code>, then create your admin with <code>npm run create-admin</code>. The README walks through each step.</p>
          </div>
        )}
      </div>
    </div>
  );
}
