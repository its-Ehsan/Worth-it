import { NextResponse } from "next/server";
import { getCategories, getProducts } from "@/lib/data";
import { filterProducts } from "@/lib/catalog";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const [products, cats] = await Promise.all([getProducts(), getCategories()]);

  if (searchParams.get("trending")) {
    const trending = products.filter((p) => p.is_trending || p.is_best_seller).slice(0, 5).map((p) => p.name);
    return NextResponse.json({ trending }, { headers: { "Cache-Control": "public, s-maxage=300" } });
  }
  const q = (searchParams.get("q") ?? "").slice(0, 80);
  if (q.trim().length < 2) return NextResponse.json({ results: [] });
  const catName = new Map(cats.map((c) => [c.id, c.name]));
  const results = filterProducts(products, cats, { q }).slice(0, 6).map((p) => ({
    slug: p.slug, name: p.name, price: p.price, image: p.images[0]?.url ?? null, category: catName.get(p.category_id ?? "") ?? null,
  }));
  return NextResponse.json({ results }, { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } });
}
