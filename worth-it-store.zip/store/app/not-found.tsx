import Link from "next/link";
export default function NotFound() {
  return (
    <div className="container-x flex min-h-[70vh] flex-col items-center justify-center py-20 text-center">
      <p className="font-display text-7xl font-extrabold text-brand-soft sm:text-8xl">404</p>
      <h1 className="mt-4 text-3xl font-extrabold">We couldn&apos;t find that page</h1>
      <p className="mt-2 max-w-sm text-muted">The link may be old, or the product may have been removed.</p>
      <div className="mt-6 flex gap-3"><Link href="/" className="btn-dark">Go home</Link><Link href="/shop" className="btn-ghost">Browse gadgets</Link></div>
    </div>
  );
}
