# Gadget Store

A mobile-first e-commerce site for your own gadget brand, built with Next.js 14 (App Router), TypeScript, Tailwind CSS and Supabase.
It has its own brand, products, orders and admin panel. ZENYX (or any supplier) is only how you fulfil orders; nothing here refers to it.

Everything you will want to change later (brand name, logo, colours, products, homepage, delivery fees, policy text) is edited in `/admin`. No code edits needed.

---

## 1. Run it locally (preview mode, 2 minutes)

```bash
npm install
npm run dev
```

Open http://localhost:3000. With no Supabase keys the site runs in **preview mode** with built-in demo products so you can click around.
In preview mode the admin and real orders are disabled (checkout simulates an order number).

## 2. Connect your database (to use the admin and take real orders)

1. Create a free project at https://supabase.com.
2. Supabase dashboard > **SQL Editor** > paste all of `supabase/schema.sql` > **Run**. This creates the tables, security rules and the `media` image bucket.
3. Supabase dashboard > **Project Settings > API**. Copy the project URL, the `anon` key and the `service_role` key.
4. `cp .env.example .env.local` and fill in the three values. **The service-role key is a secret: never share it, never commit it, never put it in `NEXT_PUBLIC_` variables.**
5. Create your admin login:
   ```bash
   npm run create-admin -- you@example.com "a-long-strong-password"
   ```
6. (Optional) Add demo products so the site is not empty: `npm run seed:demo`. Remove them any time with `npm run clear:demo` (it only deletes rows flagged demo; your real data is never touched).
7. `npm run dev`, then open http://localhost:3000/admin and sign in.

## Brand & theme

The store ships as **Worth it** ("Things actually worth having") with a fully dark purple theme and your W logo (`public/brand/`).
Change the name, tagline, logo, favicon and purple accent any time in Admin > Settings > Brand. The dark purple surfaces live as CSS variables at the top of `app/globals.css` (`--paper`, `--surface`, `--deep`, `--line`). The admin panel is deliberately a light workspace (scoped by `.admin-light`) so forms stay easy to read.

## 3. Daily use (admin)

| Task | Where |
|---|---|
| Add a product | Products > Add product: upload images, set price, stock, publish. It is live immediately. |
| Stock | Type a number (e.g. 7) to count down automatically with each order, or leave empty for "In stock". 0 or "Out of stock" shows Sold out. Quick edit on the Products list. |
| Hide a product | Products > Unpublish |
| Orders | Orders > open one > change status. Cancelled/Returned puts the stock back. |
| Reviews | Customers review with their order number + phone. Approve or reject under Reviews. Only approved reviews are public. |
| Coupons | Coupons > fixed or percentage, minimum order, max discount, expiry, usage limit |
| Brand, logo, colours, contact, delivery, policy pages, FAQ | Settings |
| Hero, banners, announcement bar, sections, social proof | Homepage |

Product rows on the homepage are driven by the switches on each product: Featured, Trending, Best seller, New arrival.

## 4. Deploy (Vercel + Supabase)

1. Push this folder to a GitHub repository (`.env.local` is git-ignored).
2. Import the repo at https://vercel.com/new.
3. Add environment variables in Vercel: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_SITE_URL` (your real domain, e.g. `https://yourbrand.com`).
4. Deploy, add your domain in Vercel, then set `NEXT_PUBLIC_SITE_URL` to it and redeploy (sitemap, canonical URLs and structured data use it).
5. Check `https://your-domain/admin`, `/sitemap.xml` and `/robots.txt`.

## 5. Security notes

- The browser only holds the public `anon` key. Row Level Security lets it read published products, categories, settings and approved reviews. Nothing else.
- Every write (products, orders, reviews, settings, uploads) runs in a server action using the service-role key, after a server-side admin check against the `admins` table. `/admin/*` is also gated in middleware.
- Prices are always recomputed on the server from the database, and stock/coupons are re-validated at order time.
- Uploads are limited to JPG/PNG/WebP/AVIF, 5 MB, verified by file signature (not just extension).
- Forms are validated with Zod. The order form has a honeypot and a per-phone hourly limit.
- For a busy store, add Supabase Auth rate limits and a CAPTCHA on checkout.

## 6. Project map

```
app/(shop)/…        public pages (home, shop, category, product, search, cart, checkout, order, policies)
app/admin/…         admin panel + server actions (actions.ts)
app/actions/shop.ts public server actions: place order, coupon check, submit review
lib/data.ts         catalog reads (cached, tag "catalog", instantly refreshed after admin edits)
lib/catalog.ts      search, filters, sorting
lib/default-settings.ts  fallback brand/homepage/policy content (overridden by the admin)
lib/demo-data.ts    DEMO data only, separate from production data
supabase/schema.sql database + security rules
scripts/            seed-demo, create-admin, selftest
```

## 7. Adding things later

- **bKash / Nagad / card**: add a payment step in `components/shop/CheckoutForm.tsx`, and a `payment_method` branch in `placeOrder` (`app/actions/shop.ts`). Orders already store `payment_method`.
- **Facebook Pixel / Meta Conversions API / GA**: add the script in `app/layout.tsx`; fire `Purchase` from the order confirmation page; send server events from `placeOrder`.
- **Email/SMS/WhatsApp notifications**: call your provider at the end of `placeOrder`.
- **Wishlist, customer accounts, abandoned cart**: Supabase Auth is already wired for admins; customers are grouped by phone today.
- **Larger catalogue (thousands of products)**: `lib/data.ts` loads the published catalogue and filters in memory (fast and cached for hundreds of products). Move search/filter into SQL queries when you outgrow it.

## 8. Known limits (MVP)

- No contact form (contact page links to call/WhatsApp/email).
- Coupons can be created, toggled and deleted but not edited.
- Customers are guests; the Customers page is built from orders.
- Product search is simple term matching (name, category, tags, description, features), not typo-tolerant.

## 9. Checks

`npm run typecheck`, `npm run build`, and `npx tsx scripts/selftest.ts` (search, filters, coupon rules, settings merge, phone validation).
