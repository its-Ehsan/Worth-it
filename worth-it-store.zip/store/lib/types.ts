export type StockStatus = "in_stock" | "out_of_stock";

export interface ProductImage { url: string; alt?: string }
export interface Spec { label: string; value: string }
export interface Variant { name: string; options: string[] }

export interface Product {
  id: string;
  slug: string;
  name: string;
  short_description: string;
  description: string;
  price: number;
  compare_at_price: number | null;
  stock_status: StockStatus;
  stock_qty: number | null;
  sku: string | null;
  category_id: string | null;
  tags: string[];
  images: ProductImage[];
  specs: Spec[];
  features: string[];
  variants: Variant[];
  related_ids: string[];
  is_featured: boolean;
  is_trending: boolean;
  is_best_seller: boolean;
  is_new_arrival: boolean;
  is_published: boolean;
  cod_available: boolean;
  sold_count: number;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
  // computed
  rating_avg?: number;
  rating_count?: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string | null;
  sort_order: number;
  is_demo?: boolean;
}

export interface Review {
  id: string;
  product_id: string;
  order_number: string | null;
  author_name: string;
  rating: number;
  body: string;
  image_url: string | null;
  status: "pending" | "approved" | "rejected";
  created_at: string;
  is_demo?: boolean;
}

export type OrderStatus = "pending" | "confirmed" | "processing" | "shipped" | "delivered" | "cancelled" | "returned";
export const ORDER_STATUSES: OrderStatus[] = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"];

export interface OrderItem {
  product_id: string;
  name: string;
  sku: string | null;
  price: number;
  qty: number;
  variant: string;
  image: string | null;
}

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  phone: string;
  district: string;
  area: string;
  address: string;
  notes: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  delivery_fee: number;
  total: number;
  coupon_code: string | null;
  payment_method: string;
  status: OrderStatus;
  admin_note: string;
  created_at: string;
  updated_at: string;
}

export interface Coupon {
  id: string;
  code: string;
  type: "fixed" | "percent";
  value: number;
  min_order: number;
  max_discount: number | null;
  expires_at: string | null;
  usage_limit: number | null;
  used_count: number;
  is_active: boolean;
  created_at: string;
}

export interface Banner { title: string; subtitle: string; image: string; link: string }
export interface FaqItem { q: string; a: string }
export interface TrustItem { title: string; text: string }
export interface StatItem { value: string; label: string }

export interface SiteSettings {
  brand: {
    name: string; tagline: string; logo_url: string; logo_with_name: boolean; favicon_url: string;
    primary_color: string; secondary_color: string; og_image: string;
  };
  contact: {
    email: string; phone: string; whatsapp: string; address: string; hours: string;
    facebook: string; instagram: string; youtube: string; tiktok: string;
  };
  delivery: {
    inside_dhaka_fee: number; outside_dhaka_fee: number; free_above: number;
    inside_dhaka_eta: string; outside_dhaka_eta: string; cod_note: string; currency_symbol: string;
  };
  homepage: {
    announcement: { enabled: boolean; text: string; link: string };
    hero: {
      eyebrow: string; title: string; subtitle: string; image: string;
      cta_text: string; cta_link: string; secondary_text: string; secondary_link: string;
      product_id: string;
    };
    banners: Banner[];
    sections: { trending: boolean; new_arrivals: boolean; best_sellers: boolean; discovery: boolean; reviews: boolean; faq: boolean };
    trust: TrustItem[];
    stats: StatItem[];
    final_cta: { title: string; subtitle: string; button_text: string; button_link: string };
  };
  pages: {
    about: string; shipping: string; returns: string; privacy: string; terms: string;
    faq: FaqItem[];
  };
  seo: { title: string; description: string };
  low_stock_threshold: number;
}

export interface CartItem {
  key: string;
  productId: string;
  slug: string;
  name: string;
  price: number;
  image: string | null;
  variant: string;
  qty: number;
  maxQty: number | null;
}
