import "server-only";
import { redirect } from "next/navigation";
import { authClient } from "./supabase/server";
import { serviceClient } from "./supabase/admin";
import { isSupabaseConfigured } from "./supabase/public";

/** Returns the signed-in admin user, or null. Verifies against the `admins` table server-side. */
export async function getAdminUser() {
  if (!isSupabaseConfigured() || !process.env.SUPABASE_SERVICE_ROLE_KEY) return null;
  const { data } = await authClient().auth.getUser(); // validates the JWT with Supabase
  const user = data.user;
  if (!user) return null;
  const { data: row } = await serviceClient().from("admins").select("user_id").eq("user_id", user.id).maybeSingle();
  return row ? user : null;
}

/** Use at the top of every admin page / server action. */
export async function requireAdmin() {
  const user = await getAdminUser();
  if (!user) redirect("/admin/login");
  return user;
}

/** For server actions: throws instead of redirecting. */
export async function assertAdmin() {
  const user = await getAdminUser();
  if (!user) throw new Error("Not authorised");
  return user;
}
