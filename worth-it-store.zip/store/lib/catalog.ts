import type { Category, Product } from "./types";
import { isPurchasable } from "./utils";

export type SortKey = "featured" | "newest" | "price-asc" | "price-desc" | "best";

export interface Filters {
  q?: string; category?: string; min?: number; max?: number;
  inStock?: boolean; rating?: number; sort?: SortKey;
}

const norm = (s: string) => s.toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();

/** Scores a product against a query across name, category, tags and descriptions. 0 = no match. */
export function searchScore(p: Product, cat: Category | undefined, q: string) {
  const terms = norm(q).split(" ").filter(Boolean);
  if (!terms.length) return 1;
  const name = norm(p.name), tags = norm(p.tags.join(" ")), c = norm(cat?.name ?? ""), d = norm(`${p.short_description} ${p.description} ${p.features.join(" ")}`);
  let total = 0;
  for (const t of terms) {
    let s = 0;
    if (name.startsWith(t)) s += 12; else if (name.includes(t)) s += 8;
    if (tags.includes(t)) s += 5;
    if (c.includes(t)) s += 4;
    if (d.includes(t)) s += 1;
    if (!s) return 0; // every term must match something
    total += s;
  }
  return total;
}

export function filterProducts(all: Product[], cats: Category[], f: Filters): Product[] {
  const catById = new Map(cats.map((c) => [c.id, c]));
  const catBySlug = new Map(cats.map((c) => [c.slug, c]));
  let list = all.map((p) => ({ p, score: f.q ? searchScore(p, catById.get(p.category_id ?? ""), f.q) : 1 }));
  if (f.q) list = list.filter((x) => x.score > 0);
  if (f.category) {
    const c = catBySlug.get(f.category);
    list = list.filter((x) => (c ? x.p.category_id === c.id : false));
  }
  if (f.min !== undefined) list = list.filter((x) => x.p.price >= f.min!);
  if (f.max !== undefined) list = list.filter((x) => x.p.price <= f.max!);
  if (f.inStock) list = list.filter((x) => isPurchasable(x.p));
  if (f.rating) list = list.filter((x) => (x.p.rating_avg ?? 0) >= f.rating!);

  const sort = f.sort ?? (f.q ? undefined : "featured");
  const t = (p: Product) => +new Date(p.created_at);
  list.sort((a, b) => {
    switch (sort) {
      case "newest": return t(b.p) - t(a.p);
      case "price-asc": return a.p.price - b.p.price;
      case "price-desc": return b.p.price - a.p.price;
      case "best": return b.p.sold_count - a.p.sold_count;
      case "featured": return Number(b.p.is_featured) - Number(a.p.is_featured) || Number(isPurchasable(b.p)) - Number(isPurchasable(a.p)) || b.p.sold_count - a.p.sold_count;
      default: return b.score - a.score || b.p.sold_count - a.p.sold_count; // relevance
    }
  });
  return list.map((x) => x.p);
}

export function parseFilters(sp: Record<string, string | string[] | undefined>): Filters {
  const s = (k: string) => { const v = sp[k]; return Array.isArray(v) ? v[0] : v; };
  const num = (k: string) => { const v = s(k); if (v === undefined || v === "") return undefined; const n = Number(v); return Number.isFinite(n) && n >= 0 ? n : undefined; };
  const sort = s("sort") as SortKey | undefined;
  return {
    q: s("q")?.slice(0, 80), category: s("category"), min: num("min"), max: num("max"),
    inStock: s("stock") === "1", rating: num("rating"),
    sort: sort && ["featured", "newest", "price-asc", "price-desc", "best"].includes(sort) ? sort : undefined,
  };
}

export function relatedProducts(all: Product[], p: Product, limit = 4) {
  const chosen = p.related_ids.map((id) => all.find((x) => x.id === id)).filter((x): x is Product => !!x);
  if (chosen.length >= limit) return chosen.slice(0, limit);
  const rest = all.filter((x) => x.id !== p.id && !chosen.includes(x))
    .sort((a, b) => Number(b.category_id === p.category_id) - Number(a.category_id === p.category_id) || b.sold_count - a.sold_count);
  return [...chosen, ...rest].slice(0, limit);
}
