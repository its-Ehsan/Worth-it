import "server-only";
import { randomBytes } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";

const MAX = 5 * 1024 * 1024;
const TYPES: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/avif": "avif" };

/** Detects the real file type from magic bytes, so renamed/spoofed files are rejected. */
function sniff(b: Uint8Array): string | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  if (b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70 && b[8] === 0x61 && b[9] === 0x76 && b[10] === 0x69 && b[11] === 0x66) return "image/avif";
  return null;
}

export async function uploadImage(db: SupabaseClient, file: File, folder: "products" | "categories" | "homepage" | "brand" | "reviews", maxBytes = MAX) {
  if (!file || typeof file === "string" || file.size === 0) throw new Error("No file selected.");
  if (file.size > maxBytes) throw new Error(`Image is too large. Maximum size is ${Math.round(maxBytes / 1024 / 1024)} MB.`);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const type = sniff(bytes);
  if (!type || !TYPES[type] || (file.type && !TYPES[file.type])) throw new Error("Only JPG, PNG, WebP or AVIF images are allowed.");
  const path = `${folder}/${Date.now()}-${randomBytes(6).toString("hex")}.${TYPES[type]}`;
  const { error } = await db.storage.from("media").upload(path, bytes, { contentType: type, cacheControl: "31536000", upsert: false });
  if (error) throw new Error("Upload failed. Please try again.");
  return db.storage.from("media").getPublicUrl(path).data.publicUrl;
}
