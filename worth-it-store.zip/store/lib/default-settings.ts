import type { SiteSettings } from "./types";

/**
 * Fallback values used until you save real ones in Admin -> Settings / Homepage.
 * Nothing here is hardcoded into the UI: components always read merged settings.
 */
export const DEFAULT_SETTINGS: SiteSettings = {
  brand: {
    name: "Worth it",
    tagline: "Things actually worth having",
    logo_url: "/brand/logo.png",
    logo_with_name: true,
    favicon_url: "/brand/favicon.png",
    primary_color: "#7C3AED",
    secondary_color: "#C026D3",
    og_image: "/brand/og.jpg",
  },
  contact: {
    email: "hello@example.com",
    phone: "+8801700000000",
    whatsapp: "8801700000000",
    address: "Chattogram, Bangladesh",
    hours: "Every day, 10:00 AM to 10:00 PM",
    facebook: "",
    instagram: "",
    youtube: "",
    tiktok: "",
  },
  delivery: {
    inside_dhaka_fee: 70,
    outside_dhaka_fee: 130,
    free_above: 5000,
    inside_dhaka_eta: "1-2 working days",
    outside_dhaka_eta: "2-4 working days",
    cod_note: "Pay in cash when your order arrives. Check the product before you pay.",
    currency_symbol: "৳",
  },
  homepage: {
    announcement: { enabled: true, text: "Cash on delivery across Bangladesh. Free delivery on orders over ৳5,000.", link: "/shipping" },
    hero: {
      eyebrow: "Things actually worth having",
      title: "Gadgets that earn their place.",
      subtitle: "Audio, power and desk gear we would buy ourselves. Checked before it ships, delivered to your door, paid for when it arrives.",
      image: "",
      cta_text: "Shop gadgets",
      cta_link: "/shop",
      secondary_text: "See what's trending",
      secondary_link: "/shop?sort=best",
      product_id: "",
    },
    banners: [
      { title: "Power that keeps up", subtitle: "Chargers and power banks for a full day away from the wall.", image: "", link: "/shop" },
      { title: "A calmer desk", subtitle: "Keyboards, lamps and hubs that make the workspace feel finished.", image: "", link: "/shop" },
    ],
    sections: { trending: true, new_arrivals: true, best_sellers: true, discovery: true, reviews: true, faq: true },
    trust: [
      { title: "Cash on delivery", text: "Pay when the parcel reaches you. No card, no advance." },
      { title: "Checked before dispatch", text: "Every order is opened, tested and sealed before it leaves." },
      { title: "Easy returns", text: "Faulty or wrong item? We replace or refund it." },
      { title: "Real people on call", text: "Message or call and a person answers, in Bangla or English." },
    ],
    stats: [
      { value: "4.8/5", label: "average review score" },
      { value: "2-4 days", label: "delivery nationwide" },
      { value: "7 days", label: "return window" },
    ],
    final_cta: {
      title: "Find the gadget you'll keep using.",
      subtitle: "Browse the full range, or message us and we'll help you pick.",
      button_text: "Start shopping",
      button_link: "/shop",
    },
  },
  pages: {
    about: "## Who we are\nWorth it is a small team that picks gadgets we would use ourselves and sells them at honest prices. If it is not actually worth having, it does not make the shelf.\n\n## What we care about\nGood products, clear descriptions, fast delivery, and being easy to reach when something goes wrong.\n\nEdit this text in Admin -> Settings -> Pages.",
    shipping: "## Delivery areas\nWe deliver to all 64 districts of Bangladesh.\n\n## Delivery time\nInside Dhaka: 1-2 working days. Outside Dhaka: 2-4 working days.\n\n## Delivery charge\nInside Dhaka ৳70, outside Dhaka ৳130. Free delivery on orders over ৳5,000.\n\n## Payment\nCash on delivery. Pay the courier when your parcel arrives. Please check the product in front of the courier.",
    returns: "## 7-day return window\nIf your item arrives faulty, damaged or different from what you ordered, contact us within 7 days of delivery.\n\n## How it works\nSend us your order number and a photo or short video. We will arrange a replacement or refund after verifying the issue.\n\n## Not covered\nDamage caused after delivery, missing original packaging, or change of mind on opened items.",
    privacy: "## What we collect\nName, phone number and delivery address, only to fulfil your order and contact you about it.\n\n## How we use it\nWe share delivery details with our courier partners. We do not sell your data.\n\n## Your choices\nContact us any time to correct or delete your information.",
    terms: "## Orders\nAn order is confirmed once our team has contacted you or marked it confirmed.\n\n## Pricing\nPrices are in Bangladeshi Taka and may change without notice. The price at the time you order is the price you pay.\n\n## Availability\nStock is limited. If an item sells out after you order, we will contact you with options.",
    faq: [
      { q: "Do you offer cash on delivery?", a: "Yes. Cash on delivery is available across Bangladesh. You pay the courier when the parcel arrives." },
      { q: "How long does delivery take?", a: "Usually 1-2 working days inside Dhaka and 2-4 working days elsewhere." },
      { q: "Can I check the product before paying?", a: "Yes. Please open and check the parcel in front of the courier before you pay." },
      { q: "What if my product is faulty?", a: "Contact us within 7 days of delivery with your order number and a photo. We will replace or refund it." },
      { q: "Do I need an account to order?", a: "No. You can check out as a guest with your name, phone number and address." },
    ],
  },
  seo: { title: "", description: "Premium gadgets delivered across Bangladesh with cash on delivery." },
  low_stock_threshold: 5,
};

export function mergeSettings(stored: unknown): SiteSettings {
  const base = structuredClone(DEFAULT_SETTINGS) as unknown as Record<string, unknown>;
  if (!stored || typeof stored !== "object") return base as unknown as SiteSettings;
  const s = stored as Record<string, unknown>;
  for (const key of Object.keys(base)) {
    const v = s[key];
    if (v === undefined || v === null) continue;
    const b = base[key];
    if (b && typeof b === "object" && !Array.isArray(b) && typeof v === "object" && !Array.isArray(v)) {
      const merged: Record<string, unknown> = { ...(b as object) };
      for (const [k, val] of Object.entries(v as object)) {
        const bb = (b as Record<string, unknown>)[k];
        if (bb && typeof bb === "object" && !Array.isArray(bb) && val && typeof val === "object" && !Array.isArray(val)) {
          merged[k] = { ...(bb as object), ...(val as object) };
        } else if (val !== undefined && val !== null) merged[k] = val;
      }
      base[key] = merged;
    } else base[key] = v;
  }
  return base as unknown as SiteSettings;
}
