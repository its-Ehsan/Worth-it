export function cn(...c: (string | false | null | undefined)[]) { return c.filter(Boolean).join(" "); }

export function formatPrice(n: number, symbol = "৳") {
  return `${symbol}${Math.round(n).toLocaleString("en-US")}`;
}

export function slugify(s: string) {
  return s.toLowerCase().trim().replace(/['’]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}

export function discountPercent(price: number, compare: number | null) {
  if (!compare || compare <= price) return 0;
  return Math.round(((compare - price) / compare) * 100);
}

export function hexToRgbTriplet(hex: string, fallback = "124 58 237") {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return fallback;
  const n = parseInt(m[1], 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

export function lightenHex(hex: string, amount: number) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return "#A78BFA";
  const n = parseInt(m[1], 16);
  const mix = (c: number) => Math.round(c + (255 - c) * amount);
  return "#" + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => mix(c).toString(16).padStart(2, "0")).join("");
}

export function timeAgo(iso: string) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} hr ago`;
  if (s < 86400 * 30) return `${Math.floor(s / 86400)} days ago`;
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

export function siteUrl() {
  return (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");
}

export function stockLabel(p: { stock_status: string; stock_qty: number | null }) {
  if (p.stock_status === "out_of_stock" || p.stock_qty === 0) return { text: "Out of stock", tone: "out" as const };
  if (p.stock_qty !== null && p.stock_qty <= 5) return { text: `Only ${p.stock_qty} left`, tone: "low" as const };
  return { text: "In stock", tone: "in" as const };
}

export function isPurchasable(p: { stock_status: string; stock_qty: number | null }) {
  return p.stock_status !== "out_of_stock" && p.stock_qty !== 0;
}
