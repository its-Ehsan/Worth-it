import { createClient } from "@supabase/supabase-js";

export const isSupabaseConfigured = () =>
  !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

/** Read-only client for public catalog data. Results are cached and tagged "catalog"
 *  so admin changes can invalidate them instantly with revalidateTag("catalog"). */
export function publicClient() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => fetch(input, { ...init, next: { tags: ["catalog"], revalidate: 3600 } }),
    },
  });
}
