import "server-only";
import { createClient } from "@supabase/supabase-js";

/** Service-role client. SERVER ONLY: bypasses RLS. Only call after verifying the caller
 *  is an admin (see requireAdmin) or inside a validated public server action (orders/reviews). */
export function serviceClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Supabase service role is not configured. Check your environment variables.");
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: (input, init) => fetch(input, { ...init, cache: "no-store" }) },
  });
}
