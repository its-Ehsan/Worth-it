import type { Coupon } from "./types";

/** Returns the discount for a coupon or a human-readable reason it can't be used. */
export function applyCoupon(c: Coupon | null, subtotal: number): { ok: true; discount: number } | { ok: false; error: string } {
  if (!c || !c.is_active) return { ok: false, error: "That coupon code isn't valid." };
  if (c.expires_at && new Date(c.expires_at).getTime() < Date.now()) return { ok: false, error: "This coupon has expired." };
  if (c.usage_limit !== null && c.used_count >= c.usage_limit) return { ok: false, error: "This coupon has reached its usage limit." };
  if (subtotal < Number(c.min_order ?? 0)) return { ok: false, error: `Spend at least ৳${Number(c.min_order).toLocaleString("en-US")} to use this coupon.` };
  let d = c.type === "percent" ? (subtotal * Number(c.value)) / 100 : Number(c.value);
  if (c.max_discount !== null && c.max_discount !== undefined) d = Math.min(d, Number(c.max_discount));
  d = Math.max(0, Math.min(Math.round(d), subtotal));
  return { ok: true, discount: d };
}
