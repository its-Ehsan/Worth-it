import "server-only";
import { serviceClient } from "./supabase/admin";
import { mergeSettings } from "./default-settings";
import type { Category, Coupon, Order, Product, Review } from "./types";

export const db = serviceClient;

export async function adminSettings() {
  const { data } = await db().from("settings").select("data").eq("id", 1).maybeSingle();
  return mergeSettings(data?.data);
}
export async function adminProducts(): Promise<Product[]> {
  const { data } = await db().from("products").select("*").order("created_at", { ascending: false });
  return (data ?? []) as Product[];
}
export async function adminCategories(): Promise<Category[]> {
  const { data } = await db().from("categories").select("*").order("sort_order").order("name");
  return (data ?? []) as Category[];
}
export async function adminOrders(limit = 1000): Promise<Order[]> {
  const { data } = await db().from("orders").select("*").order("created_at", { ascending: false }).limit(limit);
  return (data ?? []) as Order[];
}
export async function adminReviews(): Promise<(Review & { product_name?: string })[]> {
  const [{ data: r }, { data: p }] = await Promise.all([db().from("reviews").select("*").order("created_at", { ascending: false }), db().from("products").select("id,name")]);
  const name = new Map((p ?? []).map((x) => [x.id as string, x.name as string]));
  return ((r ?? []) as Review[]).map((x) => ({ ...x, product_name: name.get(x.product_id) }));
}
export async function adminCoupons(): Promise<Coupon[]> {
  const { data } = await db().from("coupons").select("*").order("created_at", { ascending: false });
  return (data ?? []) as Coupon[];
}
