/**
 * DEMO DATA ONLY. Not production data.
 * - Used automatically when Supabase env vars are missing (so you can preview the site).
 * - `npm run seed:demo` copies it into Supabase flagged is_demo=true.
 * - `npm run clear:demo` removes every is_demo row. Real products you add in /admin are never touched.
 */
import type { Category, Product, Review } from "./types";

const day = 86400000;
const ago = (d: number) => new Date(Date.now() - d * day).toISOString();
const pid = (n: number) => `00000000-0000-4000-8000-${n.toString(16).padStart(12, "0")}`;
const cid = (n: number) => `10000000-0000-4000-8000-${n.toString(16).padStart(12, "0")}`;
const rid = (n: number) => `20000000-0000-4000-8000-${n.toString(16).padStart(12, "0")}`;

export const DEMO_CATEGORIES: Category[] = [
  { id: cid(1), name: "Audio", slug: "audio", description: "Earbuds and speakers that sound as good as they look.", image_url: "/demo/cat-audio.svg", sort_order: 1, is_demo: true },
  { id: cid(2), name: "Wearables", slug: "wearables", description: "Smartwatches and trackers for everyday life.", image_url: "/demo/cat-wearables.svg", sort_order: 2, is_demo: true },
  { id: cid(3), name: "Power", slug: "power", description: "Chargers and power banks for a full day away from the wall.", image_url: "/demo/cat-power.svg", sort_order: 3, is_demo: true },
  { id: cid(4), name: "Desk & Work", slug: "desk", description: "Keyboards, mice, lights and hubs for a calmer desk.", image_url: "/demo/cat-desk.svg", sort_order: 4, is_demo: true },
];

type Seed = {
  n: number; slug: string; img: string; name: string; short: string; cat: number; price: number; was?: number;
  qty?: number | null; out?: boolean; tags: string[]; features: string[]; specs: [string, string][];
  variants?: { name: string; options: string[] }[]; flags: Partial<Pick<Product, "is_featured" | "is_trending" | "is_best_seller" | "is_new_arrival">>;
  sold: number; age: number; related: number[]; desc: string;
};

const seeds: Seed[] = [
  { n: 1, slug: "pulse-buds-pro", img: "earbuds", name: "Pulse Buds Pro", short: "Active noise cancelling earbuds with 32 hours of total battery.", cat: 1, price: 3490, was: 4290, qty: 14,
    tags: ["earbuds", "anc", "wireless", "bluetooth"], features: ["Hybrid active noise cancelling", "32 hours with the case", "Low-latency mode for video and games", "IPX4 sweat resistance", "Touch controls that can be customised"],
    specs: [["Driver", "11 mm dynamic"], ["Bluetooth", "5.3"], ["Battery", "7 h earbuds + 25 h case"], ["Charging", "USB-C, 10 min gives 2 h"], ["Water resistance", "IPX4"], ["Weight", "4.6 g per bud"]],
    variants: [{ name: "Colour", options: ["Graphite", "Pearl"] }], flags: { is_featured: true, is_trending: true, is_best_seller: true }, sold: 212, age: 40, related: [7, 2, 8],
    desc: "Pulse Buds Pro are built for people who spend half the day on calls and the other half on the move.\n\nHybrid noise cancelling takes the edge off buses and open offices, while transparency mode lets you hear announcements without taking them out.\n\nA pocket-sized case keeps them charged for the whole week." },
  { n: 2, slug: "arc-watch-2", img: "watch", name: "Arc Watch 2", short: "AMOLED smartwatch with calling, health tracking and a 10-day battery.", cat: 2, price: 5990, was: 7490, qty: 6,
    tags: ["smartwatch", "fitness", "amoled"], features: ["1.43 inch AMOLED display", "Bluetooth calling", "Heart rate, SpO2 and sleep tracking", "100+ sport modes", "Up to 10 days of battery"],
    specs: [["Display", "1.43 inch AMOLED, 466x466"], ["Battery", "Up to 10 days"], ["Water resistance", "5 ATM"], ["Connectivity", "Bluetooth 5.2"], ["Compatibility", "Android 8+, iOS 13+"]],
    variants: [{ name: "Strap", options: ["Black", "Silver", "Olive"] }], flags: { is_featured: true, is_trending: true, is_new_arrival: true }, sold: 96, age: 6, related: [11, 1, 8],
    desc: "A bright AMOLED screen, honest battery life and the health features you will actually check.\n\nTake calls from your wrist, track workouts without a phone nearby, and charge it once a week." },
  { n: 3, slug: "volt-20k-power-bank", img: "powerbank", name: "Volt 20K Power Bank", short: "20,000 mAh, 65W fast charge. Powers a phone for a week or a laptop for a day.", cat: 3, price: 4290, was: 4990, qty: 22,
    tags: ["power bank", "fast charging", "laptop"], features: ["20,000 mAh capacity", "65W USB-C power delivery", "Charges three devices at once", "Digital percentage display", "Flight-safe under 100 Wh"],
    specs: [["Capacity", "20,000 mAh (74 Wh)"], ["Output", "65W USB-C, 22.5W USB-A"], ["Input", "45W USB-C"], ["Ports", "2x USB-C, 1x USB-A"], ["Weight", "438 g"]],
    flags: { is_best_seller: true, is_trending: true }, sold: 178, age: 70, related: [8, 4, 12],
    desc: "Big enough for a long trip, small enough for a jacket pocket.\n\n65W output means it can top up a laptop, and the display tells you exactly how much is left." },
  { n: 4, slug: "halo-magnetic-charger", img: "pad", name: "Halo Magnetic Charger", short: "15W magnetic wireless charger that snaps on and stays put.", cat: 3, price: 1990, was: 2490, qty: 31,
    tags: ["wireless charger", "magnetic"], features: ["15W fast wireless charging", "Strong magnetic alignment", "Works through thin cases", "Over-temperature protection", "1.2 m braided cable"],
    specs: [["Output", "15W max"], ["Input", "USB-C 20W"], ["Cable", "1.2 m braided"], ["Compatibility", "Magnetic Qi2 phones and Qi devices"]],
    flags: { is_new_arrival: true }, sold: 58, age: 9, related: [3, 8, 1],
    desc: "Snap it on and the phone lines up every time. No fiddling with coil position, no slow charge because it drifted." },
  { n: 5, slug: "type-75-mechanical-keyboard", img: "keyboard", name: "Type 75 Mechanical Keyboard", short: "Hot-swappable 75% keyboard with gasket mount and tri-mode wireless.", cat: 4, price: 6490, was: 7990, qty: 4,
    tags: ["keyboard", "mechanical", "wireless"], features: ["Hot-swappable switches", "Gasket-mount for a softer typing feel", "Bluetooth, 2.4 GHz and USB-C", "Per-key lighting", "4,000 mAh battery"],
    specs: [["Layout", "75% (82 keys)"], ["Switches", "Linear, pre-lubed"], ["Connection", "Bluetooth 5.1, 2.4 GHz, USB-C"], ["Battery", "4,000 mAh"], ["Keycaps", "Double-shot PBT"]],
    variants: [{ name: "Switch", options: ["Linear", "Tactile"] }], flags: { is_featured: true, is_new_arrival: true }, sold: 41, age: 4, related: [6, 9, 10],
    desc: "A keyboard you want to sit down at. Soft, solid typing sound, a compact layout that keeps your mouse close, and the freedom to swap switches later." },
  { n: 6, slug: "glide-silent-mouse", img: "mouse", name: "Glide Silent Mouse", short: "Quiet-click wireless mouse with a 6-month battery.", cat: 4, price: 1290, qty: 40,
    tags: ["mouse", "wireless", "silent"], features: ["Silent click switches", "Bluetooth and 2.4 GHz", "Adjustable DPI up to 4,000", "Up to 6 months on one AA"],
    specs: [["Sensor", "Optical, 4,000 DPI"], ["Connection", "Bluetooth 5.0 / 2.4 GHz"], ["Battery", "1x AA, up to 6 months"], ["Weight", "86 g"]],
    flags: { is_best_seller: true }, sold: 134, age: 90, related: [5, 12, 9],
    desc: "The mouse for shared rooms and late nights. You will see the click, but nobody else will hear it." },
  { n: 7, slug: "orbit-mini-speaker", img: "speaker", name: "Orbit Mini Speaker", short: "Pocketable 360° Bluetooth speaker with 14 hours of playtime.", cat: 1, price: 2790, was: 3290, qty: 18,
    tags: ["speaker", "bluetooth", "portable", "waterproof"], features: ["360° sound", "IPX7 waterproof", "14 hours of playtime", "Pair two for stereo", "Built-in microphone"],
    specs: [["Output", "12W"], ["Battery", "14 hours"], ["Water resistance", "IPX7"], ["Bluetooth", "5.3"], ["Weight", "380 g"]],
    flags: { is_trending: true, is_best_seller: true }, sold: 120, age: 55, related: [1, 3, 11],
    desc: "Loud enough for a rooftop, small enough for a bag side-pocket. Splash it, drop it on the sofa, keep going." },
  { n: 8, slug: "gan-65w-fast-charger", img: "charger", name: "GaN 65W Fast Charger", short: "One tiny charger for your laptop, phone and tablet.", cat: 3, price: 2290, was: 2790, qty: 27,
    tags: ["charger", "gan", "usb-c"], features: ["65W total output", "2x USB-C and 1x USB-A", "GaN for a smaller body", "Foldable plug", "Smart power split"],
    specs: [["Output", "65W max"], ["Ports", "2x USB-C, 1x USB-A"], ["Technology", "GaN III"], ["Size", "48 x 48 x 31 mm"]],
    flags: { is_featured: true, is_best_seller: true }, sold: 163, age: 80, related: [3, 4, 12],
    desc: "Replace three chargers with one. It is about the size of a matchbox and charges a laptop at full speed." },
  { n: 9, slug: "clear-1080-webcam", img: "webcam", name: "Clear 1080 Webcam", short: "Full HD webcam with autofocus and a dual noise-reducing mic.", cat: 4, price: 2490, qty: 0, out: true,
    tags: ["webcam", "meetings", "streaming"], features: ["1080p at 30 fps", "Autofocus", "Dual noise-reducing microphones", "Privacy shutter", "Plug and play over USB"],
    specs: [["Resolution", "1920 x 1080"], ["Field of view", "78°"], ["Connection", "USB-A"], ["Compatibility", "Windows, macOS, ChromeOS"]],
    flags: {}, sold: 77, age: 120, related: [5, 6, 10],
    desc: "Look sharp on every call without installing anything. Plug it in and it just works." },
  { n: 10, slug: "dawn-led-desk-lamp", img: "lamp", name: "Dawn LED Desk Lamp", short: "Eye-friendly desk lamp with adjustable colour temperature and a wireless charging base.", cat: 4, price: 3290, was: 3990, qty: 9,
    tags: ["lamp", "desk", "led", "wireless charging"], features: ["3 colour temperatures, 5 brightness levels", "10W wireless charging base", "Flicker-free light", "Touch controls with memory", "Folds flat"],
    specs: [["Light", "2700K to 6500K"], ["Brightness", "5 levels"], ["Wireless charging", "10W"], ["Power", "USB-C 12W"]],
    flags: { is_featured: true, is_trending: true }, sold: 49, age: 21, related: [5, 6, 12],
    desc: "Warm light for the evening, cool light for focus. The base charges your phone while you work." },
  { n: 11, slug: "find-tag-tracker", img: "tracker", name: "Find Tag Tracker", short: "Slim Bluetooth tracker for keys, bags and wallets with a loud built-in speaker.", cat: 2, price: 1190, qty: 50,
    tags: ["tracker", "keys", "bluetooth"], features: ["Loud built-in speaker", "1-year replaceable battery", "Last-seen location on a map", "Splash resistant"],
    specs: [["Battery", "CR2032, about 1 year"], ["Range", "Up to 60 m"], ["Water resistance", "IP67"], ["Weight", "11 g"]],
    flags: { is_new_arrival: true }, sold: 33, age: 12, related: [2, 7, 3],
    desc: "Never turn the house upside down for your keys again. Ring them from your phone or see where you last had them." },
  { n: 12, slug: "dock-7-in-1-usb-c-hub", img: "hub", name: "Dock 7-in-1 USB-C Hub", short: "HDMI 4K, SD card reader, USB 3.0 and 100W pass-through in one slim hub.", cat: 4, price: 2890, was: 3490, qty: 12,
    tags: ["usb-c", "hub", "hdmi", "laptop"], features: ["4K HDMI output", "100W power pass-through", "SD and microSD readers", "3x USB 3.0", "Aluminium body"],
    specs: [["Ports", "HDMI, 3x USB 3.0, SD, microSD, USB-C PD"], ["Video", "4K at 30 Hz"], ["Pass-through", "Up to 100W"], ["Body", "Aluminium"]],
    flags: { is_trending: true }, sold: 88, age: 33, related: [3, 8, 6],
    desc: "Turn one port into seven. Plug in a display, a card and a mouse and still charge the laptop." },
];

export const DEMO_PRODUCTS: Product[] = seeds.map((s) => ({
  id: pid(s.n), slug: s.slug, name: s.name, short_description: s.short, description: s.desc,
  price: s.price, compare_at_price: s.was ?? null,
  stock_status: s.out ? "out_of_stock" : "in_stock", stock_qty: s.qty ?? null, sku: `DEMO-${String(s.n).padStart(3, "0")}`,
  category_id: cid(s.cat), tags: s.tags,
  images: [1, 2, 3].map((i) => ({ url: `/demo/${s.img}-${i}.svg`, alt: `${s.name} view ${i}` })),
  specs: s.specs.map(([label, value]) => ({ label, value })), features: s.features, variants: s.variants ?? [],
  related_ids: s.related.map(pid),
  is_featured: !!s.flags.is_featured, is_trending: !!s.flags.is_trending, is_best_seller: !!s.flags.is_best_seller, is_new_arrival: !!s.flags.is_new_arrival,
  is_published: true, cod_available: true, sold_count: s.sold, is_demo: true, created_at: ago(s.age), updated_at: ago(s.age),
}));

const rv = (n: number, p: number, name: string, rating: number, body: string, d: number): Review => ({
  id: rid(n), product_id: pid(p), order_number: null, author_name: name, rating, body, image_url: null, status: "approved", created_at: ago(d), is_demo: true,
});

export const DEMO_REVIEWS: Review[] = [
  rv(1, 1, "Tanvir H.", 5, "Noise cancelling is better than I expected at this price. Call quality is clear and the battery lasts all week.", 8),
  rv(2, 1, "Nusrat J.", 5, "Fits comfortably and does not fall out when I walk. Delivered in two days.", 15),
  rv(3, 1, "Rafi A.", 4, "Great sound. The case is a bit glossy and shows fingerprints, otherwise perfect.", 22),
  rv(4, 2, "Sadia K.", 5, "The screen is bright outdoors and the battery really does last more than a week.", 5),
  rv(5, 2, "Imran M.", 4, "Good watch for the price. Calls work well. Strap is comfortable.", 11),
  rv(6, 3, "Mahfuz R.", 5, "Charged my laptop twice on a long bus ride. Solid build, display is handy.", 12),
  rv(7, 3, "Farhana S.", 5, "Exactly as described. Packed well and arrived on time.", 20),
  rv(8, 5, "Shihab D.", 5, "Typing feels great, the sound is deep and quiet. Easy to connect to three devices.", 3),
  rv(9, 6, "Arif B.", 5, "Silent for real. My roommate approves.", 30),
  rv(10, 7, "Maliha T.", 4, "Loud and clear for its size. Survived a splash at the pool.", 18),
  rv(11, 8, "Jahid K.", 5, "Replaced my laptop and phone chargers with this. Does not get hot.", 25),
  rv(12, 10, "Ritu P.", 5, "Warm light at night is lovely and the phone charges on the base.", 9),
  rv(13, 12, "Sohan G.", 4, "HDMI works perfectly with my monitor. Gets a little warm under load.", 14),
];
