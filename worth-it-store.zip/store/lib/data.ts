import { publicClient, isSupabaseConfigured } from "./supabase/public";
import { DEMO_CATEGORIES, DEMO_PRODUCTS, DEMO_REVIEWS } from "./demo-data";
import { mergeSettings } from "./default-settings";
import type { Category, Product, Review, SiteSettings } from "./types";

export const isDemoMode = () => !isSupabaseConfigured();

function withRatings(products: Product[], reviews: Pick<Review, "product_id" | "rating">[]): Product[] {
  const agg = new Map<string, { sum: number; n: number }>();
  for (const r of reviews) {
    const a = agg.get(r.product_id) ?? { sum: 0, n: 0 };
    a.sum += r.rating; a.n += 1; agg.set(r.product_id, a);
  }
  return products.map((p) => {
    const a = agg.get(p.id);
    return { ...p, rating_avg: a ? Math.round((a.sum / a.n) * 10) / 10 : 0, rating_count: a?.n ?? 0 };
  });
}

export async function getSettings(): Promise<SiteSettings> {
  if (isDemoMode()) return mergeSettings({});
  try {
    const { data } = await publicClient().from("settings").select("data").eq("id", 1).maybeSingle();
    return mergeSettings(data?.data);
  } catch { return mergeSettings({}); }
}

export async function getCategories(): Promise<Category[]> {
  if (isDemoMode()) return DEMO_CATEGORIES;
  try {
    const { data } = await publicClient().from("categories").select("*").order("sort_order").order("name");
    return (data ?? []) as Category[];
  } catch { return []; }
}

export async function getProducts(): Promise<Product[]> {
  if (isDemoMode()) return withRatings(DEMO_PRODUCTS, DEMO_REVIEWS);
  try {
    const c = publicClient();
    const [p, r] = await Promise.all([
      c.from("products").select("*").eq("is_published", true).order("created_at", { ascending: false }),
      c.from("reviews").select("product_id,rating").eq("status", "approved"),
    ]);
    return withRatings((p.data ?? []) as Product[], (r.data ?? []) as Review[]);
  } catch { return []; }
}

export async function getProductBySlug(slug: string) {
  return (await getProducts()).find((p) => p.slug === slug) ?? null;
}

export async function getReviews(productId?: string): Promise<(Review & { product_name?: string })[]> {
  const products = await getProducts();
  const name = new Map(products.map((p) => [p.id, p.name]));
  let list: Review[];
  if (isDemoMode()) list = DEMO_REVIEWS;
  else {
    try {
      const { data } = await publicClient().from("reviews").select("*").eq("status", "approved").order("created_at", { ascending: false });
      list = (data ?? []) as Review[];
    } catch { list = []; }
  }
  if (productId) list = list.filter((r) => r.product_id === productId);
  return list.map((r) => ({ ...r, product_name: name.get(r.product_id) })).sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at));
}
